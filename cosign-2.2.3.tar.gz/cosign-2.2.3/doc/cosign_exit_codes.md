# Exit codes for cosign CLI

> The following exit codes may be subject to change

| Exit code | Meaning |
| :----: | :---- |
| 10 | Error verifying image due to no signature|
| 11 | Error verifying image due to non-existent tag|
| 12 | Error verifying image due to no matching signature|
| 13 | Error verifying image due to no certificate found on signature|
