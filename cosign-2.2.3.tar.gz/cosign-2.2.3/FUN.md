# Fun Tips And Tricks!

## Signing Git Commits

Git commit signing has been broken out into its own project! Check out
https://github.com/sigstore/gitsign for more.
