#!/bin/bash

exec gosu gsad "$@"
