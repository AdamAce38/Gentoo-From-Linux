#!/bin/bash

STRING=$1
shift
echo "$STRING" | $*
