A clean home directory
======================

This directory exists to ensure that during test runs we do not accidentally pick up a user's configuration file.