---
name: Question
about: Project related question
title: "[Question]"
labels: question
assignees: ''

---

##### Description:
[...]

##### Affected versions (if applicable)
- [ ] `master` branch (specify commit)
- [ ] Latest stable version from `pypi`
- [ ] Other (specify source)
