# frozen_string_literal: true

# Released under the MIT License.
# Copyright, 2021-2022, by Samuel Williams.

class IO
	module Event
		VERSION = "1.1.7"
	end
end
