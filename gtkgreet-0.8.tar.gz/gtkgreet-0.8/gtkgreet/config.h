#ifndef _CONFIG_H
#define _CONFIG_H

#include <gtk/gtk.h>

int config_update_command_selector(GtkWidget *combobox);

#endif