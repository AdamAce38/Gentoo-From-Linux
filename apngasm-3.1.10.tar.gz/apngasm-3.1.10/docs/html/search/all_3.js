var searchData=
[
  ['getframes',['getFrames',['../classapngasm_1_1APNGAsm.html#a7533862bb9fae0c1fe9c16d3887eb5a2',1,'apngasm::APNGAsm']]]
];
