
# GitHub Pages
The latest news for CDI 4.x can be found in the [GitHub pages](https://eclipse-ee4j.github.io/cdi/)

Sources in GIT
====

Master contains the work-in-progress on CDI 4.0 specification

# Legacy Releases
Check out the [cdi-spec.org](http://cdi-spec.org) for more info on CDI 2.0 and CDI 1.2
