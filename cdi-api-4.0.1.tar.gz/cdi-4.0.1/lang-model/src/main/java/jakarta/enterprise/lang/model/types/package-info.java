/**
 * Interfaces that represent {@linkplain jakarta.enterprise.lang.model.types.Type types}.
 */
package jakarta.enterprise.lang.model.types;
