/**
 * The core interfaces of the language model that represent
 * {@linkplain jakarta.enterprise.lang.model.AnnotationInfo annotations} and
 * {@linkplain jakarta.enterprise.lang.model.AnnotationTarget annotation targets}.
 */
package jakarta.enterprise.lang.model;
