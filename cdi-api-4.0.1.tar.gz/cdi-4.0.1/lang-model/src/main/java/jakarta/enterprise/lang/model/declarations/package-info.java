/**
 * Interfaces that represent {@linkplain jakarta.enterprise.lang.model.declarations.DeclarationInfo declarations}.
 */
package jakarta.enterprise.lang.model.declarations;
