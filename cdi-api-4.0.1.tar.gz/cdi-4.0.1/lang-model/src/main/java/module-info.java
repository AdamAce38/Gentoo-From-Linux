module jakarta.cdi.lang.model {
    exports jakarta.enterprise.lang.model;
    exports jakarta.enterprise.lang.model.declarations;
    exports jakarta.enterprise.lang.model.types;
}