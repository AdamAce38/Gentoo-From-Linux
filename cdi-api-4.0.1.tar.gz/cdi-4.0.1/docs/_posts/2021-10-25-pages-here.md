---
layout: post
title:  "Jakarta CDI GitHub Pages"
date:   2021-10-25 22:08:50 -0500
categories: announcement
author: starksm
---

# CDI GitHub Pages

The GitHub pages for Jakarta CDI has arrived. See the [README.md](https://github.com/eclipse-ee4j/cdi/tree/master/docs/README.md) file for how to build the pages site locally, and how to create a blog entry.