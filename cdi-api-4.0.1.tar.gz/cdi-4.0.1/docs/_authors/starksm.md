---
short_name: starksm
name: Scott M Stark
position: Software Engineer
---
https://github.com/starksm64