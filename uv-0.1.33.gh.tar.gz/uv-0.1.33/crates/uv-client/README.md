# `pypi-client`

A general-use client for interacting with PyPI.

Loosely modeled after Orogene's `oro-client`.
