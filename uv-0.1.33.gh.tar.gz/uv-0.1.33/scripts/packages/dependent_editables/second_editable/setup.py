from setuptools import setup

setup(
    name="second-editable",
    version="0.0.1",
    install_requires=[
        "first-editable",
    ],
)
