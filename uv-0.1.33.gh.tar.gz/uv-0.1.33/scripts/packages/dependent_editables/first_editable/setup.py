from setuptools import setup

setup(name="first-editable", version="0.0.1", install_requires=[])
