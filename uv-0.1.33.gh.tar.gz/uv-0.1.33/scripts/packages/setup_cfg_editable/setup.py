from setuptools import setup

setup(
    install_requires=[
        "requests",
        'importlib-metadata; python_version<"3.10"',
    ],
)
