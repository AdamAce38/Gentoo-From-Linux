	rts

#print 12+12
~print 10+10
