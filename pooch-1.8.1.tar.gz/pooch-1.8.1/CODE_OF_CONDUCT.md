# Contributor Code of Conduct

Please refer to our organization-wide
[Code of Conduct](https://github.com/fatiando/community/blob/main/CODE_OF_CONDUCT.md).
