API Reference
=============

This is an incomplete reference of the relevant Streamlink APIs.

.. toctree::

    api/streamlink
    api/session
    api/plugin
    api/options
    api/cache
    api/validate
    api/stream
    api/webbrowser
    api/exceptions
