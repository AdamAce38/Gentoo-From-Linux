Plugin specific usage
=====================


.. toctree::
    plugins/crunchyroll
    plugins/twitch
