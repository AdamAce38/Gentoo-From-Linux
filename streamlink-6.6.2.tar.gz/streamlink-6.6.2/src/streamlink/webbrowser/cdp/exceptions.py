from streamlink.webbrowser.exceptions import WebbrowserError


class CDPError(WebbrowserError):
    pass
