#include <iostream>
#include <foo_lib.hpp>

int main() {
    std::cout << fooFunc() << '\n';
    return 0;
}