#include <rapidfuzz/fuzz.hpp>

using FooType = rapidfuzz::fuzz::CachedRatio<char>;
double fooFunc();
