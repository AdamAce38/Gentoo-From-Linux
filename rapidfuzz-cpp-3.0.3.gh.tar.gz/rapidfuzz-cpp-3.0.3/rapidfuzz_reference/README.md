## rapidfuzz_reference

This includes reference implementations of various string matching algorithms,
which can be used to validate the results of faster implementations.