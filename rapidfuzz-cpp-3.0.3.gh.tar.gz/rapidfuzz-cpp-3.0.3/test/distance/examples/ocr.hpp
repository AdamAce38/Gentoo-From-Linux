#pragma once
#include <cstdint>
#include <string>

extern std::basic_string<uint8_t> ocr_example1;
extern std::basic_string<uint8_t> ocr_example2;
