#include <gtk/gtk.h>

#include "gamepick.h"

void reflect_game (gamepick_info *info, game_struct *game);
void click_on_game (GtkWidget *button, gamepick_info *info);

