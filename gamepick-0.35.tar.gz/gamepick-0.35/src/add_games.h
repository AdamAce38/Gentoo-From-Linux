
#include <gtk/gtk.h>

#include "gamepick.h"

const gchar* fragment (gamepick_info *info, const gchar *text);
void zero_game_entry (game_struct *game);
gint add_tab (gamepick_info *info, const gchar* name);
void pinup_game (gamepick_info *info, game_struct *game);
game_struct* add_game
  (gamepick_info *info, const game_struct *source, gint tab_number);
void take_down_game (game_struct *game);

