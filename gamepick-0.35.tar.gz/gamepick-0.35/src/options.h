
#include <gtk/gtk.h>

#include "gamepick.h"


void options_run (GtkWidget *widget, gamepick_info *info);
