
#include "gamepick.h"

void find_conf (gamepick_info *info);
void first_parse (gamepick_info *info);
void load_lists (gamepick_info *info);
void reset_gamepick_info (gamepick_info *info);
void warnings (gamepick_info *info, const gchar *actions);

