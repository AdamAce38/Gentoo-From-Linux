
#include "gamepick.h"

void save_config (gamepick_info *info);

