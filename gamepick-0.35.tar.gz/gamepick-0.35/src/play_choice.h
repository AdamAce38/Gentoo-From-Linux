
#include <gtk/gtk.h>


void play_choice (gamepick_info *info);

