
#include "gamepick.h"

#define auto_cols 3
#define auto_rows 2
#define buffer_size 256

#define global_knowns "known_games.lst"

typedef struct
{
  GString *name, *cmd, *icon;
} auto_knowns;

void auto_games_run (gamepick_info *info);

