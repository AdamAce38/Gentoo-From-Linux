
#include "gamepick.h"

void append (GtkWidget *combo, const gchar *text);
void close_dialog (GtkWidget *widget, GtkWidget *target);
void show_notice (const gchar* text, GtkWidget *parent);
void add_fsaa_combo (gamepick_info *info, GtkWidget *vbox, GtkWidget **dest);
void add_aitf_combo (gamepick_info *info, GtkWidget *vbox, GtkWidget **dest);
void edits_run (gamepick_info *info, game_struct *source);
/* pass source = NULL for new. */

