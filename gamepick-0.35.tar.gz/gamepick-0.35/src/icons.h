
#include <gtk/gtk.h>


GtkWidget* scaled_icon (const gchar *filename, gint max_x, gint max_y);

