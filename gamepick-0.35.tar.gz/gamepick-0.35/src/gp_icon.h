

const char** gp_icon();
const char** gp_small_icon();
