%%*************************************************************************
%% startup.m: set up search paths, and default parameters
%%
%%
%% DSDP: version 5.0
%% Copyright (c) 2004 by
%% S. Benson and Y. Ye
%% Last modified: 12 Oct 04
%%*************************************************************************
%%   warning off; 
 
   path(path,'./matlab');
%%
%%=========================================================================
