#include "../../include/dsdp5.h"
#include "petscksp.h"

int PDSDPUsePETScLinearSolver(DSDP, MPI_Comm, int);
void DSDPSetRank(int);
