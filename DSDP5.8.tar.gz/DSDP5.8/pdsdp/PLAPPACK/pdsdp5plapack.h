#include "dsdp5.h"
#include "PLA.h"

int PDSDPUsePLAPACKLinearSolver(DSDP, MPI_Comm, double, int);
void DSDPSetRank(int);

