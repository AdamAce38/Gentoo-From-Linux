# Dataframe

This dataframe directory holds all of the definitions of the dataframe data structures and commands.

There are three sections of commands:

* [eager](./eager)
* [series](./series)
* [values](./values)

For more details see the
[Nushell book section on dataframes](https://www.nushell.sh/book/dataframes.html)
