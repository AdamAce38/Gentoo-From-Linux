# Divan benchmarks

These are benchmarks using [Divan](https://github.com/nvzqz/divan), a microbenchmarking tool for Rust.

Run all benchmarks with `cargo bench`

Or run individual benchmarks like `cargo bench -- <regex>` e.g. `cargo bench -- parse`