// Copyright (c) Microsoft Corporation.
// Licensed under the MIT License.

#pragma once

#include "pal.h"

PAL_BEGIN_EXTERNC

char *GetComputerName();

PAL_END_EXTERNC
