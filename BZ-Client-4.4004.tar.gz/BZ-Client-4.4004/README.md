BZ::Client
----------

A Perl client for the Bugzilla web services API.

This software is copyright (c) 2021 by Dean Hamstad.

This is free software; you can redistribute it and/or modify it under
the same terms as the Perl 5 programming language system itself.

[![Build Status](https://travis-ci.org/djzort/BZ-Client.svg?branch=master)](https://travis-ci.org/djzort/BZ-Client)
[![CPAN version](https://badge.fury.io/pl/BZ-Client.svg)](https://metacpan.org/pod/BZ::Client)
