from flask_api.app import FlaskAPI

__version__ = "3.1"
