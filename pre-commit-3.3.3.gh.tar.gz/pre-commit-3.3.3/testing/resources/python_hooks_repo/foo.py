from __future__ import annotations

import sys


def main():
    print(repr(sys.argv[1:]))
    print('Hello World')
    return 0
