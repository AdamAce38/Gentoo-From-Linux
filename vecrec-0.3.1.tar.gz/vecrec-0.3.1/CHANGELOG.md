# Changelog

<!--next-version-placeholder-->

## v0.3.1 (2022-01-06)
### Fix
* Give `Rect.round()` the same API as `round()` ([`169bf73`](https://github.com/kxgames/vecrec/commit/169bf735bfccfbde8ea73dfa4769cae12bc6be3f))
