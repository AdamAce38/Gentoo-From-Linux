# separate file to simplify valgrind use

./rebar eunit
