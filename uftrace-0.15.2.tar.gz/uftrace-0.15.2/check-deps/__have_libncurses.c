#include <ncurses.h>

int main(void)
{
	initscr();
	endwin();
	return 0;
}
