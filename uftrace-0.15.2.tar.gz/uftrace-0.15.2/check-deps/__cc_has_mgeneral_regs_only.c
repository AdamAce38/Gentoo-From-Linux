#include <stdio.h>
#include <stdlib.h>

int main(void)
{
	printf("%f", 123.45);
	return 0;
}
