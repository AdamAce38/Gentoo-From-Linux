#include <sstream>

int main()
{
	std::ostringstream ss;
	ss.str();
	return 0;
}
