#!/usr/bin/env python3
import os

def foo():
    print(os.path.basename(__file__))

foo()
