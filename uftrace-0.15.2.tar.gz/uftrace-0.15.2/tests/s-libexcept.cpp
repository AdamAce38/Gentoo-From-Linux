#include "s-libexcept.hpp"
#include <stdexcept>

XXX::XXX()
{
	throw std::runtime_error("XXX error");
}
