#ifndef XXX_HPP
#define XXX_HPP

class XXX {
    public:
	XXX();
	~XXX()
	{
	}
};

#endif /* XXX_HPP */
