#ifndef UTILS_H
#define UTILS_H

#include "stdio.h"

ssize_t ckb_generate_random(size_t size, unsigned char* data);

#endif
