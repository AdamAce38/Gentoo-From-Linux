<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_GB">
<context>
    <name>AnimAddDialog</name>
    <message>
        <location filename="../../animadddialog.ui" line="20"/>
        <source>Add Animation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../animadddialog.ui" line="75"/>
        <source>Preset:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../animadddialog.ui" line="104"/>
        <source>Animation:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../animadddialog.ui" line="153"/>
        <source>Show preview</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AnimDetailsDialog</name>
    <message>
        <location filename="../../animdetailsdialog.ui" line="20"/>
        <source>Loaded Animations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../animdetailsdialog.ui" line="48"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../animdetailsdialog.ui" line="53"/>
        <source>Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../animdetailsdialog.ui" line="58"/>
        <source>Version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../animdetailsdialog.ui" line="63"/>
        <source>Author</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../animdetailsdialog.ui" line="68"/>
        <source>Year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../animdetailsdialog.ui" line="73"/>
        <source>License</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../animdetailsdialog.ui" line="78"/>
        <source>Description</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>AnimSettingDialog</name>
    <message>
        <location filename="../../animsettingdialog.ui" line="43"/>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../animsettingdialog.ui" line="64"/>
        <source>Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../animsettingdialog.ui" line="91"/>
        <source>Timing</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../animsettingdialog.ui" line="128"/>
        <location filename="../../animsettingdialog.ui" line="135"/>
        <source>Repeat every:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../animsettingdialog.ui" line="155"/>
        <location filename="../../animsettingdialog.ui" line="169"/>
        <location filename="../../animsettingdialog.ui" line="183"/>
        <location filename="../../animsettingdialog.ui" line="200"/>
        <location filename="../../animsettingdialog.cpp" line="216"/>
        <location filename="../../animsettingdialog.cpp" line="342"/>
        <location filename="../../animsettingdialog.cpp" line="358"/>
        <source>seconds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../animsettingdialog.ui" line="176"/>
        <source>&lt;b&gt;On mode start&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../animsettingdialog.ui" line="207"/>
        <location filename="../../animsettingdialog.ui" line="231"/>
        <source>Start delay:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../animsettingdialog.ui" line="224"/>
        <source>Stop on key press</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../animsettingdialog.ui" line="267"/>
        <source>Stop on key release</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../animsettingdialog.ui" line="274"/>
        <source>&lt;b&gt;On key press&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../animsettingdialog.ui" line="331"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../animsettingdialog.ui" line="352"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../animsettingdialog.ui" line="359"/>
        <source>Year:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../animsettingdialog.ui" line="366"/>
        <source>Description:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../animsettingdialog.ui" line="373"/>
        <source>Author</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../animsettingdialog.ui" line="380"/>
        <source>License:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../animsettingdialog.ui" line="387"/>
        <source>Version:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../animsettingdialog.ui" line="394"/>
        <source>Year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../animsettingdialog.ui" line="401"/>
        <source>Author:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../animsettingdialog.ui" line="437"/>
        <source>Version</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../animsettingdialog.ui" line="444"/>
        <source>License</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../animsettingdialog.ui" line="451"/>
        <source>Script name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../animsettingdialog.ui" line="471"/>
        <source>Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../animsettingdialog.cpp" line="26"/>
        <source> Animation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../animsettingdialog.cpp" line="33"/>
        <source>&lt;b&gt;Animation&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../animsettingdialog.cpp" line="203"/>
        <source>&lt;b&gt;Playback&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../animsettingdialog.cpp" line="208"/>
        <source>Duration:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../animsettingdialog.cpp" line="220"/>
        <source>Start with mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../animsettingdialog.cpp" line="228"/>
        <source>Start with key press</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../animsettingdialog.cpp" line="240"/>
        <source>on pressed key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../animsettingdialog.cpp" line="241"/>
        <source>on whole keyboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../animsettingdialog.cpp" line="242"/>
        <source>on keyboard (once)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../animsettingdialog.cpp" line="246"/>
        <source>every time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../animsettingdialog.cpp" line="247"/>
        <source>only once</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../animsettingdialog.cpp" line="285"/>
        <location filename="../../animsettingdialog.cpp" line="297"/>
        <source>Repeat:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../animsettingdialog.cpp" line="295"/>
        <location filename="../../animsettingdialog.cpp" line="307"/>
        <source>times</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../animsettingdialog.cpp" line="309"/>
        <location filename="../../animsettingdialog.cpp" line="312"/>
        <source>Forever</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../animsettingdialog.cpp" line="360"/>
        <location filename="../../animsettingdialog.cpp" line="364"/>
        <source>Stop after:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>BatteryStatusTrayIcon</name>
    <message>
        <location filename="../../batterysystemtrayicon.cpp" line="24"/>
        <source>Not connected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../batterysystemtrayicon.cpp" line="24"/>
        <source>Critical</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../batterysystemtrayicon.cpp" line="24"/>
        <source>Low</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../batterysystemtrayicon.cpp" line="24"/>
        <source>Medium</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../batterysystemtrayicon.cpp" line="24"/>
        <source>High</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../batterysystemtrayicon.cpp" line="25"/>
        <source>N/A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../batterysystemtrayicon.cpp" line="25"/>
        <source>Discharging</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../batterysystemtrayicon.cpp" line="25"/>
        <source>Charging</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../batterysystemtrayicon.cpp" line="25"/>
        <source>Fully Charged</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../batterysystemtrayicon.cpp" line="26"/>
        <source>Battery: %1 (%2%)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../batterysystemtrayicon.cpp" line="27"/>
        <source>Status: %1</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CkbUpdaterDialog</name>
    <message>
        <location filename="../../ckbupdaterwidget.cpp" line="55"/>
        <source>Downloading</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ckbupdaterwidget.cpp" line="102"/>
        <source>Update has been downloaded to /tmp/ckb-next/v</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ckbupdaterwidget.cpp" line="102"/>
        <source>Download Complete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ckbupdaterwidget.cpp" line="105"/>
        <source>&lt;br /&gt;You will need to manually compile the source code.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ckbupdaterwidget.cpp" line="107"/>
        <source>&lt;br /&gt;&lt;br /&gt;Optionally, for added security, please check that the following value exists at the bottom of &lt;a href=&quot;https://github.com/ckb-next/ckb-next/releases/tag/v</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ckbupdaterwidget.cpp" line="109"/>
        <source>&quot;&gt;this page&lt;/a&gt;.&lt;br /&gt;&lt;pre&gt;%1&lt;/pre&gt;&lt;br /&gt;Press OK to continue.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>CkbUpdaterWidget</name>
    <message>
        <location filename="../../ckbupdaterwidget.ui" line="14"/>
        <source>Software Updater</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ckbupdaterwidget.ui" line="92"/>
        <source>A new version of ckb-next has been released.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ckbupdaterwidget.ui" line="156"/>
        <source>Update Now</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ckbupdaterwidget.ui" line="172"/>
        <source>Remind Me Later</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ColorButton</name>
    <message>
        <location filename="../../colorbutton.cpp" line="51"/>
        <source>Change color...</source>
        <translation type="unfinished">Change colour...</translation>
    </message>
    <message>
        <location filename="../../colorbutton.cpp" line="96"/>
        <source>A system configuration that can lead to instability issues with this software has been detected.&lt;br&gt;&lt;br&gt;If this application locks up after clicking the OK button below, please refer to &lt;a href=&quot;https://github.com/ckb-next/ckb-next/wiki/Troubleshooting#glib-critical-errors-and-lock-up-at-colour-chooser&quot;&gt;https://github.com/ckb-next/ckb-next/wiki/Troubleshooting#glib-critical-errors-and-lock-up-at-colour-chooser&lt;/a&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ExtraSettingsWidget</name>
    <message>
        <location filename="../../extrasettingswidget.ui" line="313"/>
        <source>By default, the same brightness level will be applied to all profiles and all devices. Enable this to store it with the lighting mode instead.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../extrasettingswidget.ui" line="316"/>
        <source>Set brightness per-mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../extrasettingswidget.ui" line="219"/>
        <source>Behavior</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../extrasettingswidget.ui" line="238"/>
        <source>OS X tweaks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../extrasettingswidget.ui" line="178"/>
        <source>The tray icon will not be displayed. The application will still run in the background; re-launch the app to see the GUI again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../extrasettingswidget.ui" line="181"/>
        <source>Hide tray icon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../extrasettingswidget.ui" line="392"/>
        <source>Frame rate (FPS):</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../extrasettingswidget.ui" line="441"/>
        <source>0 animations found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../extrasettingswidget.ui" line="453"/>
        <source>Re-scan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../extrasettingswidget.ui" line="460"/>
        <source>Details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../extrasettingswidget.ui" line="566"/>
        <source>Disable Anti Aliasing (Requires restart)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../extrasettingswidget.ui" line="264"/>
        <source>Location:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../extrasettingswidget.ui" line="75"/>
        <source>Try this if you&apos;re having problems with mouse movement.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../extrasettingswidget.ui" line="78"/>
        <source>Disable mouse acceleration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../extrasettingswidget.ui" line="200"/>
        <source>Hardware</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../extrasettingswidget.ui" line="306"/>
        <source>Warning: high frame rates may cause stability issues</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../extrasettingswidget.ui" line="106"/>
        <source>Scroll</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../extrasettingswidget.ui" line="132"/>
        <source>line(s) at a time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../extrasettingswidget.ui" line="365"/>
        <source>Disable animated preview when ckb-next is not in focus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../extrasettingswidget.ui" line="382"/>
        <source>May improve appearance on some keyboards.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../extrasettingswidget.ui" line="385"/>
        <source>Use spatial dithering to simulate extra color resolution</source>
        <translation>Use spatial dithering to simulate extra colour resolution</translation>
    </message>
    <message>
        <location filename="../../extrasettingswidget.ui" line="339"/>
        <source>Try this if you&apos;re having problems with the scroll wheel.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../extrasettingswidget.ui" line="342"/>
        <source>Disable scroll acceleration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../extrasettingswidget.ui" line="68"/>
        <source>Monochrome tray icon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../extrasettingswidget.ui" line="257"/>
        <source>Animation scripts</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../extrasettingswidget.ui" line="506"/>
        <source>Turn lights off when idle for</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../extrasettingswidget.ui" line="538"/>
        <source>m</source>
        <comment>minutes</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../extrasettingswidget.ui" line="41"/>
        <source>Delay application start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../extrasettingswidget.ui" line="358"/>
        <source>Enabling per-mode brightness will disable scrolling on the tray icon to change the brightness level</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../extrasettingswidget.cpp" line="83"/>
        <source>This feature is not supported under Wayland</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../extrasettingswidget.cpp" line="120"/>
        <source>No animations found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../extrasettingswidget.cpp" line="122"/>
        <source>1 animation found</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../extrasettingswidget.cpp" line="124"/>
        <source>%1 animations found</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FwUpgradeDialog</name>
    <message>
        <location filename="../../fwupgradedialog.ui" line="20"/>
        <source>Firmware update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../fwupgradedialog.ui" line="60"/>
        <source>New:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../fwupgradedialog.ui" line="86"/>
        <source>Current:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../fwupgradedialog.ui" line="113"/>
        <source>Downloading new firmware, please wait...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../fwupgradedialog.ui" line="151"/>
        <source>Device</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../fwupgradedialog.ui" line="176"/>
        <source>Start</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../fwupgradedialog.ui" line="189"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../fwupgradedialog.cpp" line="90"/>
        <location filename="../../fwupgradedialog.cpp" line="106"/>
        <location filename="../../fwupgradedialog.cpp" line="113"/>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../fwupgradedialog.cpp" line="90"/>
        <source>&lt;center&gt;Not a valid firmware for this device.&lt;/center&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../fwupgradedialog.cpp" line="106"/>
        <source>&lt;center&gt;There was a problem with the downloaded file.&lt;br /&gt;Please try again later.&lt;/center&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../fwupgradedialog.cpp" line="113"/>
        <source>&lt;center&gt;Unable to save temporary file.&lt;/center&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../fwupgradedialog.cpp" line="120"/>
        <source>Ready to install new firmware.&lt;br /&gt;&lt;br /&gt;&lt;b&gt;Disclaimer:&lt;/b&gt; ckb-next is not endorsed by Corsair.&lt;br /&gt;&lt;br /&gt;This is &lt;i&gt;unlikely&lt;/i&gt; to cause any damage, however the developers of this software do not accept any responsibility in such an event.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../fwupgradedialog.cpp" line="149"/>
        <source>Update successful!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../fwupgradedialog.cpp" line="151"/>
        <source>Update failed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../fwupgradedialog.cpp" line="152"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../fwupgradedialog.cpp" line="176"/>
        <source>Please wait</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../fwupgradedialog.cpp" line="177"/>
        <source>Installing firmware...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GradientDialog</name>
    <message>
        <location filename="../../gradientdialog.ui" line="29"/>
        <source>Pick Gradient</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gradientdialog.ui" line="113"/>
        <source>Pick Color...</source>
        <translation>Pick Colour...</translation>
    </message>
    <message>
        <location filename="../../gradientdialog.ui" line="145"/>
        <source>Position:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gradientdialog.ui" line="179"/>
        <source>Color:</source>
        <translation>Colour:</translation>
    </message>
    <message>
        <location filename="../../gradientdialog.ui" line="211"/>
        <source>Presets</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gradientdialog.ui" line="254"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gradientdialog.ui" line="261"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gradientdialog.ui" line="271"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gradientdialog.cpp" line="131"/>
        <source>1 point</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gradientdialog.cpp" line="133"/>
        <source>%1 points</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gradientdialog.cpp" line="160"/>
        <location filename="../../gradientdialog.cpp" line="188"/>
        <source>Custom</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gradientdialog.cpp" line="193"/>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gradientdialog.cpp" line="193"/>
        <source>Can&apos;t overwrite a built-in preset. Please choose a different name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gradientdialog.cpp" line="198"/>
        <location filename="../../gradientdialog.cpp" line="215"/>
        <source>Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gradientdialog.cpp" line="198"/>
        <source>Preset &quot;%1&quot; already exists. Replace?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../gradientdialog.cpp" line="215"/>
        <source>Delete preset &quot;%1&quot;?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>KPerfWidget</name>
    <message>
        <location filename="../../kperfwidget.ui" line="105"/>
        <location filename="../../kperfwidget.ui" line="260"/>
        <location filename="../../kperfwidget.ui" line="422"/>
        <location filename="../../kperfwidget.ui" line="429"/>
        <location filename="../../kperfwidget.ui" line="474"/>
        <location filename="../../kperfwidget.ui" line="665"/>
        <location filename="../../kperfwidget.ui" line="757"/>
        <source>On</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kperfwidget.ui" line="362"/>
        <location filename="../../kperfwidget.ui" line="507"/>
        <location filename="../../kperfwidget.ui" line="637"/>
        <source>Normal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kperfwidget.ui" line="367"/>
        <location filename="../../kperfwidget.ui" line="512"/>
        <location filename="../../kperfwidget.ui" line="642"/>
        <source>Always on</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kperfwidget.ui" line="372"/>
        <location filename="../../kperfwidget.ui" line="517"/>
        <location filename="../../kperfwidget.ui" line="647"/>
        <source>Always off</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kperfwidget.ui" line="377"/>
        <location filename="../../kperfwidget.ui" line="522"/>
        <location filename="../../kperfwidget.ui" line="652"/>
        <source>RGB indicator</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kperfwidget.ui" line="382"/>
        <location filename="../../kperfwidget.ui" line="527"/>
        <location filename="../../kperfwidget.ui" line="657"/>
        <source>RGB + normal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kperfwidget.ui" line="91"/>
        <source>Indicate mute:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kperfwidget.ui" line="177"/>
        <location filename="../../kperfwidget.ui" line="234"/>
        <location filename="../../kperfwidget.ui" line="309"/>
        <location filename="../../kperfwidget.ui" line="596"/>
        <location filename="../../kperfwidget.ui" line="622"/>
        <location filename="../../kperfwidget.ui" line="679"/>
        <location filename="../../kperfwidget.ui" line="731"/>
        <source>Off</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kperfwidget.ui" line="750"/>
        <source>Top row</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kperfwidget.ui" line="70"/>
        <source>Indicate brightness:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kperfwidget.ui" line="629"/>
        <source>Indicate current mode:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kperfwidget.ui" line="803"/>
        <source>Default audio output</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kperfwidget.ui" line="808"/>
        <source>Default audio input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kperfwidget.ui" line="822"/>
        <source>Note: macro recording not implemented. Indicator will always display &quot;off&quot;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kperfwidget.ui" line="950"/>
        <source>Indicate mute from:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kperfwidget.ui" line="964"/>
        <source>Copy performance settings to mode...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kperfwidget.ui" line="1080"/>
        <source>Miscellaneous</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kperfwidget.ui" line="535"/>
        <source>Indicate macro recording:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kperfwidget.ui" line="829"/>
        <source>Indicate Windows Lock:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kperfwidget.ui" line="140"/>
        <source>Lock lights</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kperfwidget.ui" line="267"/>
        <source>Unknown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kperfwidget.ui" line="253"/>
        <source>K95 buttons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kperfwidget.ui" line="354"/>
        <source>Note: many desktop environments do not use scroll lock. The indicator may not turn on even when enabled.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kperfwidget.ui" line="698"/>
        <source>If the sound device does not support muting, or if mute status is unknown, this color will be displayed.</source>
        <translation>If the sound device does not support muting, or if mute status is unknown, this colour will be displayed.</translation>
    </message>
    <message>
        <location filename="../../kperfwidget.ui" line="708"/>
        <source>Indicator intensity:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kperfwidget.cpp" line="237"/>
        <source>Copy performance settings to:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>KStatusNotifierItem</name>
    <message>
        <location filename="../../kstatusnotifier/kstatusnotifieritem.cpp" line="578"/>
        <source>Quit</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>KbAnimWidget</name>
    <message>
        <location filename="../../kbanimwidget.ui" line="48"/>
        <source>No animations in this mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbanimwidget.ui" line="176"/>
        <source>Normal</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbanimwidget.ui" line="181"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbanimwidget.ui" line="186"/>
        <source>Subtract</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbanimwidget.ui" line="191"/>
        <source>Multiply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbanimwidget.ui" line="196"/>
        <source>Divide</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbanimwidget.ui" line="204"/>
        <source>Blend mode:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbanimwidget.ui" line="243"/>
        <source>Opacity:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbanimwidget.ui" line="250"/>
        <source>Name:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbanimwidget.ui" line="257"/>
        <source>Set keys</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbanimwidget.ui" line="264"/>
        <location filename="../../kbanimwidget.cpp" line="239"/>
        <source>Delete animation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbanimwidget.ui" line="271"/>
        <source>Edit properties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbanimwidget.cpp" line="183"/>
        <source>Rename...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbanimwidget.cpp" line="184"/>
        <source>Duplicate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbanimwidget.cpp" line="185"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbanimwidget.cpp" line="239"/>
        <source>Are you sure you want to delete this animation?</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>KbBindWidget</name>
    <message>
        <location filename="../../kbbindwidget.ui" line="49"/>
        <source>Keys</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbbindwidget.ui" line="80"/>
        <source>Copy to mode...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbbindwidget.ui" line="93"/>
        <source>Click to select keys</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbbindwidget.ui" line="115"/>
        <source>Reset</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbbindwidget.ui" line="131"/>
        <source>Binding</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbbindwidget.cpp" line="79"/>
        <source>Winlock Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbbindwidget.cpp" line="79"/>
        <source>Windows key lock is currently enabled.

The binding will not function until winlock has been disabled.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbbindwidget.cpp" line="87"/>
        <source>Click to select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbbindwidget.cpp" line="95"/>
        <source>(Unknown)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbbindwidget.cpp" line="100"/>
        <source>%1 %2 selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbbindwidget.cpp" line="100"/>
        <source>buttons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbbindwidget.cpp" line="100"/>
        <source>keys</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbbindwidget.cpp" line="113"/>
        <source>&lt;center&gt;Reset all %1s to default?&lt;/center&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbbindwidget.cpp" line="115"/>
        <source>&lt;center&gt;Reset this %1 to default?&lt;/center&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbbindwidget.cpp" line="117"/>
        <source>&lt;center&gt;Reset %1 %2s to default?&lt;/center&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbbindwidget.cpp" line="118"/>
        <source>Confirm action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbbindwidget.cpp" line="110"/>
        <location filename="../../kbbindwidget.cpp" line="128"/>
        <source>button</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbbindwidget.cpp" line="110"/>
        <location filename="../../kbbindwidget.cpp" line="128"/>
        <source>key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbbindwidget.cpp" line="129"/>
        <source>s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbbindwidget.cpp" line="133"/>
        <source>all %1s</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbbindwidget.cpp" line="135"/>
        <source>Copy binding for </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbbindwidget.cpp" line="135"/>
        <source> to:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>KbLightWidget</name>
    <message>
        <location filename="../../kblightwidget.ui" line="55"/>
        <source>Colors</source>
        <translation>Colours</translation>
    </message>
    <message>
        <location filename="../../kblightwidget.ui" line="74"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If enabled, the same colors will be displayed here as on the keyboard. If disabled, the base colors will be shown.&lt;/p&gt;&lt;p&gt;Note: The animation preview will be disabled when the window loses focus to preserve computation resources.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If enabled, the same colours will be displayed here as on the keyboard. If disabled, the base colors will be shown.&lt;/p&gt;&lt;p&gt;Note: The animation preview will be disabled when the window loses focus to preserve computation resources.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../../kblightwidget.ui" line="77"/>
        <source>Show animated</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kblightwidget.ui" line="201"/>
        <source>Change color...</source>
        <translation>Change colour...</translation>
    </message>
    <message>
        <location filename="../../kblightwidget.ui" line="111"/>
        <location filename="../../kblightwidget.cpp" line="108"/>
        <source>Click to select</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kblightwidget.ui" line="220"/>
        <source>New animation...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kblightwidget.ui" line="163"/>
        <source>Off</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kblightwidget.ui" line="248"/>
        <source>Animations</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kblightwidget.cpp" line="112"/>
        <source>1 zone selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kblightwidget.cpp" line="114"/>
        <source>1 key selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kblightwidget.cpp" line="117"/>
        <source>%1 zones selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kblightwidget.cpp" line="119"/>
        <source>%1 keys selected</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>KbModeEventMgr</name>
    <message>
        <location filename="../../kbmodeeventmgr.ui" line="17"/>
        <source>Mode Event Manager</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbmodeeventmgr.ui" line="190"/>
        <source>WARNING: Only windows under XWayland will be detected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbmodeeventmgr.ui" line="104"/>
        <source>Enabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbmodeeventmgr.ui" line="124"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbmodeeventmgr.ui" line="131"/>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbmodeeventmgr.ui" line="138"/>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbmodeeventmgr.ui" line="197"/>
        <source>Tip: Run xprop or xwininfo in a terminal and click on a window to find out its title and other values.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbmodeeventmgr.ui" line="45"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbmodeeventmgr.ui" line="58"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbmodeeventmgr.cpp" line="20"/>
        <source>Switch to mode &quot;%1&quot; when:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>KbProfileDialog</name>
    <message>
        <location filename="../../kbprofiledialog.ui" line="17"/>
        <source>Device Profiles</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbprofiledialog.ui" line="48"/>
        <source>Tip: Hold down Ctrl and click on multiple profiles to export</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbprofiledialog.ui" line="57"/>
        <source>Import</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbprofiledialog.ui" line="67"/>
        <source>Export</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbprofiledialog.cpp" line="66"/>
        <source>New profile...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbprofiledialog.cpp" line="116"/>
        <source>Rename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbprofiledialog.cpp" line="117"/>
        <source>Duplicate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbprofiledialog.cpp" line="118"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbprofiledialog.cpp" line="123"/>
        <source>Save to Hardware</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbprofiledialog.cpp" line="127"/>
        <source>Saving to hardware is not supported on this device.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbprofiledialog.cpp" line="129"/>
        <source>Move Up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbprofiledialog.cpp" line="132"/>
        <source>Move Down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbprofiledialog.cpp" line="157"/>
        <source>Delete profile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbprofiledialog.cpp" line="157"/>
        <source>Are you sure you want to delete this profile?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbprofiledialog.cpp" line="209"/>
        <location filename="../../kbprofiledialog.cpp" line="351"/>
        <source>ckb-next profiles (*.ckb)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbprofiledialog.cpp" line="312"/>
        <location filename="../../kbprofiledialog.cpp" line="361"/>
        <location filename="../../kbprofiledialog.cpp" line="369"/>
        <location filename="../../kbprofiledialog.cpp" line="375"/>
        <location filename="../../kbprofiledialog.cpp" line="387"/>
        <location filename="../../kbprofiledialog.cpp" line="397"/>
        <location filename="../../kbprofiledialog.cpp" line="456"/>
        <location filename="../../kbprofiledialog.cpp" line="464"/>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbprofiledialog.cpp" line="312"/>
        <source>An error occurred while exporting the selected profiles.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbprofiledialog.cpp" line="317"/>
        <source>Export Successful</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbprofiledialog.cpp" line="317"/>
        <source>Selected profiles have been exported successfully.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbprofiledialog.cpp" line="361"/>
        <source>Selected file is not a valid profile.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbprofiledialog.cpp" line="369"/>
        <source>Could not read %1.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbprofiledialog.cpp" line="375"/>
        <source>Package contains invalid metadata.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbprofiledialog.cpp" line="387"/>
        <source>Unsupported package selected. Please update ckb-next to import it.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbprofiledialog.cpp" line="397"/>
        <source>This profile was not created for the current device type.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbprofiledialog.cpp" line="418"/>
        <location filename="../../kbprofiledialog.cpp" line="467"/>
        <location filename="../../kbprofiledialog.cpp" line="490"/>
        <source>Profile Import</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbprofiledialog.cpp" line="419"/>
        <source>This profile was created for a %1 (%2)
but it is going to be imported to a %3 (%4).

You may need to manually add some keys to the appropriate animations.

Import Anyway?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbprofiledialog.cpp" line="456"/>
        <source>Selected package contains no valid profiles.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbprofiledialog.cpp" line="464"/>
        <source>Selected package contains some corrupt profiles.

An attempt will be made to import as many as possible.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbprofiledialog.cpp" line="468"/>
        <source>The following profiles will be imported.

• </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbprofiledialog.cpp" line="491"/>
        <source> already exists. Overwrite it?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbprofiledialog.cpp" line="516"/>
        <source>Import Successful</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbprofiledialog.cpp" line="516"/>
        <source>Profiles have been imported successfully.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>KbWidget</name>
    <message>
        <location filename="../../kbwidget.ui" line="174"/>
        <location filename="../../kbwidget.ui" line="254"/>
        <source>Lighting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbwidget.ui" line="214"/>
        <source>Tip: Drag+drop items to reorder. Right-click for menu.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbwidget.ui" line="222"/>
        <source>Binding</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbwidget.ui" line="286"/>
        <location filename="../../kbwidget.ui" line="308"/>
        <source>Performance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbwidget.ui" line="330"/>
        <location filename="../../kbwidget.ui" line="408"/>
        <source>Device</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbwidget.ui" line="370"/>
        <source>Wireless version:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbwidget.ui" line="577"/>
        <location filename="../../kbwidget.ui" line="590"/>
        <location filename="../../kbwidget.ui" line="636"/>
        <location filename="../../kbwidget.ui" line="649"/>
        <location filename="../../kbwidget.ui" line="734"/>
        <source>N/A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbwidget.ui" line="724"/>
        <source>Wireless Bootloader version:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbwidget.ui" line="421"/>
        <source>Serial Number:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbwidget.ui" line="613"/>
        <source>Layout:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbwidget.ui" line="449"/>
        <source>Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbwidget.ui" line="606"/>
        <source>Status:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbwidget.ui" line="626"/>
        <source>Battery:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbwidget.ui" line="683"/>
        <source>Enable system tray icon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbwidget.ui" line="698"/>
        <source>Bootloader version:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbwidget.ui" line="711"/>
        <source>Firmware version:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbwidget.ui" line="552"/>
        <location filename="../../kbwidget.cpp" line="402"/>
        <source>Check for updates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbwidget.ui" line="543"/>
        <source>Poll rate:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbwidget.ui" line="54"/>
        <source>Save to hardware</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbwidget.cpp" line="116"/>
        <source>Saving to hardware is not supported on this device.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbwidget.cpp" line="178"/>
        <source>This device does not support setting the poll rate through software.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbwidget.cpp" line="202"/>
        <source>Manage profiles...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbwidget.cpp" line="272"/>
        <source>Rename...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbwidget.cpp" line="273"/>
        <source>Duplicate</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbwidget.cpp" line="274"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbwidget.cpp" line="279"/>
        <source>Move Up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbwidget.cpp" line="285"/>
        <source>Move Down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbwidget.cpp" line="314"/>
        <source>Delete mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbwidget.cpp" line="314"/>
        <source>Are you sure you want to delete this mode?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbwidget.cpp" line="407"/>
        <source>Up to date</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbwidget.cpp" line="409"/>
        <source>Upgrade to v%1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbwidget.cpp" line="426"/>
        <source>Checking...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbwidget.cpp" line="434"/>
        <location filename="../../kbwidget.cpp" line="438"/>
        <location filename="../../kbwidget.cpp" line="441"/>
        <source>Firmware update</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbwidget.cpp" line="434"/>
        <source>&lt;center&gt;There was a problem getting the status for this device.&lt;br /&gt;Would you like to select a file manually?&lt;/center&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbwidget.cpp" line="438"/>
        <source>&lt;center&gt;There is a new firmware available for this device (v%1).&lt;br /&gt;However, it requires a newer version of ckb-next.&lt;br /&gt;Please upgrade ckb-next and try again.&lt;/center&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbwidget.cpp" line="441"/>
        <source>&lt;center&gt;Your firmware is already up to date.&lt;br /&gt;Would you like to select a file manually?&lt;/center&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbwidget.cpp" line="453"/>
        <source>Select firmware file</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbwidget.cpp" line="453"/>
        <source>Firmware blobs (*.bin)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbwidget.cpp" line="458"/>
        <source>Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbwidget.cpp" line="458"/>
        <source>&lt;center&gt;File could not be read.&lt;/center&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>KbWindowInfoModel</name>
    <message>
        <location filename="../../kbwindowinfomodel.cpp" line="6"/>
        <source>Case Sensitive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbwindowinfomodel.cpp" line="7"/>
        <source>Case Insensitive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbwindowinfomodel.cpp" line="8"/>
        <source>OR</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbwindowinfomodel.cpp" line="9"/>
        <source>AND</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbwindowinfomodel.cpp" line="10"/>
        <source>is</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbwindowinfomodel.cpp" line="11"/>
        <source>contains</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbwindowinfomodel.cpp" line="12"/>
        <source>starts with</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbwindowinfomodel.cpp" line="13"/>
        <source>ends with</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbwindowinfomodel.cpp" line="14"/>
        <source>Window Title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbwindowinfomodel.cpp" line="15"/>
        <source>Program Path</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbwindowinfomodel.cpp" line="16"/>
        <source>Instance Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbwindowinfomodel.cpp" line="17"/>
        <source>Class Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbwindowinfomodel.cpp" line="194"/>
        <source>Click</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbwindowinfomodel.cpp" line="197"/>
        <source>Click Click</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbwindowinfomodel.cpp" line="200"/>
        <source>Click Click Click</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../kbwindowinfomodel.cpp" line="203"/>
        <source>Good Job! Have a cookie 🍪</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>KeyAction</name>
    <message>
        <location filename="../../keyaction.cpp" line="101"/>
        <source>Unbound</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../keyaction.cpp" line="108"/>
        <location filename="../../keyaction.cpp" line="170"/>
        <source>(Unknown)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../keyaction.cpp" line="116"/>
        <source>Switch to previous mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../keyaction.cpp" line="119"/>
        <source>Switch to next mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../keyaction.cpp" line="121"/>
        <source>Switch to mode %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../keyaction.cpp" line="128"/>
        <source>DPI cycle up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../keyaction.cpp" line="130"/>
        <source>DPI cycle down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../keyaction.cpp" line="132"/>
        <source>DPI up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../keyaction.cpp" line="134"/>
        <source>DPI down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../keyaction.cpp" line="136"/>
        <source>Sniper</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../keyaction.cpp" line="140"/>
        <source>DPI: %1, %2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../keyaction.cpp" line="143"/>
        <source>DPI stage %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../keyaction.cpp" line="149"/>
        <source>Brightness up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../keyaction.cpp" line="152"/>
        <source>Brightness down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../keyaction.cpp" line="157"/>
        <source>Toggle Windows lock</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../keyaction.cpp" line="159"/>
        <source>Windows lock on</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../keyaction.cpp" line="161"/>
        <source>Windows lock off</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../keyaction.cpp" line="164"/>
        <source>Start animation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../keyaction.cpp" line="166"/>
        <source>Launch program</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../keyaction.cpp" line="168"/>
        <source>Send G-key macro</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>KeyWidgetDebugger</name>
    <message>
        <location filename="../../keywidgetdebugger.ui" line="14"/>
        <source>KeyWidgetDebugger</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../keywidgetdebugger.ui" line="40"/>
        <source>H</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../keywidgetdebugger.ui" line="50"/>
        <source>Model</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../keywidgetdebugger.ui" line="109"/>
        <source>Y</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../keywidgetdebugger.ui" line="126"/>
        <source>Lighting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../keywidgetdebugger.ui" line="136"/>
        <source>Show key selection surfaces</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../keywidgetdebugger.ui" line="146"/>
        <source>X</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../keywidgetdebugger.ui" line="153"/>
        <source>W</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../keywidgetdebugger.ui" line="160"/>
        <source>Layout</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../keywidgetdebugger.ui" line="167"/>
        <source>DevW</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../keywidgetdebugger.ui" line="174"/>
        <source>DevH</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>LegacyLightWidget</name>
    <message>
        <location filename="../../legacylightwidget.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../legacylightwidget.ui" line="47"/>
        <source>Hardware Lighting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../legacylightwidget.ui" line="61"/>
        <source>This device only supports lighting set in hardware. This means that in order to program your lighting settings you must perform the following steps on the keyboard:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../legacylightwidget.ui" line="71"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;ol style=&quot;margin-top: 0px; margin-bottom: 0px; margin-left: 0px; margin-right: 0px; -qt-list-indent: 1;&quot;&gt;&lt;li style=&quot; margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Select the mode to program the lights for by pressing the correct button (M1, M2 or M3).&lt;/li&gt;&lt;li style=&quot; margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Hold down the lighting programming button (to the left of the brightness button) until the ring around it starts flashing.&lt;/li&gt;&lt;li style=&quot; margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Press each key you want to toggle the light for.&lt;/li&gt;&lt;li style=&quot; margin-top:12px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Once finished, hold down the lighting programming button once more until the ring stops flashing.&lt;/li&gt;&lt;/ol&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MPerfWidget</name>
    <message>
        <location filename="../../mperfwidget.ui" line="44"/>
        <source>DPI</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mperfwidget.ui" line="63"/>
        <source>Low</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mperfwidget.ui" line="68"/>
        <source>Medium-low</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mperfwidget.ui" line="73"/>
        <source>Medium</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mperfwidget.ui" line="78"/>
        <source>Medium-high</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mperfwidget.ui" line="83"/>
        <source>High</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mperfwidget.ui" line="106"/>
        <location filename="../../mperfwidget.ui" line="361"/>
        <location filename="../../mperfwidget.ui" line="884"/>
        <location filename="../../mperfwidget.ui" line="901"/>
        <location filename="../../mperfwidget.ui" line="911"/>
        <source>Uncheck this box to skip the stage while moving up or down.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mperfwidget.ui" line="220"/>
        <location filename="../../mperfwidget.ui" line="242"/>
        <location filename="../../mperfwidget.ui" line="312"/>
        <location filename="../../mperfwidget.ui" line="527"/>
        <location filename="../../mperfwidget.ui" line="549"/>
        <location filename="../../mperfwidget.ui" line="679"/>
        <location filename="../../mperfwidget.ui" line="714"/>
        <source>Tip: alt+click to set all colors at once</source>
        <translation>Tip: alt+click to set all colours at once</translation>
    </message>
    <message>
        <location filename="../../mperfwidget.ui" line="328"/>
        <source>X Value:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mperfwidget.ui" line="479"/>
        <source>Y Value:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mperfwidget.ui" line="578"/>
        <source>Lift height:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mperfwidget.ui" line="768"/>
        <source>You can assign other DPIs in the Binding tab.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mperfwidget.ui" line="863"/>
        <source>Other:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mperfwidget.ui" line="877"/>
        <source>Sniper:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mperfwidget.ui" line="894"/>
        <source>DPI Stage:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mperfwidget.ui" line="921"/>
        <source>Angle snap</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mperfwidget.ui" line="947"/>
        <source>Movement</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mperfwidget.ui" line="979"/>
        <source>Use DPI indicator:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mperfwidget.ui" line="1002"/>
        <source>Indicator intensity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mperfwidget.ui" line="1040"/>
        <source>Independent X/Y states</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mperfwidget.ui" line="1099"/>
        <source>Copy to mode...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mperfwidget.cpp" line="350"/>
        <source>Copy performance settings to:</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MacroStringEditDialog</name>
    <message>
        <location filename="../../macrostringeditdialog.ui" line="17"/>
        <source>Edit Macro As String</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../macrostringeditdialog.cpp" line="21"/>
        <source>Macro string parse error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../macrostringeditdialog.cpp" line="21"/>
        <source>An error occured while parsing at column %1&lt;br&gt;&lt;br&gt;Please correct it and try again.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MacroTableModel</name>
    <message>
        <location filename="../../macrotablemodel.cpp" line="177"/>
        <source>None</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../macrotablemodel.cpp" line="179"/>
        <source>Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../macrotablemodel.cpp" line="187"/>
        <source>Unknown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../macrotablemodel.cpp" line="196"/>
        <source>You can not set a delay before the first key event</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../macrotablemodel.cpp" line="198"/>
        <source>To set a delay, please switch the delay mode to &quot;as typed&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../macrotablemodel.cpp" line="213"/>
        <source>Key</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../macrotablemodel.cpp" line="215"/>
        <source>Delay</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../macrotablemodel.cpp" line="358"/>
        <source>Delay is too large</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../macrotablemodel.cpp" line="365"/>
        <source>Max random delay is too large</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../macrotablemodel.cpp" line="369"/>
        <source>Max random delay is less or equal to the minimum</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../macrotablemodel.cpp" line="380"/>
        <source>Invalid key </source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../../mainwindow.ui" line="48"/>
        <source>Exit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.ui" line="56"/>
        <source>About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="135"/>
        <source>Restore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="136"/>
        <source>Quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="162"/>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="170"/>
        <source>The ckb-next daemon is not running. This program will &lt;b&gt;not&lt;/b&gt; work without it!</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="172"/>
        <source>Start it once with:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="174"/>
        <source>Enable it for every boot:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="176"/>
        <source>If &quot;Unit ckb-next-daemon.service is masked.&quot;, unmask it first and try again:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="179"/>
        <source>Start and enable it with:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="205"/>
        <source>The ckb-next daemon is not running.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="292"/>
        <source>Driver inactive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="299"/>
        <source>&lt;br /&gt;&lt;br /&gt;&lt;b&gt;Warning:&lt;/b&gt; Driver version mismatch (</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="299"/>
        <source>). Please upgrade ckb-next</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="299"/>
        <source>. If the problem persists, try rebooting.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="310"/>
        <source>&lt;br /&gt;&lt;b&gt;Warning:&lt;/b&gt; System Extension by &quot;Fumihiko Takayama&quot; is not allowed in Security &amp; Privacy. Please allow it and then unplug and replug your devices.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="312"/>
        <source>&lt;br /&gt;&lt;b&gt;Warning:&lt;/b&gt; Make sure ckb-next-daemon is allowed in Security &amp; Privacy -&gt; Input monitoring.&lt;br /&gt;Please allow for up to 10 seconds for the daemon restart prompt to show up after allowing input monitoring.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="322"/>
        <source>&lt;br /&gt;&lt;b&gt;Warning:&lt;/b&gt; The uinput module could not be loaded. If this issue persists after rebooting, compile a kernel with CONFIG_INPUT_UINPUT=y.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="325"/>
        <source>No devices connected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="328"/>
        <source>1 device connected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="330"/>
        <source>%1 devices connected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="361"/>
        <source>A new firmware is available for your %1 (v%2)
Would you like to install it now?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="377"/>
        <source>ckb-next will still run in the background.
To close it, choose Quit from the tray menu
or click &quot;Quit&quot; on the Settings screen.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="536"/>
        <source>Update to v</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../mainwindow.cpp" line="541"/>
        <source>Up to date</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ModeListTableModel</name>
    <message>
        <location filename="../../modelisttablemodel.cpp" line="76"/>
        <source>New mode...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ModeSelectDialog</name>
    <message>
        <location filename="../../modeselectdialog.ui" line="14"/>
        <source>Select Modes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../modeselectdialog.ui" line="53"/>
        <source>Select All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../modeselectdialog.ui" line="60"/>
        <source>Select None</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>QObject</name>
    <message>
        <location filename="../../main.cpp" line="68"/>
        <source>Starts in background, without displaying the main window.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../main.cpp" line="73"/>
        <source>Causes already running instance (if any) to exit.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../main.cpp" line="76"/>
        <source>Switches to the profile with the specified name on all devices.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../main.cpp" line="79"/>
        <source>Switches to the mode either in the current profile, or in the one specified by --profile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../main.cpp" line="82"/>
        <source>Delays application start for 5 seconds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../main.cpp" line="83"/>
        <source>Disables the daemon not running popup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../main.cpp" line="97"/>
        <source>Enables the KeyWidget debug window</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../main.cpp" line="299"/>
        <source>Downgrade Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../main.cpp" line="300"/>
        <source>Downgrading ckb-next will lead to profile data loss. It is recommended to click Cancel and update to the latest version.&lt;br&gt;&lt;br&gt;If you wish to continue, back up the settings file located at&lt;blockquote&gt;%1&lt;/blockquote&gt;and click OK.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ckbversionnumber.cpp" line="16"/>
        <source>N/A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../keymap.cpp" line="1763"/>
        <source>Eject</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../keymap.cpp" line="1765"/>
        <source>Power</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../keymap.cpp" line="1767"/>
        <source>Wheel Left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../keymap.cpp" line="1769"/>
        <source>Wheel Right</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RebindWidget</name>
    <message>
        <location filename="../../rebindwidget.ui" line="69"/>
        <source>Keyboard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="257"/>
        <source>T&amp;yping:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="203"/>
        <source>M&amp;edia:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="267"/>
        <source>Modi&amp;fier:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="183"/>
        <source>Miscellaneous:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="193"/>
        <source>&amp;Number pad:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="275"/>
        <source>Mouse</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="525"/>
        <source>Cha&amp;nge DPI:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="316"/>
        <source>4 (Back)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="321"/>
        <source>5 (Forward)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="415"/>
        <source>(Cycle Up)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="420"/>
        <source>(Cycle Down)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="425"/>
        <source>(Up)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="430"/>
        <source>(Down)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="435"/>
        <source>Sniper</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="465"/>
        <source>Custom:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="396"/>
        <location filename="../../rebindwidget.ui" line="557"/>
        <source>Left</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="401"/>
        <location filename="../../rebindwidget.ui" line="562"/>
        <source>Right</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="567"/>
        <source>Middle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="386"/>
        <location filename="../../rebindwidget.ui" line="910"/>
        <source>Up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="391"/>
        <location filename="../../rebindwidget.ui" line="915"/>
        <source>Down</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="535"/>
        <source>Standard button:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="518"/>
        <source>DPI is only available for mice.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="357"/>
        <source>Wheel:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="294"/>
        <source>Special button:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="634"/>
        <source>Animation</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="703"/>
        <source>Stop on key release</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="710"/>
        <source>Restart every time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="752"/>
        <source>Start a&amp;nimation on keypress:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="766"/>
        <source>Special</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="888"/>
        <source>Switch to mode:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="946"/>
        <location filename="../../rebindwidget.ui" line="1001"/>
        <source>Wrap-around</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="923"/>
        <source>Wi&amp;ndows lock:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="844"/>
        <source>Toggle</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="849"/>
        <source>On</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="854"/>
        <source>Off</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="878"/>
        <source>Brightness:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="803"/>
        <source>(Previous)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="808"/>
        <source>(Next)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="1025"/>
        <source>Program</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="1089"/>
        <source>Launch program on key press:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="1082"/>
        <source>Launch program on key release:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="1131"/>
        <location filename="../../rebindwidget.ui" line="1163"/>
        <source>Single instance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="1145"/>
        <location filename="../../rebindwidget.ui" line="1177"/>
        <source>Run indefinitely</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="1150"/>
        <source>Stop on release</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="1155"/>
        <location filename="../../rebindwidget.ui" line="1182"/>
        <source>Stop on re-press</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="1197"/>
        <source>Macro</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="1229"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="1245"/>
        <source>Preview</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="1340"/>
        <source>This device only</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="1345"/>
        <source>All ckb-next devices</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="1350"/>
        <source>All keyboards</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="1371"/>
        <source>Record from:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="1378"/>
        <source>Keystroke delay:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="1397"/>
        <source>Events</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="1432"/>
        <source>Edit as string</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="1525"/>
        <location filename="../../rebindwidget.cpp" line="803"/>
        <source>Start Recording</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="1551"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="1577"/>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="1296"/>
        <source>Set delay to default values: 20us up to 15 chars, 200us above</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="1312"/>
        <source>Delay will be the same as it was recorded</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="1299"/>
        <source>de&amp;fault</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="1315"/>
        <source>as t&amp;yped</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="1596"/>
        <source>Clear</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="1626"/>
        <source>Unbind</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="1633"/>
        <source>Reset to Default</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="1640"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.ui" line="1647"/>
        <source>Apply</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.cpp" line="84"/>
        <source>Tip: use xdg-open to launch a file or directory. For instance, to open your home folder:
  xdg-open </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.cpp" line="456"/>
        <source>Key %1 (%2) is pressed but never released.
This will result in the key being pressed by the macro until you manually press the key itself and release it.

Are you sure you want to continue?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.cpp" line="459"/>
        <source>Key %1 (%2) is released but never pressed.
This will have no observable effect unless the key is held down manually or by another macro.

Are you sure you want to continue?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.cpp" line="462"/>
        <source>Macro warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.cpp" line="804"/>
        <source>Click Apply or manually edit the events.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.cpp" line="842"/>
        <source>Unknown key combination pressed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.cpp" line="842"/>
        <source>An unknown key combination (%1, %2) has been pressed.
Make sure your keyboard layout is set to English - United States while recording macros.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.cpp" line="852"/>
        <source>Stop Recording</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.cpp" line="853"/>
        <source>Type your macro and press Stop Recording when finished.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.cpp" line="860"/>
        <source>Click Start Recording or manually edit the events.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.cpp" line="928"/>
        <source>&quot;Record from all keyboards&quot; is only recommended if you do not have a keyboard managed by ckb-next.
It currently only functions with an English - United States keyboard layout.
Make sure your keyboard is switched to it before recording.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../rebindwidget.cpp" line="931"/>
        <source>Record from all keyboards</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SettingsWidget</name>
    <message>
        <location filename="../../settingswidget.ui" line="61"/>
        <source>No devices connected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../settingswidget.ui" line="143"/>
        <source>Modifier keys</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../settingswidget.ui" line="334"/>
        <source>These will override the keyboard profile. See &quot;Binding&quot; tab for more settings.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../settingswidget.ui" line="375"/>
        <source>Application</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../settingswidget.ui" line="389"/>
        <source>ckb-next will be started when you log in to your computer.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../settingswidget.ui" line="392"/>
        <source>Start ckb-next at login</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../settingswidget.ui" line="399"/>
        <source>You will be notified when new firmware versions are available. You&apos;ll have the option to install them immediately or wait until later.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../settingswidget.ui" line="402"/>
        <source>Check for new firmware automatically</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../settingswidget.ui" line="412"/>
        <source>Check for ckb-next updates on startup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../settingswidget.ui" line="422"/>
        <source>Enable this only if you have a high DPI monitor and the ckb-next window shows up too small.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../settingswidget.ui" line="425"/>
        <source>Enable HiDPI Scaling</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../settingswidget.ui" line="439"/>
        <location filename="../../settingswidget.cpp" line="197"/>
        <source>Generate report</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../settingswidget.ui" line="464"/>
        <source>Check for updates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../settingswidget.ui" line="471"/>
        <location filename="../../settingswidget.cpp" line="286"/>
        <source>Uninstall ckb-next</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../settingswidget.ui" line="589"/>
        <source>About Qt</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../settingswidget.ui" line="596"/>
        <source>Quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../settingswidget.cpp" line="92"/>
        <source>The ckb-next development team</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../settingswidget.cpp" line="96"/>
        <source>&lt;br/&gt;Special thanks to &lt;a href=&quot;https://github.com/tekezo&quot; style=&quot;text-decoration:none;&quot;&gt;tekezo&lt;/a&gt; for &lt;a href=&quot;https://github.com/tekezo/Karabiner-VirtualHIDDevice&quot; style=&quot;text-decoration:none;&quot;&gt;VirtualHIDDevice&lt;/a&gt;.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../settingswidget.cpp" line="197"/>
        <source>This will collect software logs, as well as information about the Corsair devices in your system.

Make sure they are plugged in and click OK.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../settingswidget.cpp" line="211"/>
        <location filename="../../settingswidget.cpp" line="231"/>
        <source>Error executing ckb-next-dev-detect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../settingswidget.cpp" line="211"/>
        <source>An error occurred while trying to execute ckb-next-dev-detect.
File not found or not executable.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../settingswidget.cpp" line="216"/>
        <source>Generating Report</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../settingswidget.cpp" line="227"/>
        <source>An error occurred while trying to execute ckb-next-dev-detect.

</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../settingswidget.cpp" line="230"/>
        <source>Return code %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../settingswidget.cpp" line="236"/>
        <source>Select output directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../settingswidget.cpp" line="239"/>
        <source>Report generated successfully</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../settingswidget.cpp" line="239"/>
        <source>The report has been generated successfully.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../settingswidget.cpp" line="249"/>
        <source>Error writing report</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../settingswidget.cpp" line="249"/>
        <source>Could not write report to the selected directory.
Please pick a different one and try again.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../settingswidget.cpp" line="268"/>
        <source>Checking...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../settingswidget.cpp" line="286"/>
        <source>WARNING: Clicking OK will uninstall ckb-next and any older versions of the software from your system.

Your settings and lighting profiles will be preserved.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../settingswidget.cpp" line="298"/>
        <source>Please restart ckb-next</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../settingswidget.cpp" line="298"/>
        <source>Please click the Quit button and restart ckb-next for the changes to take effect.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
