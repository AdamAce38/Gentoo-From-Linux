#include "ckbmainbackgroundcolour.h"
#include <QColor>

QColor CkbMainBackgroundColour::c;
const QColor CkbMainBackgroundColour::unknown(Qt::white);
