#ifndef IDLETIMER_H
#define IDLETIMER_H

class IdleTimer
{
public:
    static int getIdleTime();
    static bool isWayland();
};

#endif // IDLETIMER_H
