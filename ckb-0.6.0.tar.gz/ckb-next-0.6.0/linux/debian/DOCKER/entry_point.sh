#!/usr/bin/env bash
exec "$@"
