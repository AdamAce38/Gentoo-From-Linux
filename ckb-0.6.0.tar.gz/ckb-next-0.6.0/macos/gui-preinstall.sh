#!/usr/bin/env bash
# old GUI
killall -9 ckb
# new GUI
killall -9 ckb-next
exit 0
