#!/usr/bin/env bash
sudo launchctl load -w /Library/LaunchDaemons/org.ckb-next.daemon.plist
exit 0
