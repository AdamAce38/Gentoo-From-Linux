# frozen_string_literal: true

module Roadie
  VERSION = "5.2.1"
end
