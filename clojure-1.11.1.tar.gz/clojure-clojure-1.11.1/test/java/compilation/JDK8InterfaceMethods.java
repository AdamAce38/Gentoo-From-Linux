package compilation;

public interface JDK8InterfaceMethods {
    public static long staticMethod0(long v) { return v; }
    public static String staticMethod1(String s) { return s; }
    public static boolean staticMethod2(boolean b) { return b; }
}
