#!/bin/sh
autoreconf -v --install --symlink --force || exit 1
