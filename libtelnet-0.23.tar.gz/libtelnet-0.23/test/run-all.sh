#!/bin/sh

DIR=$(dirname "$0")
"$DIR/run-test.sh" "$DIR/"*.test
