/* Defining the flags that are used inside rotate() */
#define ROTATE_RIGHT_FLAG	1

void rotate (int rotor, char *rotar, char flags);
