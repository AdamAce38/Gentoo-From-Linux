#define wave_device_available false

