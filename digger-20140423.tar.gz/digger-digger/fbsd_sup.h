#include <stdio.h>

void strupr(char *);
void catcher(int);
#define FIXME(args) fprintf(stderr, "%s\n", args)

