void dobags(void);
int16_t getnmovingbags(void);
void cleanupbags(void);
void initbags(void);
void drawbags(void);
bool pushbags(int16_t dir,int *clfirst,int *clcoll);
bool pushudbags(int *clfirst,int *clcoll);
int16_t bagy(int16_t bag);
int16_t getbagdir(int16_t bag);
void removebags(int *clfirst,int *clcoll);
bool bagexist(int bag);

