extern bool wave_device_available;

