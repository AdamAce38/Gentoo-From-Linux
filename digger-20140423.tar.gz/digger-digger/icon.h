extern SDL_Color IconPalette[256];
extern uint8_t Icon[];

