void gettitle(unsigned char *);

