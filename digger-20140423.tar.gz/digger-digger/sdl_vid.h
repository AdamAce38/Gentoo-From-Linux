#ifndef SDL_VID_H
#define SDL_VID_H

extern uint32_t addflag;
void doscreenupdate(void);
void switchmode(void);

#endif /* SDL_VID_H */
