#include "def.h"

bool initsounddevice(void)
{
	FIXME("initsounddevice called");
	return(0);
}

bool setsounddevice(int base, int irq, int dma, uint16_t samprate, uint16_t bufsize)
{
	FIXME("setsounddevice called");
	return(0);
}

void killsounddevice(void)
{
	FIXME("killsounddevice called");
}

