// Copyright (c) Tailscale Inc & AUTHORS
// SPDX-License-Identifier: BSD-3-Clause

//go:build !plan9

// +kubebuilder:object:generate=true
// +groupName=tailscale.com
package v1alpha1
