# Security Policy

## Reporting a Vulnerability

You can report vulnerabilities privately to
[security@tailscale.com](mailto:security@tailscale.com). Tailscale
staff will triage the issue, and work with you on a coordinated
disclosure timeline.
