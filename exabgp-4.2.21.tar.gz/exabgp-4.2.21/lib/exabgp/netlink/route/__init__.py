from exabgp.netlink import NetLinkError


class NetLinkRouteError(NetLinkError):
    pass
