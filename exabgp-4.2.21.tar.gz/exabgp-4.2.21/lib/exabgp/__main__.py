from exabgp.application.main import main

if __name__ == '__main__':
	main()