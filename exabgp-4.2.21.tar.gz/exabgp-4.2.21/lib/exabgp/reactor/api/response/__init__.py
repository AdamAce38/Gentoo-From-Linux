class Response(object):
    from exabgp.reactor.api.response.text import Text
    from exabgp.reactor.api.response.json import JSON
