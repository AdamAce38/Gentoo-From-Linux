Version 4.0.10
 * Feature: Add decoding for Mac Mobility

Version 4.0.9
 * Change: re-enabled multiple source/destination in flow
 * Fix: forward port of #845, send state down messages on peer removal
   orginal patch: Andre Kampert
 * Feature: add != test of flows
   patch by: dhammika
 * Fix: Read pipename from env file rather than using default 
   patch by: Craig Milne
 * Fix: using teardown could crash exabgp
   patch by: Matthias Wichtlhuber
 * Fix: use of label and rd with announce attributes

Version 4.0.8
 * Fix: PEP-0479

Version 4.0.7
 * Feature: added prefix for ip-reachability-tlv
   patch: Tinus Flagstad
 * Feature: forewardport #840 (RFC 7674 - Support redirect traffic to a VRF encoded as 4-octet AS)
   original patch by: Omri Matitiau
 * Fix: handling of processes when the configuration reload fails
   patch by: Malcolm Dodds
 * Fix: healthcheck, remove options.ip_setup in dynamic ip management
   patch by: Ahmet Demir
 * Fix: present unknown RD as hexadecimal string (previous representation could not be JSON parsed)
   reported by: Jitoxxx
 * Fix: fix permissions of systemd service files
   patch by: Malcolm Dodds
 * Fix: properly show connection as down in the cli
   reported by: chantra
 * Fix: JSON encoding for route-refresh
   reported by: nfz1
 * Fix: Prevent busy spinning in multiple code path (including when a peer closed the connection on us)
   reported by: chantra
 * Fix: busy spinning when the peer went away
   reported by: chantra
 * Improvement: many fix to QA code
   patch by: Vincent Bernart
 * Improvement: exit with error code 0 on SIGTERM
   reported by: Johan Guldmyr
 * Fix: fix neighbor CLI to match against peer address
   patch by: Malcolm Dodds
 * Fix: fix parsing of labelled default IP route
   patch by: Thomas Morin
 * Fix: checks for consumption of data in bgp-ls
   patch by: he32
 * Fix: support latest python3 (with async as keyword)

Version 4.0.6
 * Fix: default network for IPv6 is 128 .. not 32
   patch by: Donatas Abraitis
 * Fix: issue when parsing AS_SET with '['
   patch by: Kyle Birkeland
 * Fix: parding of MD5 string in configuration
   patch by: Kyle Birkeland
 * Fix: bug generating flows with redirect
   reported by: jasonsdn
 * Fix: decoding of routes with label, the number of label to decode was badly calculated
 * Fix: allow digit as first letter of hostname
   reported by: Vascko
 * Fix: Fix strip default attributes from withdrawals
   patch by: dhammika
 * Fix: make sure routes are removed on SIGUSR1
   patch by: Malcolm Dodds
 * Fix: Fix RPM spec files
   patch by: Malcolm Dodds
 * Change: if exabgp is installed in /usr, the configuration will be looked into /etc (and not /usr/etc)
   request by: Vascko

Version 4.0.5
 * Fix: bad encoding of flow rules with &
   reported by: Iwase Yusuke

Version 4.0.4
 * Feature: draft draft-ietf-idr-bgp-extended-messages-24 support (option capability extended-message)
 * Fix: do not tear down session if not enough space is available to pack an NLRI after attribute but treat-as-withdraw
 * Fix: BGP-LS parsing issue when using Python3
 * Fix: Invalid JSON when parsing unknown OPEN capabilities
 * Fix: The way we iterated over the action queue could cause out of order executions
 * Fix: problem with encoding of Notification messages
 * Fix: L being added to number with %ld on some platform and version on Python 
 * Fix: fix string representations with MPLS raw labels
   patch by: Thomas Morin
 * Feature: Add a systemd exabgp instance service
   patch by: jmauro

Version 4.0.3
 * Fix: MD5 issue with python3
 * Fix: control of logging for timer events
 * Fix: possible packet data not being reset in update generation
 * Fix: could miss API command if sent at faster than read rate
 * Fix: bad json encoding
   reported by: Tyson Clugg
 * Fix: missing L2VPN/EVPN to next-hop sizing check
   patch by: jsynack
 * Fix: allow an hold-time of zero
   patch by: andrius-adamavicius
 * Fix: printing of RT
   reported by: abreu75
 * Fix: allow a single KA for hold-time of zero
   reported by: andrius-adamavicius
 * Fix: api report writing the word neighbor twice
   patch by: chantra
 * Fix: setup.py script functions not working
   patch by: aabdnn
 * Fix: the API would spin on EOF (issue #704)
   patch by: chantra
 * Fix: exabgp.tcp.once was not exiting
   patch by: dhammika
 * Fix: api poller slow down
   patch by: dhammika
 * Fix: EVPN decoding on type 4 NLRI
   patch by: kvlangenhove

Version 4.0.2
 * Feature: exabgpcli
 * Feature: draft-ietf-idr-link-bandwidth-06
 * Feature: colored output
 * Feature: script to use as flow-spec receiver for Cumulus Linux
 * Feature: added all families to announce { ipv4 {} ipv6 {} }
 * Feature: API to clear RIB
 * Feature: Per family negotiation of Add-Path ( add-path section, like family )
 * Feature: add --sink and --echo to test bgp daemon
 * Feature: include negotiated information with update / packets API messages
 * Feature: allow multiple inheritance
 * Feature: new "functional" program for functional testing with many new goodies
 * Fix: BGP-LS encoding
   patch by: Evelio Vila
 * Fix: Issue with received timer
 * Fix: internal API using named FIFO
 * Fix: add support for netbsd for heathcheck
 * Fix: issue with api inheritance
 * Fix: several issue with BGP-LS
 * Fix: issues with NLRI decoding (bug introduced between 4.0.0 and 4.0.1)
 * Fix: various
 * Change: BGPLS with BGP-LS
 * Change: rewrote may part of the code (reactor/async, log, API, ...)
 * Change: renamed exabgp.api.file to exabgp.api.cli - now a boolean, enabled by default
 * Change: --folder option now --root, and not need when installed in /
 * Change: deprecated route-distinguisher only rd will now be parsed
 * Change: ASN in JSON are now correctly expressed as numbers and not strings

Version 4.0.1
 * Change: makes python3 the default interpreter
 * Change: major change to log output format
 * Change: refactor the core for much faster session establishment
 * Change: JSON format for extended-community now reports both the value and decoded string
 * Change: new section: announce { ipv4 { unicast ...; multicast ...; } } same syntax as route ...;
 * Change: new section: announce { ipv6 { unicast ...; multicast ...; } } same syntax as route ...;
 * Fix: correcly parse single element flow rule
   reported by: Christoph Loibl
 * Fix: much faster session establishment
 * Feature: allow to disable command acknowledgement via environment
   reported by: nidotech
 * Feature: https://tools.ietf.org/html/draft-ietf-idr-bgp-prefix-sid-05
   patch by: Evelio Vila
 * Feature: added a new API message "negotiated" which gives the negotiated feature of the session
 * Feature: added a new API message "fsm" which gives the BGP state machine information
 * Feature: added a new API message "signal" which inform of the signals received by ExaBGP
 * Feature: it is now possible to use ip/netmask as notation for neighbor
 * Feature: local-as can be set to "auto", to auto-setup an iBGP session using the OPEN's ASN
 * Feature: Allow binding to multiple global IP addresses
 * Feature: Add --validate option to check configuration
 * Feature: Added option to save ADJ-RIB-IN
 * Fix: Handle MD5 authentication on global IP addresses
 * Fix: profiling code
 * Fix: issue when waiting on a TCP connection then closed
 * Fix: parsing flowspec port
 * Fix: correctly inherit API data when using templated neighbors
 * Fix: hexstring function
 * Fix: VPLS JSON decoding
 * Fix: Notification when encountering issues
 * Fix: Many fixes to make sure all tests pass again

Version 4.0.0
 * Feature: add support for interface-set for BGP flowspec routes
 * Change: the configuration format is not compatible with ExaBGP 3.x
 * Change: BMP support is deprecated for BGP-LS
 * Change: move and install healthcheck in bin
 * Change: removed old environment support ( DEBUG_* )
 * Change: configuration logging is now disabled by default
 * Change: all API commands returns an 'done' or 'error' message after running
   patch by: Jérôme Marteaux
 * Change: when API commands are failing, returns a 'error' message
   patch by: Jérôme Marteaux
 * Change: md5 is now called md5-password
 * Change: always use neighbor local address for next-hop self (and not router-id for on IPv4 connections)
 * Feature: support for large communities (-03)
   patch by: Job Snijders
 * Feature: add support for upstart
   patch by: Pierre-Yves Kerembellec
 * Feature/Fix: Port of bagpipe EVPN code
   patch by: Thomas Morrin
 * Feature: EVPN RT5 support
   patch by: Diego Garcia del Rio
 * Feature: Can use numerical values for Flow elements
   requested by: jpan613 (on github)
 * Feature: show route (extensive) can take a neighbor as parameter
   requested by: jtkdpu
 * Feature: allow to run exabgp from python -m exabgp
 * Feature: support for BGP-LS decoding
 * Change: ExaBGP is now run as user/group exabgp/exabgp with the systemd service file.
   patch by: Vincent Bernat
 * Change: Update are now grouped by default
 * Change: Configuration format
    - all deprecated name remove
    - no more process group within neighbor
 * Change: Change the API configuration syntax and format
    - default changed
       * JSON is now the default API encoder
       * JSON now use high resolution time
    - syntax changes to the Text API format
       * added direction of message
       * change received/sent to receive/send
       * add extra informatiom (detail here)
    - syntax changes to the JSON API format
       * add direction to object
       * pid, ppid are now numbers and not string
       * remove deprecated 'ip' from neighbor
       * rename 'restart flags' to be 'restart-flags'
       * rename 'address family flags' to be 'address-family-flags'
       * format change for notification and shutdown message
       * VPLS endpoint, base, offset, and size are now numbers and not strings
       * nlris are now a list and not nrli indexed object
       * ipv4/ipv6 nlri without label or rd are now a list of nlri (as string) and not key to empty objects
       * nlris with label or rd are returned as a list of objects
 * Change: remove all ExaBGP 2.0 compatibily
 * Change: remove all ExaBGP 2.0 compatibily environment variables
 * Change: include time when we log to file (and not application)
 * Change: ttl-security is now called outgoing-ttl
 * Change: the reactor does not exit if there is no peer configured
   patch by: Jordan Gedney
 * Change: API format for BGP flowspec updates, flowspec updates is now a list of dicts where each dict contains a single flowspec rule
   patch by: Stacey Sheldon (Corsa)
 * Fix: JSON reporting of VPLS ( endpoint, base, offset, and size were mixed up during printing )
 * Fix: Do shutdown when waiting for a new connection to a peer
 * Fix: Bad ASN enconding when ASN4 is not negotiated
   reported by: Orangefish on github
 * Fix: Shutdown when waiting for a new outgoing connection to establish
 * Fix: JSON counter
   reported by:
 * Fix: JSON flow printing for source and destination
 * Fix: Do not always locate exabgp.env
   reported by: Florian Obser
 * Fix: Correctly drop root privileges
   reported by: Florian Obser
 * Fix: validation of flow routes
 * Fix: Python differences between Unix version breaking process forking
   reported by: Raphael Mazelier
 * Fix: Allow = with flowspec singleton
   reported by: Pavel Odintsov
 * Fix: selfcheck feature
 * Fix: do not refuse to parse multiple MP attributes in an update
 * Fix: possible bug with attribute information due to caching
   reported by: Colin Petrie
 * Fix: issue with unknown capabilities
   reported by: Sandy Breeze
 * Fix: notification messages were not passed to the API
   reported by: Florian Obser
 * Fix: ExaBGP was crashing if it could not write to a logfile
   reported by: Pavel Odintsov
 * Fix: only grouping IPv4 routes
   reported by: Sergey Viuchny (stroboscope)
 * Fix: Flow redirect to nexhop encoding
   reported by: Mickael Marchand (Thank you to Peng Xiao and Nicolas Fevrier for their help)
 * Fix: remove useless PYTHONPATH in sbin/exabgp
   reported by: Håvard Eidnes
 * Fix: add semi-colon in syslog ouput
 * Fix: parsing multiple NLRI in flow routes
   reported by: Dmitry Onuchin
 * Fix: bad parsing of flow routes / missing support for exact bit matches
   reported by: hengchai
   reported by: Dmitry Onuchin
 * Fix: reading large buffered data from helper process caused truncation
   reported by: qqTYXn7
 * Fix: better --version output
   patch by: Ebben Aries
 * Fix: mistakenly made a function private breaking some ASN4 code path
   reported by: Victor Sudakov
 * Fix: the ttl-security parameter didn´t really work. Fixed for outgoing connections now.
   patch by: Borja Marcos
 * Fix: AS4Path Message Registration
   patch by: Adam Twardowski
 * Fix: ASN4 boundary off by one
 * Fix: Bad peer IP when using show routes
   patch by: Wayne Tucker
 * Fix: broken route-refresh command
   reported by: Bryan Schwerer
 * Fix: handle mulitple bits of flags in flow routes (Fragments and TCPFlags)
   reported by: Pavel Odintsov
 * Fix: does not use label information when handling the RIB
   reported by: choisuibun
 * Fix: healthcheck removes added IPs on exit
   patch by: Ben Agricola
 * Fix: Bad encoding of capability when multiple families are used for add-path
   reported by: Alexander Bespalov
 * Fix: support non ASN4 use of AS_TRANS (AS23456)
   reported by: Todd Crane
 * Fix: the json format would not allow normal parsers to extract all the NLRIs
   reported by: Marco Marzetti
 * Feature: Allow single line flow route
   requested by: Pavel Odintsov
 * Feature: add support for rpm packaging
   patch by: Arun Babu Neelicattu
 * Feature: manually sending EOR
   pach by: Charles Ng
 * Feature: add per neighbor connection port
   requested by: dbarrosop
 * Feature: support MIN_TTL for incoming connection (for OS with support - FreeBSD)
   requested by: Borja Marcos
 * Feature: md5-ip allows to override local-address for the MD5 calculations
   requested by: Bryan Benson
 * Feature: allow setting process umask via exabgp.daemon.umask
   patch by: Bryan Le Gear
 * Change: Update syslog message format
   patch by: Brian Johnson
 * Fix: flush route api
   patch by: Brian Johnson
 * Feature: Add 'show neighbor status' api
   patch by: Brian Johnson
 * Fix: Broken EOR printing
   reported by: Pier Carlo Chiodi
 * Fix: Allow asn4 peer to speak with asn2 only peer
   patch by: Brian Johnson
 * Fix: ExaBGP was crashing when serializing BGP flowspec updates
   patch by: Stacey Sheldon (Corsa)
 * Fix: API encoding of IPv4 Unicast EOR messages were being encoded as NLRI updates
   patch by: Stacey Sheldon (Corsa)
 * Fix: Update RIB cache families on configuration reload
   patch by: Brian Johnson
 * Change: Update show neighbors output to be parseable by configuration parser
   patch by: Brian Johnson
 * Feature: Allow configuration parsing of a string or a file
   patch by: Brian Johnson
 * Fix: Do not add IPv4/unicast family unless specifically configured
   patch by: Brian Johnson
 * Fix: ParseAPI should always use the class version of the _built dict
   patch by: Brian Johnson
 * Fix: Off by one error when getting message type for send-* api
   patch by: Brian Johnson
 * Fix: md5-ip config option is an ip address not a router_id
   patch by: Brian Johnson
 * Feature: Show routes by type (static/flow/l2vpn)
   patch by: Brian Johnson
 * Fix: Rewrite Update.messages so it will only include one MP_REACH or MP_UNREACH per UPDATE
   patch by: Brian Johnson
 * Fix: Remove a peer's RIB cache when it is deleted from the config file
   patch by: Brian Johnson
 * Feature: Allow md5 password to be base64 encoded
   patch by: Brian Johnson

Version 3.4.19
 * Add: IPv6 nlri-mpls to list of enabled protocol (was missing)
   requested by: adrian62
 * Fix: encoding of Flow Label requiring more than 2 bytes
   reported by: BLAKEMMM
 * Fix: decoding of capability (was potentially over reading)
 * Fix: trace when trying to access PID file and this is not allowed
   reported by: George Shuklin
 * Fix: Remove a peer's RIB cache when it is deleted from the config file
   patch by: Brian Johnson
 * Fix: do not crash the reactor when an invalid IP is passed via the API
   reported by: Yevgeniy Ovsyannikov
 * Fix: bad defintion of Flow for ICMPType, ICMPCode and Fragment
   reported by: Christoph Loibl
 * Feature: allow add-path for mpls-vpn
   reported by: adrian62
 * Change: Backported setup.py from master
 * Feature: added SRPMS for exabgp
   patch by: Leonardo Amaral

Version 3.4.18
 * Backport: backhole community (RFC 7999)
   original patch by: Job Snijders
 * Fix: Configuration parser does not accept configs without neighbors.
   patch by doddt
 * Fix: 'connect' keyword is now also allowed in neighbor scope
   patch by: Stacey Sheldon (Corsa)
 * Fix: removing protocol auto-cleanup (it should never be called and seems to cause a CG issue)
   reported by: Colin Petrie
 * Change: default to a 0 offset for ipv6 flowspec source/destination match
   patch by: Brian Johnson
 * Fix: Better PID file handling
   reported by: Ben Agricola
 * Fix: Update RIB cache families on configuration reload
   patch by: Brian Johnson
 * Fix: Backport fix on SIGUSR2 (restarting process not needing to be)
   patch by: Shawn Zhou
 * Change: group-updates now generates one UPDATE per address family (and not one per NLRI for non IPv4)
   patch by: Brian Johnson

Version 3.4.17
 * Fix: does not accept IPv6 as router-id
   reported by: yuriya
 * Fix: JSON output for flow routes with rd
   reported by droon5
 * Fix: Fix Path-Information
 * Fix: Bad encoding of capability when multiple families are used for add-path
   reported: by Alexander Bespalov
 * Fix: support non ASN4 use of AS_TRANS (AS23456)
   reported by: Todd Crane
 * Fix: do not exit when we can not accept incoming connection
   reported by: Pavel Batkov
 * Fix: quote where not escaped in JSON reason field
   reported by: Rob Barnes
 * Fix: decoding of IPv6 flow routes
   reported by: stoffi92
 * Fix: decoding of Graceful Restart Capability
   patch by: florinz
 * Fix: ASN4 encoding
   patch by: Shu Sugimoto and Eiichiro Watanabe
 * Change: Run without even peers configured
   patch by: Jordan Gedney
 * Fix: JSON encoding of updates without NLRIs
   patch by: Dhammika Pathirana
 * Fix: Possible race conditions in api handling
   patch by: Brian Johnson
 * Feature: Add 'show neighbor status' api
   patch by: Brian Johnson
 * Fix: flush route api
   patch by: Brian Johnson
 * Fix: Allow asn4 peer to speak with asn2 only peer
   patch by: Brian Johnson
 * Fix: only one MP NLRI is allow per UPDATE
   reported by: subsecond
 * Change: configuration output does not includes ':' anymore
   patch by: doddt
 * Change: syslog format changed to be in line with other application
   patch by: Brian Johnson

Version 3.4.16
 * Feature: allow users to decide if processes must be run before or after we drop privileges
   requested by: Ben Agricola
 * Fix: correctly look in /etc/exabgp for programs to run when the path is relative
   reported by: Vincent Bernat
 * Fix: missing handler for NOTIFICATION
   patch by: minglvyy

Version 3.4.15
 * Fix: the ttl-security parameter didn´t really work. Fixed for outgoing connections now.
   patch by: Borja Marcos
 * Fix: configuration leak between processes for neighbor-changes and send-packets
   reported by: spakka
 * Feature: add per neighbor connection port
   requested by: dbarrosop
 * Fix: ASN4 boundary off by one
 * Fix: Bad peer IP when using show routes
   patch by (backported): Wayne Tucker
 * Fix: Missing next-hop in the text api
   reported by: Lisa Roach
 * Fix: broken route-refresh command
   reported by: Bryan Schwerer
 * Fix: wrongly announcing connection issue with peer on the API
   reported by: Bryan Schwerer

Version 3.4.14
 * Change: This version does not exists
 * Change: we modified some pypi related code and failed at first
 * Change: pypi does not let you modify releases

Version 3.4.13
 * Fix: add semicolon in syslog entry so it can be parsed by tools
 * Fix: duplication of message following helper process death
   reported by: spakka
 * Fix: death of helper program would lead to BGP session drop
   reported by: spakka
 * Fix: mistakenly made a function private breaking some ASN4 code path
   reported by: Victor Sudakov
 * Feature: manual eor
   patch by: Charles Ng

Version 3.4.12
 * Fix: issue with unknown capabilities
   reported by: Sandy Breeze
 * Fix: notification messages were not passed to the API
   reported by: Florian Obser
 * Fix: transitivity on extended community
   patch by: Thomas Morin
 * Fix: bad reporting of VPLS information in JSON
 * Fix: wrong SAFI on MPLS routes
   reported by: Hideaki HAYASHI
 * Fix: bad route comparaison
   reported by: Alvaro Pereira
 * Fix: decoding of Update
 * Fix: Flow redirect to nexhop encoding
   reported by: Mickael Marchand (Thank you to Peng Xiao and Nicolas Fevrier for their help)
 * Fix/Improve: JSON for flow spec
 * Fix/Improve: redirect-to-nexthop
   reported by: Mickael Marchand

Version 3.4.11
 * Change: install healthcheck in bin
 * Fix: Do shutdown when waiting for a new connection to a peer
 * Fix: Bad ASN enconding when ASN4 is not negotiated
   reported by: Orangefish on github
 * Fix: Shutdown when waiting for a new outgoing connection to establish
 * Fix: JSON counter
   reported by:
 * Fix: JSON flow printing for source and destination
 * Fix: Do not always locate exabgp.env
   reported by: Florian Obser
 * Fix: Correctly drop root privileges
   reported by: Florian Obser
 * Fix: validation of flow routes
 * Fix: Python differences between Unix version breaking process forking
 * Fix: Allow = with flowspec singleton
   reported by: Pavel Odintsov
 * Fix: selfcheck feature
 * Fix: do not refuse to parse multiple MP attributes in an update
 * Fix: possible bug with attribute information due to caching
 * Feature: Allow single line flow route
   requested by: Pavel Odintsov
 * Feature: show route (extensive) can take a neighbor as parameter
   requested by: jtkdpu

Version 3.4.10
 * Fix: Fix parsing attributes with PARTIAL flag set
   patch by: Daniel Neiter
 * Fix: Fix -t exit with error code 1 when -t is used and the configuration is invalid
   reported by: Kevin Landreth
 * Fix: Using split option with large MP could lead to invalid update
   reported by: m4ccbr on github
 * Fix: MD5 support for incoming connection
   patch by: Sandy Breeze and David Overton
 * Fix: prevent multiple similar binding
   reported by: Sandy Breeze
 * Fix: allow different MD5 for the same binding
   reported by: Sandy Breeze
 * Fix: issue with ASN4 code
   reported by: Florian Obser (with a patch, thank you)
 * Fix: issue with --decode
 * Change: remove /usr/bin/healthcheck. People should use
   "python -m exabgp healthcheck" instead

Version 3.4.9
 * Fix: very bad bug where NLRI where not associated to the right AFI/SAFI pair ( #235 )
   reported by: esequei
 * Feature: per peer listening option ( listen keyword with port number )
 * Feature: incoming connection MD5 support (incomplete: only work on localhost atm)
   requested by: Sandy Breeze

Version 3.4.8
 * Fix: bug with multiple configuration files
 * Fix: allow generic attribute not only in single line but also in multiple lines
   patch by: Eiichiro Watanabe (issue #214)
 * Fix: issue with parsing extended-community origin
   reported by: Tim Preston
 * Fix: handle numeric community parsing correctly
   reported by: Aaron Kalin
 * Fix: bug in AS_PATH with AS_SET handling
   patch by: Eiichiro Watanabe
 * Fix: off by one for the maximum message size generation
   reported by: Eiichiro Watanabe
 * Fix: issue with handling of some generic attributes
   reported by: Hiroshi Yokoi
 * Fix: restore old api syntax broken by mistake
   patch by: David Waring
 * Fix: issue with E-VPN NLRI
   patch by: Thomas Morin
 * Fix: bad iteration for JSON generation ( bug created during 3.4.8 dev )
   patch by: Ian bobbitt
 * Fix: healthcheck.py: optionally match "alias" in ifconfig output
   patch by: Håvard Eidnes
 * Fix: healthcheck.py: make the ifconfig path work; regexp fix
   patch by: Håvard Eidnes
 * Change: moved the netlink library within exabgp
 * Feature: qa/bin/ip and qa/bin/route

Version 3.4.7
 * Package: be more pythonic and use enty points with pip installation
 * Package: automatically update debian's changelog on release
 * Fix: issue with aggregator generation
   reported by: Yan Filyurin

Version 3.4.6
 * Fix: a badly formated flow route would throw the parser in limbo
   reported by: NickGudov (issue #203)
 * Fix: allow multiple extended attribute (like flow rediction with a origin/target)
 * Fix: use ICMP Type and Code when printing flows (respectively using name and number)
 * Fix: do not use space printing redirect extended community
 * Fix: not parsing correctly multisession configurations
 * Fix: bug in ASPath parsing
   reported by: Terry Hardie (issue #205)
 * Feature: use ETC environment variable for configuration location if set
 * Feature: JSON now includes ASN (local,peer) and IP (local,IP)
   requested by: jtkdpu (issue #196)
   patch by: Ryan Tinianov (pull #199) for the IP
 * Feature: API support for sending eor
   requested by: spakka (issue #109)
 * Feature: allow routes to have a name (which can be used as comment)
   requested by: lazy404 (issue #167)
 * Feature: improve release code to prevent version mismatch (issue #202)
   reported by: Anand Buddhdev
 * Fix: systemd file is not installed anymore by default (issue #202)
   to add to the file installation list use "python setup.py install systemd"
   requested by: Anand Buddhdev
 * QA: moved all testing code (used by travis-ci) in the ./qa folder
 * QA: added nosetest, updating some of the old unittest code
 * QA: integrated travis-ci with coveralls.io to have real time code coverage
 * QA: ExaBGP can take more than one configuration file and on configuration reload rotate between them
 * QA: checking that broken flows do not break the parser
 * QA: checking that configuration routes are well added and removed on SIGUSR1
 * QA: checking that incoming notifications are handled correctly
 * QA: moved many sample configuration file from etc/exabgp to the new qa/conf

Version 3.4.5
 * Fix: improper distribution of events to process workers
   reported by: Tim Epkes

Version 3.4.4
 * Fix: bug with IPv4 / ipv6 handling
 * Fix: better peer isolation when parsing messages
 * Fix: IPv6 decoding when the routes includes link-local
 * Fix: missing text API paramter
 * Fix: no JSON for Aggregator
 * Fix: show route extensive
   patch by: Michal Grzedzicki, thank you
 * Fix: 4-Octet AS Specific BGP Extended Community (RFC 5668)
   patch by: Michal Grzedzicki
 * Fix: bug with label encoding
   patch by: Jesse Mather
 * Improvement: add support for add-path with family MPLS
   requested by: Tim Epkes
 * Fix: bug when process writes multiple lines
   reported by: Ilya Voronin
 * Feature: accept packet with confedation (RFC 3065)
   requested by: oriordan (with a patch, thank you)
 * Fix: do not bark if an unknown ASPath attribute is found
 * Fix: correctly accept connection on AF_INET6 socket
   patch by: John W. O'Brien
 * Fix: restore lost python2.6 compatibility
   reported by: Minsuk Song
 * Fix: IPv6 MD5
   reported by: Dave J Knight
 * Add framework to debug SIGUSR1 related problems
 * Fix: do not drop session when receiving an unknown capability
   patch by: Peter van Dijk (PowerDNS)

Version 3.4.3
 * Fix: JSON message increment
   reported by: Daniel Neiter, with a patch, thank you.
 * Fix: JSON message format for operational
   reported by: Rob Barnes, with a patch, thank you.
 * Fix: JSON message for route-refresh
 * Fix: EOR unpack issue
 * Fix: ASPath encoding
 * Fix: possible bad notify call
 * Fix: Aggregator configuration issue
 * Fix: pycharm reported issues
    - operational, using afi instead of safi
    - bad function paramters
    - missing return keyword
    - many cleanups
 * Change: use RFC MULTISESSION capability and not CISCO variant anymore

Version 3.4.2
 * Feature: add more information in crash report
 * Fix: problem when trying to report exception errors
 * Fix: better handling of on PIPE errors
   reported by: Thomas Raabo
 * Fix: could not split MPLS routes
   reported by: Hideaki HAYASHI
 * Fix: not correctly handling NOTIFICATION message
   reported by: Hideaki HAYASHI
 * Fix: do not block on a peer should a socket become blocking
   reported by: Wouter Miltenburg
 * Fix: API JSON message id incrementation
   reported by: Wouter Miltenburg

Version 3.4.1
 * Fix: on bad JSON message
   patch by: Wouter Miltenburg
 * Fix: parsing of default route
   reported by: Wouter Miltenburg
 * Fix: remove legacy exabgp.tcp.timeout
 * Fix: forgot some processes options when printing neighbor
 * Fix: bad function call for API
 * Fix: correct JSON for OPEN
 * Fix: issues with bad naming of APIOption
   patch by: Wouter Miltenburg
 * Fix: do not try to be clever (and possibly get it wrong) and rely on keepalive timer to detect TCP faults
 * Fix: formating issue of extended community
 * Fix: issue with EOR
 * Fix: caching issue
   reported by: Wouter Miltenburg
 * Fix: make sure we do not call select with a negative time
   reported by: Wouter Miltenburg, Daniel Piekacz
   patch by: Wouter Miltenburg
 * Fix: handle AS4_PATH with PARTIAL bit set
   reported by: Daniel Piekacz
 * Fix: bug with generic attribute generation
 * Fix: bad Notification
   patch by: Wouter Miltenburg
 * Fix: bad Keepalive JSON message
   patch by: Wouter Miltenburg

Version 3.4.0
 * Feature: add support for extended-attribute for FlowSpec
 * Feature: more detailed JSON objects
   patch by: Wouter Miltenburg
 * Feature: support for L2VPN (experimental)
   patch by: Nikita V. Shirokov
 * Improvement: better handling of NOTIFICATION received during OPEN negotiation
 * Improvement: ExaBGP can restart failed helper process
 * Fix: Do not reconnect too fast when connection fails
   reported by: Robert Barnes
 * Fix: Invalid JSON object for route-refresh
   reported by: Robert Barnes
 * Fix: We were not reporting the NLRI of the route received when exabgp.log.routes was set
 * Fix: accept exabgp_tcp_port as configuration option and not only exabgp.tcp.port
 * Fix: duplicate line output
 * Fix: bad refactorisation which caused an bad ASN4 bug
 * Fix: change EOR from IPv4 multicast (mistake) to IPv4 unicast
   reported by: Mark Treacy
 * Fix: bad encoding of flow fragment encoding
   reported by: Andrei-Marius Radu
 * Fix: bad reporting of process open sending
   reported by: Mark Treacy (with patch, thank you)
 * Fix: Incorporating NETBSD compatibility patches
 * Fix: Generation of Generic Attributes
 * Fix: Faster reactor (should be able to process much more API/BGP messages)
 * Change: new commands for the configuration of the API
 * Change: JSON objects now include a unique neighbor identifier
 * Change: JSON objects now include a counter for unique message id
 * Change: JSON objects now include a "type" to now how to best parse them
 * Change: JSON new EOR object
 * Change: JSON new Flow format
 * Change: slight variation with the command line option names, now using docopt
   patch by: Michael Robert Watson
 * Change: the profile information is now exported in kcachegrind format
 * Compatibility: JSON re-introduced the family under the "announce" section ( removed by mistake )
 * Compatibility: restoring integer as default time, high resolution must be enabled to not break older installations
 * Change: JSON and Text shutdown object now shows the PID and PPID

Version 3.3.2
 * Fix: work toward working operational-01
   patch by: David Freedman
 * Fix: do not use . notation in systemd but _
   reported by: Apollon Oikonomopoulos

Version 3.3.1
 * Fix: typo using uid instead gid (could prevent dropping privileges !)
   reported by: Adrian Gämperli (with a merge request, thank you)
 * Fix: prevent ExaBGP to start if the log folder is not writeable by the user
 * Fix: configuration defaults for booleans ( and warns when group-updates is not enabled );
 * Fix: issue when removing some routes
   reported by: Adrian Gämperli (backb1 on github)
 * Fix: bad printing of route as-path
 * Fix: neighbor matching was too permissive
   reported by: Adrian Gämperli (with a merge request, thank you)
 * Fix: under load ExaBGP could miss some commands sent through the API
   reported by: Adrian Gämperli (with a merge request, thank you)
 * Change: performing KeepAlive handling as first action
 * Change: time is provided as an high resolution real number and not an integer
 * Debian package
   update by: Henry-Nicolas Tourneur

Version 3.3.0
 * Fix: typo causing issue when parsing multiple neighbor commands
   reported by: Pablo Camarillo Garvia
 * Fix: bad handling of EOR
   reported by: Petr Lapukhov
 * Fix: multiple bugs with multi neighbor commands
 * Feature: allow as-path [ asn asn, [ asn ] ]
 * Other: migrate the setup.py script to work with git (vs hg)
 * Change: TEXT API format changed and version updated to 3.3.0 (reflect the version when the last change was introduced)
 * Change: JSON API format changed and version updated to 3.3.0
 * Change: as-path now returns two JSON keys, 'as-path' and 'as-set'
 * Change: NLRI are now grouped by next-hop, next-hop removed from the NLRI
 * Change: raw message use the keyword "message" and not "update"
 * Change/Fix: JSON for announcement was missing next-hop
 * Change: on TEXT API, "announced route eor" becomes "announced eor"

Version 3.2.19
 * Fix: bug when displaying EOR
 * Fix: invalid check on next-hop for multi-line routes
   reported by: Pierre Aubry
 * Fix: badly parsing command line for run option
   reported by: Allan Feid
   solution by: Vincent Bernat
 * Fix: allow the creation of 'allow' flows
   reported by: Adrian Cepleanu
 * Fix: bad JSON encoding for EOR
   reported by: Robert Barnes
 * Fix: API message encoding
   patch by: Daniel Neiter
 * Feature: allow digit:digit in extended communities
   requested by: Pierre Aubry
 * Feature: healtcheck.py, python 2.6 and community support
   pulled from: Allan Feid

Version 3.2.18
 * Fix: add path for IPv6 was badly negotiated
   reported by: Robert Barnes

Version 3.2.17
 * Feature: make route auto-flush an option with an API call to flush routes on demand
 * Feature: make the reactor loop time an option (it allows for a faster flush of routes)
 * Feature: allow to disable the Adj-RIB-Out (can save lots of memory if you know what you are going to send)
   requested by: David Hauweele
 * Fix: Keep API routes between SIGUSR
 * Fix: Missing empty added nlri when the update only has withdrawn
   reported by Robert Barnes (and his co-workers) with a patch, thank you !
 * Fix: Single AS Path with AS Set were reported as empty AS Path and AS Set
   reported by: David Hauweele
 * Fix: possibly not sending withdrawal when it was required
   reported by: David Hauweele
 * Fix: typo in code causing crash when process went away
   reported by: Robert Barnes
 * Fix: RouterID MUST be an IPv4
   reported by: Kristopher Beevers
 * Fix: JSON output on EBGP and IBGP session is not the same
   reported by: Robert Barnes
 * Fix: route representation with labels and route distinguisher
 * Fix: do not double remove the BGP header size
   reported by: Hideaki HAYASHI
 * Fix: parsing flow NLRI, withdrawal were reported as announcement
 * Fix: printing extended communities
 * Fix: retry when network is blocking (issue 60)
   reported by: Hideaki HAYASHI
 * Change: remove next-hop from attributes in JSON as it is given in the announce section
 * Change: cleanup in configuration parsing
 * Change: the path-information, labels and route distinguisher are now printed before the next-hop

Version 3.2.16
 * Fix: fix an issue with RIB cache handling
 * Fix: fix an issue with Flow generation introduced recently (mandatory attributes are mandatory even for Flow Routes)
   thanks to: Quentin Loos for reporting the issue and helping fixing it
 * Fix: on SIGUSR no route withdrawal update was performed
   reported by: Sascha Schumann
 * Fix: Do not oversend routes for route refresh
   reported by: Hideaki HAYASHI
 * Fix: Bug when route when trying to withdraw an absent route with the API
   reported by: Peter Bristow
 * Fix: Malformed JSON message
   reported by: Robert Barnes
 * Fix: validate the FLAG of the attribute received (following our own advise on IDR)
 * Change: major RIB code modification
 * Change: match attributes using the flag value as well

Version 3.2.15
 * Fix: a wrong fix introducing a bug in 3.2.14

Version 3.2.14
 * Fix: do not leak route between peers
 * Fix: restore group level static group for all peers thereafter
 * Fix: a bug in group-updates causing attributes to not be included in the update message
 * Fix: a bug when update large than 4096 could be generated with group-updates
 * Fix: an issue with JSON generation
 * Fix: MD5 support had been removed by error from 3.2
 * Feature: allow to use quote with --decode
 * Feature: implement draft-ietf-idr-aigp-10

Version 3.2.13
 * Fix: do not send enhanced route refresh BoRR and EoRR on reconnection
 * Fix: do not take all the CPU when connecting

Version 3.2.12
 * Fix: the signal for reload were wrong in the debian script
   reported by: Sascha Schumann
 * Fix: a critical bug introduce in 3.2.11 when route were not resent on reconnect
   reported by: Sascha Schumann

Version 3.2.11
 * Feature: the TCP server allows 'neighbor' commands
   patch by: Hideaki HAYASHI
 * Feature: initial Enhanced route refresh initial implementation
   thanks to: Hideaki HAYASHI for reporting an issue before the release (some border cases still exist)
 * Fix: bug in generating API string, missing space
 * Fix: bug in generating API string, withdrawn reported as invalid announced
 * Fix: bug in generating API string, withdawn was missing Path-Information
 * Fix: route refresh implementation issues
 * Fix: a bug with capability parsing introduced with operational
   reported by: M. Brent Busby
 * Fix: be more aggressive on reconnection (3.2 was slower than 3.1)
   reported by: Sascha Schumann

Version 3.2.10
 * Fix: was not announcing add-path for IPv6 unicast
 * Fix: we were not sending the Notification messages
   reported by: Hideaki HAYASHI
 * Feature: add support for route-refresh (RFC 2918)

Version 3.2.9
 * Fix: some json generation issue
   reported by: Peter Spikings
 * Fix: bad decoding of withdrawn routes with label ( checking 0x80000 and not 0x800000 )
 * Fix: only treat 0x800000 as special for route withdrawal
 * Fix: we could believe we were already connected when we were not
 * Fix: handle when ExaBGP daftly connects to iself
 * Fix: did not parse add-path capability correctly (only registered the last family sent)
   reported by: Ryan Steinmetz
 * Fix: ASM messages were sent as ADM
 * Feature: decode shows the JSON representation of updates
 * Feature: start of support for draft-ietf-idr-operational-message-00
 * Feature: allow operational advisory message using the API

Version 3.2.8
 * Fix: correctly re-send routes between restart

Version 3.2.7
 * Fix: do not try to read empty body, causing loop delay

Version 3.2.6
 * Fix: bug in collision detection
 * Fix: prevent re-announcement of identical routes

Version 3.2.5
 * Feature: FlowSpec decoding (ExaBGP can decode incoming FlowSpec)
 * Feature: detect invalid netmask on route parsing
 * Feature: "next-hop self" is supported via the API
 * Feature: can accept incoming connect and perform collision detection
 * Feature: add support for draft-ietf-idr-flowspec-redirect-ip-00.txt
 * Feature: add missing DCSP marking from RFC 5575 (flowspec)
 * Feature: add missing traffic-action from RFC 5575 (flowspec)
 * Feature: add support for draft-raszuk-idr-flow-spec-v6-03
 * Feature: complete RFC 5575 by providing support for flow-vpn
 * Fix: async connect issues
   reported by: Vincent Bernat (with very good advice for the patch)
 * Fix: bad function defintions
   patch by: Vincent Bernat
 * Fix/Compatibility: bad naming of flow capability
 * Compatibility: -c becomes -f (it should not be used by users anyway)

Version 3.2.4
 * Feature: new update code generation can really group NLRI in one update packet
 * Feature: massive code cleanup, much easier to read
 * Feature: new RIB code (inbound and outbound tables) much faster
 * Compatibility: JSON next-hop for the route is not in the attribute anymore but the NLRI

Version 3.2.3
 * Fix: an issue in the 3.2.x series when the socket return a non-fatal error
   reported by: Daniel Bradshaw
 * Fix: an issue when the code would not behave correctly on network error
 * Fix: some issues when encoding vpnv4 routes
 * Fix: change the behaviour of the main peer loop (should behave more like expected - no bug reported tho)
 * Fix: many small fixes
 * Fix: bad encoding of FlowSpec Fragments
 * Feature: implemented some defensive coding practice (enable with exabgp.debug.defensive)
 * Feature: IO code now fully non blocking on read and write
 * Feature: total rewrite of the watchdog feature now extremely scalable

Version 3.2.2
 * Feature: allow to generate NOTIFICATION messages through the API
   requested by: Parag Jain
 * Feature: new syntax for the multiple neighbor announcement created in 3.1.13
   Allow to filter on more than the IP address
   requested by: Petr Lapukhov
 * Feature: better uid/euid/gid change check
 * Feature: allow to reload with restart of helper process with SIGUSR1
   patch by: Vincent Bernat
 * Feature: --decode can now be passed multiple messages to decode
 * Feature: -v,--version returns ExaBGP's version
 * Feature: be more robust on ^C
 * Feature: totally rewrote the networking code, it now better deal with blocking write and not not need buffering
 * Feature: user controlled open wait timer
 * Feature: handle unknown transitive attributes
 * Feature: allow the generation of generic attributes
 * Feature: faster parsing of consecutive updates with the same attributes
 * Feature: more regression testing
 * Fix: potential issue with multisession collision detection
 * Fix: with multisession recent python would refuse to copy an route due to a lock in logger of the neighbor object
 * Fix: could not handle NOTICATION sent during the OPEN negotiation stage
 * Fix: extra spaces in the configuration could cause bad parsing
   reported by: Parag Jain (with a patch for the RD case - thank you)
   reported by: Vincent Bernat (with an alternate solution)
 * Fix: ExaBGP would not connect if the OS did not implement SO_REUSEPORT
   reported by: Vincent Bernat
 * Fix: the configuration would not handle run program with upper case or spaces
   reported by: Vincent Bernat
 * Fix: bug in the networking code
   patch by: Vincent Bernat
 * Fix: an issue with received timer expiring when it should not have
   reported by: Eric Cables
 * Fix: do not try to parse Flow Route when perforing self-check (ExaBGP regression suite)
 * Compatibility: supervisor was renamed reactor
 * Compatibility: the word inet4/inet6 are now replaced by ipv4/ipv6
 * Compatibility: the option exabgp.tcp.block was removed following the networking code change
 * Compatibility: reload the configuration with SIGUSR1, reload configuration and processes with SIGUSR2
 * Compatinility: using SIGHUP will now TERMINATE ExaBGP and not reload the configuration
   reported by: Daniel Bradshaw (issue 32)

Version 3.1.13 - 6th July 2013
 * Fix: only clear buffered routes on restart and not reload (bug never reported)
 * Fix: an issue when parsing EOR
 * Fix: bug with RD community genration
   reported by: Parag Jain
 * Feature: use less memory on route change calculation
 * Feature: more regression testing
 * Feature: allow to control which neighbor will get API notification
   requested by: Parag Jain
 * Feature: allow to control which neighbors will get API notification
   requested by: Petr Lapukhov
 * Feature: allow delayed connections
   requested by: David Freeman
 * Feature: block on busy socket for performance testing
   requested by: David Freeman
 * Fix/Feature: only announce routes for the negociated family on a connection
   requested by: Andrew Hoyos

Version 3.1.12 - 16th May 2013
 * Fix: could crash when a family safi was not defined in the peer family group instead of exiting with an error
 * Fix: a bug in the generation of extended community (target and origin)

Version 3.1.11 - 2nd of May 2013
 * Fix/Feature: prevent exabgp api command to block the main loop if very long (issue 29)
 * Feature: better sharing of available time between api and peers
 * Fix: a bug when trying to stop exabgp and a worker process is unstable
 * Feature: count how many time a worker crashed and stop the application it is unstable (5 restart in 64 seconds)

Version 3.1.10 - 2nd of May 2013
 * Change: the JSON format of ASPath

Version 3.1.10 - 8th of April 2013
 * Change: relax a rule and let MED propagate on IBGP

Version 3.1.9 - 27th of March 2013
 * Fix: bug in logging
 * Fix: typo in neighbor printing

Version 3.1.8 - 22nd of March 2013
 * Fix: bad encoding of extended community for FlowSpec redirect
   reported by: Ozgur Karaman
 * Feature: unsupported before the next configuration format 'next-hop self', the neighbor MUST be defined first
   requested by: Federic Gabut-Deloraine

Version 3.1.7 - 18th of March 2013
 * Fix: api only get bgp session negotiation messages if neighbor-changes is set
   reported by: Lorenzo Murillo
 * Fix: json quoted integer and long by mistake
   reported by: Lorenzo Murillo
 * Fix: json used comma with no data to separate
   reported by: Lorenzo Murillo

Version 3.1.6 - 8th of March 2013
 * Fix: unclear log entry when removing route using API
   reported by: Lorenzo Murillo
 * Fix: withdrawn routes were always prepended with add-path information
 * Fix: bad withdrawal of routes (issue 11)
 * Fix: more sanity checking when parsing flow routes
 * Change: split configuration code to not be exabgp only
 * Feature: add a very simple BMP deamon (version 1 of the draft)

Version 3.1.5 - 18th of Febuary 2013
 * Fix: function name broking some features (issue 23)
   reported by: Lorenzo Murillo

Version 3.1.4 - 18th of Febuary 2013
 * Fix: Learn to spell negotiated (issue 21)
   reported by: Ian Wells
 * Feature: option to only attempt one TCP connection per peer (required by unittesting code)
 * Fix: a bug in code in charge of parsing legacy API names
 * Fix: fix relative path from exabgp
 * Fix: bug in api code causing crash
 * Fix: did not cleanup routes from the api before tokenisation (issue 22)
   reported by: Lorenzo Murillo
 * Fix: did not split routes from the api (issue 22)
   reported by: Lorenzo Murillo
 * Fix: when the api program was sending message too fast, some were missed (issue 22)
   reported by: Lorenzo Murillo
 * Fix: make peer name more unique (adding asn, and router-id) to prevent to router configuration to merge
 * Feature: restart the API program if we lost its file descriptor

Version 3.1.3 - 4th of Febuary 2013
 * Fix: JSON bugs (encoding for cluster-list, withdrawn routes)
   patch by: Vincent Bernat

Version 3.1.2 - 10th of January 2013
 * Copyright: updated all copyright notice (welcome to 2013)
 * Change: tidy process command name (keeping compatibility)
 * Feature: pass raw update message to the API
 * Feature: better control of the API message passed
 * Feature: allow/make work a global process for multiples peers (partial compatibility kept)

Version 3.1.1 - 6th of January 2013
 * Complete Fix: watchdog feature (issue 13)
 * Feature: JSON API 1.0, flowspec untested (issue 17)
 * Feature: allow to remove routes by only providing the nlri and next hop (issue 16)

Version 3.1.0 - 2nd of January 2013
 * Partial Fix: watchdog feature
   reported by: Ryan Steinmetz
 * Fix: problem with SIGHUP when deleting peer
   patch by: Justin Azoff (thank you)
 * Fix: cluster-list attribute was not passed to api correctly
 * Feature: MD5 support on FreeBSD (issue 14)
   patch by: Ryan Steinmetz (thank you)
 * Feature: caching of Community and Next-Hop
   requested by: Justin Azoff (with benchmarking gains report,thank you)
 * Feature: Store routes in neighbor as set and not list, so removal are O(1)
   patch by: Justin Azoff (thank you)
 * Feature: (experimental) Limit the memory used for parsed route caching
 * Feature: (experimental) json encoding on the API (issue 17) not tested with flow routes or complex routes

Version 3.0.11 - 21st of November 2012
 * Fix: add support for IPv6 MD5SUM
   reported by: Eiichiro Watanabe (with a patch, thank you)
 * Fix: RFC compliance, supporting keepalive timer of zero
 * Fix: parsing an invalid community string could cause a program crash
 * Feature: add possibility to disable route attribute caching to reduce memory usage
   (over a few hundred Mb saved per full routing tables)
   requested by Daniel Piekacz

Version 3.0.10 - 6th of September 2012
 * Fix: not removing duplicate route correctly (same nlri different attributes) (issue 7)
   patch by: Reggie Yam (thank you)

Version 3.0.9 - 5th of September 2012
 * Fix: problem when parsing ASN which are not fitting in a Python integer
   reported by: Matthias Cramer

Version 3.0.8 - 28th of August 2012
 * Fix: empty as-path route printing
 * Fix: bug in printing neighbor objects
 * Fix: the first route of any MultiProtocol Update did not get its attributes set
 * Fix: safi on extensive route printing
 * Feature: change the packet dump format to be cisco like
 * Change: added configuration self-checking (-t, --test)
 * Feature: added parsing of raw update in command line (--decode)
 * Feature: add a capability to disable asn4 support (useful when decoding routes)

Version 3.0.7 - 19th of August 2012
 * Fix: parser had a bug with multiple flow routes
   reported by Dmitry Lisakov and Oleg Alekseenko

Version 3.0.6 - 5th of August 2012
 * Fix: ommission during a variable name change
 * Fix: the example supervise script
 * Fix: withdrawing routes via helper program (issue 5)

Version 3.0.5 - 22 of July 2012
 * Feature: suppor for systemd
   patch by: Sébastien Luttringer
 * Fix: some unexpected verbosity when use the exabgp shell script on some OSes
   patch by: Sébastien Luttringer
 * Fix: possible miss of connection loss
 * Fix: EOR code (again)
 * Fix: we were deleting the next-hop of MP routes !
 * Fix: follow correctly RFC 4760 (MP) for route generation (it was working, we were lucky)
 * Fix: exabgp.daemon was spelt exabgp.deamon for the PID location migration
   reported by: Tim Gebbett
 * CHANGE: Do not start if the PID file exists
 * CHANGE: helpers can now get new message for EORs like "announced eor 1/1 (IPv4 unicast)"
 * Debian package update by:
   Henry-Nicolas Tourneur
 * ArchLinux package by:
   by: Sébastien Luttringer

Version 3.0.4 - 19 of July 2012
 * Fix: FlowSpec API change update forgotten
 * Fix: Provide the right user to -fi when upgrading on Debian
 * Fix: split option now works with non ipv4 unicast route
 * Fix: log level parsing with -d
 * Fix: need to change gid before uid when dropping privileges
 * Fix: do not run our forked program as the caller but the suid user (fix bug when daemonizing too)
 * Fix: bug when daemonizing and not using syslog
 * Fix: handle gracefully ^C during configuration load/reload
 * Feature: prevent SIGINT to reach the forked programs
 * Feature: allow multiple configuration files, which forks multiple main loops
 * Feature: send a "shutdown" message before terminating the worker processes
 * Feature: group-updates option in neighbor which group routes with the same attributes in one update
 * Feature: announce to helpers the start and end of update

Version 3.0.3 - 17 of July 2012 (unreleased experimental version)
 * Fix: bug in ASN4 path reconstruction
 * Fix: on peer close, do not carry untransmitted routes through the next cycle
 * Fix: on peer reload make sure all the routes are re-announced
 * Fix: massive CPU saving - only check for new route to announce when we have some
 * Fix: route buffering when sending many routes over slow connection/to slow routers was broken
   reported by Simon Woodhead (thank you for the testbed to debug it)
 * Feature: in the way we store route in memory for the route delta on config change
 * Feature: better reporting of message buffering
 * CHANGE: The way the routes as-path is printed/parsed (final for the 3.x.x)

Version 3.0.2 - 16 of July 2012 (unreleased experimental version)
 * CHANGE: python2.4 may work but it not supported anymore
 * Fix: as-path decoding issue with as-set being eaten (full rewrite of ASPATH and ASN4 parsing)
   reported by Rishabh Goel
 * Fix: bug with profiling
 * Fix: withdrawal was broken when path-info was added
 * API CHANGE: as-path configuration syntax (as-sequence removed)
 * CHANGE: restructuration of file hierarchy

Version 3.0.1 - 14 of July 2012 (unreleased experimental version)
 * Feature: caching of parsed attributes of route received (saving memory and CPU)
 * Feature: do not generate complex string with packet data if not printed
 * Feature: all objects are storing data in the wire format when possible
 * Feature: add AGGREGATOR and AS4_AGGREGATOR support
   requested by: Rishabh Goel <rgoel@internap.com>
 * Feature: add ATOMIC_AGGREGATE support
   requested by Rishabh Goel
 * Feature: faster configuration parsing
 * Feature: bring compatibility mode for option with 2.0.x
 * Feature: support for RFC 4659 BGP-MPLS IP VPN Extension for IPv6 VPN
 * Fix: harmless bug in the EOR generation
 * Fix: missing family announcement in open when autogenerated with option "all"
 * Fix: silly bug in profiling
 * Fix: clusterid and originator_id were not added to generated routes
 * Fix: were not parsing extended-community in multi-line routes
 * Fix: flow-spec route creation (broken during the work for 3.0.0)
 * Fix: typo when generating route string with labels
 * Fix: problem when forking on BSD/Darwin
 * Change: to ASN4 code

Version 3.0.0 - 13 of July 2012 (unreleased experimental version)
 * Major version change due to incompatible CLI interface with version 1.x.x and 2.x.x
 * Major version change due to a change of API behaviour with the forked worker processes

 * Change : Many printed message have changed, including OPEN MultiProtocol
 * CLI Change: use new ini file and environment values for configuration
 * API Change: send "up" message to worker process when neighbour OPEN negotiation is complete (not on TCP up)
 * API Change: the format of the line sent to the worker changed, neighbor name include multi-session information
 * API Change: the down message sent to help programs now include a reason for the shutdown of the session
 * API Change: use the word withdrawn when the route was received, withdraw when it is an action, same for announce and announced
 * API Addition: send "connected" to worker when neighbour TCP session is established (replace previous 'up')
 * API Addition: requires peer-updates under 'process' to announce peer status changes
 * API Addition: show routes, show routes extensive, show neighbors
 * Fix: were not dropping root privileges correctly
 * Fix: reset counters correctly for number of routes seen (only affects the logs)
 * Fix: prevent 100% CPU usage/loop when trying to read on unreliable links
 * Fix: correctly process IPv6 routes with 32 bytes long next-hop
   reported by Daniel Piekacz (with patch, thank you)
 * Fix: problem on broken pipe with the helper program
 * Fix: correct sending of message to helper program (every worker was getting every peers messages)
 * Fix: if an helper program goes away, do not try to restart the peer (prevent surprises)
 * Fix: problem when writing too fast and causing EGAIN errno failure on the socket (mostly/only on Mac OSX)
   reported by Simon Helson (with patch, thank you)
 * Fix: a nasty bug when dynamic route announcement would not work when no routes were setup
   reported by Tim Gebbett
 * Fix: bad counting of routes parsed (not resetting in some case)
 * Fix: badly printed local-preference when generating route representation
 * Fix: bug when trying to daemonise ExaBGP, caused by unclosed FD
   reported by Ryan Lane (with a patch, thank you)
 * Fix: parse correctly routes with empty AS-SET or AS-SEQUENCE
 * Feature: hidden option to change BGP select timeout (use at your own risk - do not ask me where it is - it is hidden)
 * Feature: announce EOR even if Graceful-Restart was not negotiated but only MultiProtocol
 * Feature: implementation of draft-ietf-idr-bgp-multisession-06
   use capability 131 (and not 68) for multisession to achieve interop with Cisco
 * Feature: following RFC 6608 new notification codes
 * Feature: to the logging code and message filtering
 * Feature: support RFC 3765 (NOPEER community)
 * Feature: support for draft-ietf-idr-add-paths-07 (even IPv6 even if it is not supported by anyone)
   requested by: Rishabh Goel (Thank you for giving me a BGP session to an XR)
 * Feature: support for RFC 4456 (BGP Route Reflection: An Alternative to Full Mesh Internal BGP (IBGP))
   more exactly the generation and parsing of originator-id and cluster-list attributes
   requested by Rishabh Goel
 * Feature: add tcp timeout control for connection over very slow ebgp multihop (dangerous, use with care)
 * Feature: control of the MP families announced in the OPEN message
 * Feature: support for RFC 3107 and 4364 (Carrying Label Information in BGP-4)
 * Feature: selfcheck, allow to check if the routes we generate pass our own parser

Version 2.0.8 - 31 of March 2012 (stable version)
 * Fix: the update grouping could cause message up to "header size" bigger than allowed.
 * Fix: caller script path detection

Version 2.0.7 - 24 of March 2012
 * Fix: debian packaging issue
 * Note: Only released for debian (again :p)

Version 2.0.6 - 28 of Febuary 2012 (stable version)
 * Feature: update grouping up to 4096 bytes
 * Fix: debian packaging issue

Version 2.0.5 - 10 of Febuary 2012
 * Feature: allow named community
 * Fix: bad flowspec component size calculation for large flow routes
 * Fix: bad attribute generation for attributes bigger than 256 chars
 * Fix: allows to pass arguments to the helper programs
 * Contribution: route collector utilities from Daniel Piekacz

Version 2.0.4 - 1st of Febuary 2012
 * Fix: sending any signal stoped the program instead of reloading

Version 2.0.3 - 1st of Febuary 2012
 * Feature: now sending help "neighbor <ip> up" when a neighbor goes up
 * Fix: now sending correctly "neighbor <ip> down" when a neighbor goes down
 * Fix: a bug when parsing "split" configuration
 * Fix: sending routes faster than a router can accept does not cause the BGP session to go down
   problem found by Eric Nghia Nguyen Duy (thank you for giving me access to his lab to fix the issue)
 * Feature: Buffering message we can not send if sockets return a transient failure
 * Feature: Limiting how long and how deep the buffer are kept before we kill the session
 * Fix: under load we could receive partial messages, read until we have it all
 * Fix: we were not always sending the 'down' message to handlers
 * Fix: handle signal during select
 * Internal Change: how we read from socket
 * User Change: new DEBUG_CORE option (alias for DEBUG_SUPERVISOR, DEBUG_DAEMON, DEBUG_PROCESS, DEBUG_MESSAGE, DEBUG_TIMER, DEBUG_ROUTE)
 * User Change: DEBUG_ROUTES is deprecated please use DEBUG_ROUTE (2.0.x release with have both values)
 * Feature: Parsing AS4_PATH message and merging AS_PATH when required
 * Fix: possible problem with session establishment
 * Feature: extendeded community are available in the configuration file
 * Feature: printed routes now include extended community information
 * Fix: bad route generation for OLD BGP speakers, previously not including 2 bytes ASN in the AS4_PATH

Version 2.0.2 - 1st of January 2012
 * Copyright: updated all copyright notice (welcome to 2012)
 * Fix : would not daemonise correctly
 * Fix: we were mistakenly not displaying Notify sent on errors
 * Fix: some debian packaging issues
 * Fix: bug when parsing unknown open capability
 * Fix: forgotten to allow some route option on multiline
 * User Change: implemented RFC 6286 BGP Identifier released restrictions
 * Improvment: recognise multisession capability (draft-ietf-idr-bgp-multisession-06)
 * Improvment: allow the configuration of route which will not be announced on configuration reload (to work in conjunction with watchdog)
   requested by Marco d'Itri

Version 2.0.1 - 8th of December 2011
 * Fix : Regression on FlowSpec
 * Fix : interpreter not found on some Linux version
   (issue 3) reported by  Sebastien Luttringer

Version 2.0.0 - 3rd of December 2011 (experimental version)
 * Feature: can set flowspec communities
   requested by Yiming Gong
 * Feature: incoming route parsing for processing by an external application
   requested by Daniel Piekacz (and others)
 * Improvment: Add profiling features to find bottlenecks
 * Improvment: Code speedup following profiling
 * Internal Change : lots of folder restructuration
 * Internal Change : all includes now under exabpg and not bgp
 * User Change : move the program from bin to sbin, and renamed it from bgpd to exabgp
 * User Change : configuration folder now called exabgp to match debian package
 * User Change : move all external processes in the exabgp configuration folder

Version 1.3.4 - 21th of September 2011 (stable version)
 * Feature: added support for asdot/asdot+
   requested by jonlooney (with a patch - thank you)
 * Fix: when the pid file could not be written, the daemon was crashing on exit

Version 1.3.3 - 25th of June 2011
 * Feature: massive speed improvement when reloading with many routes (60 to 2 seconds with 10k routes)
   reported by Martin Baum (with proof of concept patch)

Version 1.3.2 - 23rd of June 2011
 * Fix bug where we would not wait long enough for OPEN/KEEPALIVE messages on startup
   reported by: Yann Berthier

Version 1.3.1 - 3rd of May 2011
 * Fix bug in configuration parsing introduce just before 1.3.0
 * Feature: make tcp-server implement all the internal API available

Version 1.3.0 - 2nd of May 2011
 * Feature: reduce likelyness of route update recalculation causing us to not send keepalive in time
 * Fix: introduced a bug in neighbor printing
 * Fix: we were trying to send a KEEPALIVE after the initial routes, but it was not going
 * Fix: a work around a python bug with TCP was not implemented everywhere
 * Feature: adding a 'ttl-security' to allow to explicit setup of TCP TTL
 * Feature: better handling of BGP timer for keepalive
 * Feature: refuse to run as root, try to run as nobody automatically, uid/gid set to the user defined by env USER otherwise
 * Removed: the old wiki documentation
 * Feature: Debian Packaging (author and maintainer: Henry-Nicolas Tourneur - thank you)
 * Change: renamed env variable DAEMON to DAEMONIZE (to prevent name clash with Debian)
 * Feature: added env variable PDB if set the program will call pdb, the python debugger, on program fault
 * Feature: it is now possible to get some routes withdrawn from an external process (see watchdog example conf.)
   warning: this code is not yet considered production ready, expect some bugs for complex configurations
 * Feature: it is now possible to modify the configuration without reload from external proccess (see process example conf.)
   warning: this code is not yet considered production ready, expect some bugs for complex configurations
 * Fix: make sure we can setup a session even if no route (ie: AFI/SAFI families for Mulitprotocol) are in the configuration
 * Fix: many small bug fixes, simple code refactorisation, ...

Version 1.2.0 - 25th of January 2011
 * Feature: Allow to break route in more specific (ie define a /22 and get 4x /24 announced)
   This is useful when blackholing traffic to make sure no routes more specific are received from your network peer/transit
   requested by : Renaud Chaput
 * Feature: Save the program PID into a file (set the PID= environment value with the file path)
   requested by : Renaud Chaput
 * Feature: Add syslog support (env SYSLOG= nothing for local syslog, a file name (auto-rotate) or host:<host> for remote syslog)
   requested by : Josh Ward
 * Feature: Can now daemonise (env DAEMON= detach and send the program in the background)
   requested by : Josh Ward
 * Feature: Selection of what subsystems to log, more readable logs (well, less unreadeable to be exact)
 * Feature: Create a new "group" in the configuration to share routes and configuration options between neighbors
   requested by : Multiple people
 * Fix: non detection of MD5 change on configuration reload
 * Feature: support distutil with a setup.py file for easy installation

Version 1.1.0 - 10th of January 2011
 * Feature: Tested and completed TCP MD5 signature
   contribution: MD5 TCP code by David Farrar

Version 1.0.4 - 8th of January 2011
 * Feature: can now toggle debuging using environment values (DEBUG_CONFIGURATION, DEBUG_SUPERVISOR, DEBUG_WIRE)
 * Fix: some change to the AS_PATH generation code (some routers did not accept empty AS_PATH as it was encoded before)
   reported by: R.P. Aditya
 * Fix: some interoperability issue with openbgpd (could not parse their OPEN message)
   (issue 1) reported by Manuel Guesdon
 * Experimental: Some MD5 for Linux (untested - surely not working)

Version 1.0.3 - 6th of January 2011
 * Fix: missing default localpref on IBGP session if not specified on the route
 * Feature: more verbose messages in case of OPEN negociation issue
 * Fix: typo preventing 4 Bytes ASN to work

Version 1.0.2 - 22nd of October 2010
 * Feature: only try to generate UPDATE messages if the configuration was changed (save quite some CPU as the algorithm is really naive)
 * Fix : a neighbor configuration change could have been undetected on SIGHUP/SIGALRM
   reported by: Yann Berthier
 * Fix : reloading the configuration did not detect the removed routes
   reported by Renaud Chaput
 * Fix : a bug in the format of the UPDATE for route withdrawal causing Cisco (and not Quagga) to tear the session
   reported by Renaud Chaput

Version 1.0.1 - 7th of September 2010
 * Fixes an issue with some python versions (at least 2.5.2) when sending a large number of routes (several hundred). Some messages could be sent in multiple parts, causing the parser at the other end to barf (Thank you to Renaud Chaput for the bug report)
