---
name: Hardware support request
about: Request support for a new hardware architecture support
title: ''
labels: new architecture
assignees: ''

---

**Why do you need support for this specific architecture?**
Please write a short note why you need this specific architecture support.

**Which architecture model, family and further information? CPU or accelerator? **

**Is the documentation of the hardware counters publicly available?**

**Are there already any usable tools (commercial or open-source)?**
