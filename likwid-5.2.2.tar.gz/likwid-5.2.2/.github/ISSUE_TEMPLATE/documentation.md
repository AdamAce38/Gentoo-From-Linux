---
name: Documentation
about: If you are missing documentation or found errors
title: "[DOCS]"
labels: documentation
assignees: ''

---

**What are you searching for**
Please supply a short note what you want to know

**Where have you searched for it**
Unfortunately, the documentation is located in different places (Wiki, webpage, slide sets, ...)
