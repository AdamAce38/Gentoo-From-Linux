using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle ("Mono.Cecil.Tests")]
[assembly: AssemblyProduct ("Mono.Cecil")]
[assembly: AssemblyCopyright ("Copyright © 2008 - 2011 Jb Evain")]

[assembly: ComVisible (false)]

[assembly: Guid ("da96c202-696a-457e-89af-5fa74e6bda0d")]

[assembly: AssemblyVersion ("1.0.0.0")]
[assembly: AssemblyFileVersion ("1.0.0.0")]
