﻿Partial Public Class Test
    Public Enum Targets
        Exe
        Winexe
        Library
        [Module]
        None
    End Enum
End Class
