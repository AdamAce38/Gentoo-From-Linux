export S="${HOME}/perl"
export GENTOO_NO_PORTING_TESTS=1
export GENTOO_ASSUME_SANDBOXED=1
mkdir -p ${S}
