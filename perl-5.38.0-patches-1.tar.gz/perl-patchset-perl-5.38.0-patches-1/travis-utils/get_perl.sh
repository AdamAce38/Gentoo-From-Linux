einfo "Fetching ${TARGET_PERL}"
wget -O /tmp/perl.tar.xz ${TARGET_PERL} || die "Cannot fetch ${TARGET_PERL}";
