require "test/unit"
require_relative "core_assertions"

Test::Unit::TestCase.include Test::Unit::CoreAssertions
