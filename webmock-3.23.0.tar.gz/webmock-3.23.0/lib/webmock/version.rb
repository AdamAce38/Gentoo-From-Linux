# frozen_string_literal: true

module WebMock
  VERSION = '3.23.0' unless defined?(::WebMock::VERSION)
end
