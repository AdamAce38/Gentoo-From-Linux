module GetOpt.Declarative (module GetOpt.Declarative) where
import           Prelude ()
import           GetOpt.Declarative.Types as GetOpt.Declarative
import           GetOpt.Declarative.Interpret as GetOpt.Declarative
import           GetOpt.Declarative.Environment as GetOpt.Declarative
