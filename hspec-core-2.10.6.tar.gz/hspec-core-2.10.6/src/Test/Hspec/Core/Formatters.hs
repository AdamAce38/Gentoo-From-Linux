-- |
-- Deprecated\: Use "Test.Hspec.Core.Formatters.V1" instead.
module Test.Hspec.Core.Formatters
-- {-# DEPRECATED "Use \"Test.Hspec.Core.Formatters.V1\" instead." #-}
(module V1) where
import           Test.Hspec.Core.Formatters.V1 as V1
