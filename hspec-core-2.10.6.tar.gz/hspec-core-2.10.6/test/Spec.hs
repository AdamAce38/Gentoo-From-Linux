{-# OPTIONS_GHC -fforce-recomp -F -pgmF hspec-meta-discover #-}
