from django.apps import AppConfig


class DefaultConfig(AppConfig):
    name = 'django_otp.plugins.otp_email'
    default_auto_field = 'django.db.models.AutoField'
