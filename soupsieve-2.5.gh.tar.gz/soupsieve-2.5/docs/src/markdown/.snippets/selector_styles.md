<style>
.twemoji.big-icon svg {
  max-height: initial !important;
  height: 3rem !important;
  width: 3rem !important;
}

.twemoji[data-md-color-primary] {
  color: var(--md-primary-fg-color);
}

.twemoji.icon:hover {
  cursor: pointer;
}

.twemoji.icon svg{
  transition: all 0.5s ease;
}

.twemoji.icon:hover svg {
  transform: scale(1.2);
  translateY(10%);
}
</style>
