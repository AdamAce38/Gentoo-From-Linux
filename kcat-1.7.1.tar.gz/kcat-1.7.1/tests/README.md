These tests assume a cluster is running and the bootstrap.servers
is set in the $BROKERS environment variable.

The cluster is assumed to have auto topic creation enabled with
a default partition count of at least 3.

