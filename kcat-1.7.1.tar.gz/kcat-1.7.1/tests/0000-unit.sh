#!/bin/bash
#

# Run builtin unittests
#

set -e
source helpers.sh

$KCAT -U
