#pragma once

#define KCAT_VERSION "1.7.1" /* Manually updated */
