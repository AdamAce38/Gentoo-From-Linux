.. rocThrusts documentation master file, created by
   sphinx-quickstart on Mon Jan  8 09:51:41 2018.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to rocThrust's documentation!
==================================

.. toctree::
   :maxdepth: 3 
   :caption: Contents:

   api/library_root
   
Indices and tables
==================

* :ref:`genindex`
* :ref:`search`
