Once Thrust has been installed, these example programs can be compiled
directly with nvcc.  For example, the following command will compile the
norm example.
  $ nvcc norm.cu -o norm

These examples are also available online:
  https://github.com/NVIDIA/thrust/tree/main/examples
