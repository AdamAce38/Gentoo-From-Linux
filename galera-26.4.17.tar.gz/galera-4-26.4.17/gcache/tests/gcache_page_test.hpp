/*
 * Copyright (C) 2010 Codership Oy <info@codership.com>
 *
 * $Id$
 */
#ifndef __gcache_page_test_hpp__
#define __gcache_page_test_hpp__

extern "C" {
#include <check.h>
}

extern Suite* gcache_page_suite();

#endif // __gcache_page_test_hpp__
