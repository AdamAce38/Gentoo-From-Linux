/*
 * Copyright (C) 2011 Codership Oy <info@codership.com>
 *
 * $Id$
 */
#ifndef __gcache_rb_test_hpp__
#define __gcache_rb_test_hpp__

extern "C" {
#include <check.h>
}

extern Suite* gcache_rb_suite();

#endif // __gcache_rb_test_hpp__
