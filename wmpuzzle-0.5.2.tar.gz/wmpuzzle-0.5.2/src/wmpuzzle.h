/* vim: set noet ts=4:
 *
 * Copyright (c) 2002-2013 Martin A. Godisch <martin@godisch.de>
 */

#ifndef WMPUZZLE_H_INCLUDED
#define WMPUZZLE_H_INCLUDED

#include <config.h>

#ifdef BSD
#include <daemon.xpm>
#else
#include <linux.xpm>
#endif

#define EINTERNAL 200
#define EINVALXPM 201
#define ESMALLXPM 202

void do_opts(int, char**, char***, int*, int*, int*, char**, char**);
static void handler(int);
void move(int);
void prepare(const char*);
char *read_state(char*);
void shuffle(int, char*);
int valid(int);
void write_state(void);
int transform(char***);

#endif
