##
adb shell /data/tmp/run.exe -s 5k -r 2k -i 1 -st 133 > CO.00
adb shell /data/tmp/run.exe -s 5k -r 2k -i 1 -st 1 > CO.01
adb shell /data/tmp/run.exe -s 5k -r 2k -i 1 -st 2 > CO.02
adb shell /data/tmp/run.exe -s 5k -r 2k -i 1 -st 3 > CO.03
adb shell /data/tmp/run.exe -s 5k -r 2k -i 1 -st 4 > CO.04
adb shell /data/tmp/run.exe -s 5k -r 2k -i 1 -st 5 > CO.05
adb shell /data/tmp/run.exe -s 5k -r 2k -i 1 -st 6 > CO.06
adb shell /data/tmp/run.exe -s 5k -r 2k -i 1 -st 7 > CO.07
adb shell /data/tmp/run.exe -s 5k -r 2k -i 1 -st 8 > CO.08
adb shell /data/tmp/run.exe -s 5k -r 2k -i 1 -st 37 > CO.09
##
adb shell /data/tmp/run.exe -s 50k -r 200 -i 1 -st 133 > CO.10
adb shell /data/tmp/run.exe -s 50k -r 200 -i 1 -st 1 > CO.11
adb shell /data/tmp/run.exe -s 50k -r 200 -i 1 -st 2 > CO.12
adb shell /data/tmp/run.exe -s 50k -r 200 -i 1 -st 3 > CO.13
adb shell /data/tmp/run.exe -s 50k -r 200 -i 1 -st 4 > CO.14
adb shell /data/tmp/run.exe -s 50k -r 200 -i 1 -st 5 > CO.15
adb shell /data/tmp/run.exe -s 50k -r 200 -i 1 -st 6 > CO.16
adb shell /data/tmp/run.exe -s 50k -r 200 -i 1 -st 7 > CO.17
adb shell /data/tmp/run.exe -s 50k -r 200 -i 1 -st 8 > CO.18
adb shell /data/tmp/run.exe -s 50k -r 200 -i 1 -st 37 > CO.19
##
adb shell /data/tmp/run.exe -s 500k -r 20 -i 1 -st 133 > CO.20
adb shell /data/tmp/run.exe -s 500k -r 20 -i 1 -st 1 > CO.21
adb shell /data/tmp/run.exe -s 500k -r 20 -i 1 -st 2 > CO.22
adb shell /data/tmp/run.exe -s 500k -r 20 -i 1 -st 3 > CO.23
adb shell /data/tmp/run.exe -s 500k -r 20 -i 1 -st 4 > CO.24
adb shell /data/tmp/run.exe -s 500k -r 20 -i 1 -st 5 > CO.25
adb shell /data/tmp/run.exe -s 500k -r 20 -i 1 -st 6 > CO.26
adb shell /data/tmp/run.exe -s 500k -r 20 -i 1 -st 7 > CO.27
adb shell /data/tmp/run.exe -s 500k -r 20 -i 1 -st 8 > CO.28
adb shell /data/tmp/run.exe -s 500k -r 20 -i 1 -st 37 > CO.29
##
adb shell /data/tmp/run.exe -s 5M -r 2 -i 1 -st 133 > CO.30
adb shell /data/tmp/run.exe -s 5M -r 2 -i 1 -st 1 > CO.31
adb shell /data/tmp/run.exe -s 5M -r 2 -i 1 -st 2 > CO.32
adb shell /data/tmp/run.exe -s 5M -r 2 -i 1 -st 3 > CO.33
adb shell /data/tmp/run.exe -s 5M -r 2 -i 1 -st 4 > CO.34
adb shell /data/tmp/run.exe -s 5M -r 2 -i 1 -st 5 > CO.35
adb shell /data/tmp/run.exe -s 5M -r 2 -i 1 -st 6 > CO.36
adb shell /data/tmp/run.exe -s 5M -r 2 -i 1 -st 7 > CO.37
adb shell /data/tmp/run.exe -s 5M -r 2 -i 1 -st 8 > CO.38
adb shell /data/tmp/run.exe -s 5M -r 2 -i 1 -st 37 > CO.39
