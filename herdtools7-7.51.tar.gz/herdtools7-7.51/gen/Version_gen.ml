include Version

let libdir = Filename.concat libdir "herd"
