# Released under the MIT License.
# Copyright, 2022, by Brad Schrag.
# Copyright, 2023, by Samuel Williams.

# This file serves as a placeholder for testing registry logic for the loading of a folder path.
