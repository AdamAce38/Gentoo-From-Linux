require 'gdk3/base'
require 'gdk3/deprecated'

