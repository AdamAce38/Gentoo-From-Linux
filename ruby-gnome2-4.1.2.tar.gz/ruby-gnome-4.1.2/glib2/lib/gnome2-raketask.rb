# Copyright(C) 2013-2015 Ruby-GNOME2 Project.
#
# This program is licenced under the same license of Ruby-GNOME2.

# Just for backward compatibility.
require "gnome2/rake/package-task"

GNOME2Package = GNOME2::Rake::PackageTask
