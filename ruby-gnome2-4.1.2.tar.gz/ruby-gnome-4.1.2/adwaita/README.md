# Ruby/Adwaita

Ruby/Adwaita is a Ruby binding of Adwaita.

## Requirements

* Ruby/GTK4 in [Ruby-GNOME](https://ruby-gnome.github.io/)
* [adwaita](https://gnome.pages.gitlab.gnome.org/libadwaita/)

## Install

    gem install adwaita

## License

Copyright (c) 2022  Ruby-GNOME Project Team

This program is free software. You can distribute/modify this program
under the terms of the GNU LESSER GENERAL PUBLIC LICENSE Version 2.1.

## Project Website

https://ruby-gnome.github.io/
