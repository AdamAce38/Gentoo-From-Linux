/* querycp.h is in the public domain */

#ifndef _WCD_QUERYCP_H
#define _WCD_QUERYCP_H

unsigned short query_con_codepage(void);
#endif
