#ifndef _WCD_WFIXPATH_H_
#define _WCD_WFIXPATH_H_

int wcd_is_slash(int c);
void wcd_fixpath(char *in, size_t lim) ;

#endif
