#!/usr/bin/env bash

./test/libs/bats/bin/bats test/*.bats
