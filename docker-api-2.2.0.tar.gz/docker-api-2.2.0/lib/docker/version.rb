module Docker
  # The version of the docker-api gem.
  VERSION = '2.2.0'
end
