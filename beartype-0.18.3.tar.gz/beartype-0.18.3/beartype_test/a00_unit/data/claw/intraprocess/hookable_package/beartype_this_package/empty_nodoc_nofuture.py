#!/usr/bin/env python3
# --------------------( LICENSE                            )--------------------
# Copyright (c) 2014-2024 Beartype authors.
# See "LICENSE" for further details.

# Literally empty submodule containing only zero or more whitespace characters
# and zero or more inline comments -- exercising a pernicious edge case in AST
# transformation that actually happened and destroyed everything.
