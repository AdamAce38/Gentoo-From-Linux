# frozen_string_literal: true
module Haml
  VERSION = '6.3.0'
end
