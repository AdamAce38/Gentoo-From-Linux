# benchmark

* `/benchmark/**/*.haml`: Use `/bin/bench` to run these.
* `/benchmark/slim/`: Run `/benchmark/slim/run-benchmarks.rb`.
