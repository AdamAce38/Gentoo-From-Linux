#ifndef COQUILLO_CRAWLER_TAGS_HPP
#define COQUILLO_CRAWLER_TAGS_HPP

#include "tag/generic.hpp"
#include "tag/id3v2.hpp"
#include "tag/xiphcomment.hpp"

#endif
