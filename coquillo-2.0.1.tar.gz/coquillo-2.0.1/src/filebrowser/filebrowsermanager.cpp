#include "filebrowsermanager.hpp"

namespace Coquillo {
    FileBrowserManager::FileBrowserManager(QObject * parent)
    : QObject(parent) {

    }
}
