#include "progresslistener.hpp"

namespace Coquillo {
    ProgressListener::ProgressListener(QObject * parent)
    : QObject(parent) {

    }
}
