<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="en_US" sourcelanguage="en_US">
<context>
    <name>BasicTags</name>
    <message>
        <location filename="../../ui/basictags.ui" line="23"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/basictags.ui" line="44"/>
        <source>/</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/basictags.ui" line="70"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Automatic numbering of selected files&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/basictags.ui" line="73"/>
        <source>#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/basictags.ui" line="102"/>
        <location filename="../../ui/basictags.ui" line="122"/>
        <location filename="../../ui/basictags.ui" line="142"/>
        <location filename="../../ui/basictags.ui" line="198"/>
        <location filename="../../ui/basictags.ui" line="247"/>
        <location filename="../../ui/basictags.ui" line="287"/>
        <location filename="../../ui/basictags.ui" line="310"/>
        <location filename="../../ui/basictags.ui" line="403"/>
        <location filename="../../ui/basictags.ui" line="426"/>
        <location filename="../../ui/basictags.ui" line="459"/>
        <location filename="../../ui/basictags.ui" line="525"/>
        <location filename="../../ui/basictags.ui" line="601"/>
        <location filename="../../ui/basictags.ui" line="651"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Copy value to other selected files&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/basictags.ui" line="165"/>
        <source>Composer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/basictags.ui" line="178"/>
        <source>&amp;Title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/basictags.ui" line="234"/>
        <source>&amp;Genre</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/basictags.ui" line="274"/>
        <source>Encoder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/basictags.ui" line="330"/>
        <source>Artist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/basictags.ui" line="350"/>
        <source>Comment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/basictags.ui" line="370"/>
        <source>A&amp;lbum</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/basictags.ui" line="383"/>
        <source>&amp;Number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/basictags.ui" line="446"/>
        <source>Album artist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/basictags.ui" line="482"/>
        <source>&amp;Year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/basictags.ui" line="567"/>
        <source>&amp;Disc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/basictags.ui" line="588"/>
        <source>&amp;URL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/basictags.ui" line="638"/>
        <source>Orig. artist</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Coquillo::FileBrowser</name>
    <message>
        <location filename="../../src/filebrowser/filebrowser.cpp" line="202"/>
        <source>Entry name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/filebrowser/filebrowser.cpp" line="203"/>
        <source>Give a name for this entry</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Coquillo::HeaderDataModel</name>
    <message>
        <location filename="../../src/headerdatamodel.cpp" line="34"/>
        <source>Label</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Coquillo::ItemCountLabel</name>
    <message>
        <location filename="../../src/itemcountlabel.cpp" line="19"/>
        <source>No files</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Coquillo::MainWindow</name>
    <message>
        <location filename="../../src/mainwindow.cpp" line="62"/>
        <source>Menubar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="68"/>
        <source>Statusbar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="76"/>
        <source>Lock toolbars</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="108"/>
        <source>Files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="169"/>
        <source>Parse tags</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="180"/>
        <source>Rename files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/mainwindow.cpp" line="294"/>
        <source>Show modification indicator</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Coquillo::Settings::SettingsDialog</name>
    <message>
        <location filename="../../src/settings/settingsdialog.cpp" line="64"/>
        <source>Select directory</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Coquillo::TagEditor::ImageModel</name>
    <message>
        <location filename="../../src/tageditor/imagemodel.cpp" line="111"/>
        <source>Image</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/tageditor/imagemodel.cpp" line="111"/>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/tageditor/imagemodel.cpp" line="111"/>
        <source>Description</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Coquillo::TagEditor::ImageTags</name>
    <message>
        <location filename="../../src/tageditor/imagetags.cpp" line="46"/>
        <source>Import images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/tageditor/imagetags.cpp" line="65"/>
        <source>Export image to</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Coquillo::TagEditor::RawData</name>
    <message>
        <location filename="../../src/tageditor/rawdata.cpp" line="19"/>
        <source>Field</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/tageditor/rawdata.cpp" line="19"/>
        <source>Value</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/tageditor/rawdata.cpp" line="55"/>
        <source>%1 values</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Coquillo::TagEditor::TagEditor</name>
    <message>
        <location filename="../../src/tageditor/tageditor.cpp" line="18"/>
        <source>Basic</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/tageditor/tageditor.cpp" line="19"/>
        <location filename="../../src/tageditor/tageditor.cpp" line="61"/>
        <source>Images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/tageditor/tageditor.cpp" line="20"/>
        <source>Raw</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Coquillo::Tags::ImageTypes</name>
    <message>
        <location filename="../../src/tags/imagetypes.cpp" line="14"/>
        <source>Other</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/tags/imagetypes.cpp" line="15"/>
        <source>File icon (PNG. 32x32 px</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/tags/imagetypes.cpp" line="16"/>
        <source>File icon (other format)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/tags/imagetypes.cpp" line="17"/>
        <source>Front cover</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/tags/imagetypes.cpp" line="18"/>
        <source>Back cover</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/tags/imagetypes.cpp" line="19"/>
        <source>Leaflet page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/tags/imagetypes.cpp" line="20"/>
        <source>Image from album</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/tags/imagetypes.cpp" line="21"/>
        <source>Lead artist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/tags/imagetypes.cpp" line="22"/>
        <source>Artist or performer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/tags/imagetypes.cpp" line="23"/>
        <source>Conductor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/tags/imagetypes.cpp" line="24"/>
        <source>Band</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/tags/imagetypes.cpp" line="25"/>
        <source>Composer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/tags/imagetypes.cpp" line="26"/>
        <source>Lyricist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/tags/imagetypes.cpp" line="27"/>
        <source>Recording location</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/tags/imagetypes.cpp" line="28"/>
        <source>Artist during recording</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/tags/imagetypes.cpp" line="29"/>
        <source>Artist during performance</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/tags/imagetypes.cpp" line="30"/>
        <source>Movie screenshot</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/tags/imagetypes.cpp" line="31"/>
        <source>Illustration</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/tags/imagetypes.cpp" line="32"/>
        <source>Band logo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/tags/imagetypes.cpp" line="33"/>
        <source>Publisher logo</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Coquillo::Tags::TagsModel</name>
    <message>
        <location filename="../../src/tags/tagsmodel.cpp" line="20"/>
        <source>Title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/tags/tagsmodel.cpp" line="21"/>
        <source>Artist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/tags/tagsmodel.cpp" line="22"/>
        <source>Album</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/tags/tagsmodel.cpp" line="23"/>
        <source>Genre</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/tags/tagsmodel.cpp" line="24"/>
        <source>Comment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/tags/tagsmodel.cpp" line="25"/>
        <source>Year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/tags/tagsmodel.cpp" line="26"/>
        <source>#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/tags/tagsmodel.cpp" line="27"/>
        <source>Total</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/tags/tagsmodel.cpp" line="28"/>
        <source>Disc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/tags/tagsmodel.cpp" line="29"/>
        <source>Original Artist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/tags/tagsmodel.cpp" line="30"/>
        <source>Album Artist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/tags/tagsmodel.cpp" line="31"/>
        <source>Composer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/tags/tagsmodel.cpp" line="32"/>
        <source>URL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/tags/tagsmodel.cpp" line="33"/>
        <source>Encoder</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/tags/tagsmodel.cpp" line="34"/>
        <source>Filename</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/tags/tagsmodel.cpp" line="35"/>
        <source>Images</source>
        <translation type="unfinished"></translation>
    </message>
    <message numerus="yes">
        <location filename="../../src/tags/tagsmodel.cpp" line="88"/>
        <source>%n image(s)</source>
        <translation>
            <numerusform>1 image</numerusform>
            <numerusform>%n images</numerusform>
        </translation>
    </message>
</context>
<context>
    <name>Coquillo::WebTags::AlbumDetailsModel</name>
    <message>
        <location filename="../../src/webtags/albumdetailsmodel.cpp" line="13"/>
        <source>Title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/webtags/albumdetailsmodel.cpp" line="13"/>
        <source>Artist</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Coquillo::WebTags::TagSearchDialog</name>
    <message>
        <location filename="../../src/webtags/tagsearchdialog.cpp" line="29"/>
        <source>Album</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/webtags/tagsearchdialog.cpp" line="29"/>
        <source>Artist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/webtags/tagsearchdialog.cpp" line="29"/>
        <source>D#</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../src/webtags/tagsearchdialog.cpp" line="29"/>
        <source>ID</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>FileBrowser</name>
    <message>
        <location filename="../../ui/filebrowser.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/filebrowser.ui" line="22"/>
        <source>Up</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/filebrowser.ui" line="49"/>
        <source>Bookmark</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/filebrowser.ui" line="77"/>
        <source>Change to directory...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/filebrowser.ui" line="110"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Check this to include all children of selected directories&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/filebrowser.ui" line="113"/>
        <source>Include subdirectories</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ImageTags</name>
    <message>
        <location filename="../../ui/imagetags.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/imagetags.ui" line="47"/>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/imagetags.ui" line="60"/>
        <source>Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/imagetags.ui" line="80"/>
        <source>Export selected images to disk</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/imagetags.ui" line="83"/>
        <source>Export</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/imagetags.ui" line="94"/>
        <source>Import images from disk</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/imagetags.ui" line="97"/>
        <source>Add</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/imagetags.ui" line="108"/>
        <source>Remove selected images</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/imagetags.ui" line="111"/>
        <source>Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/imagetags.ui" line="135"/>
        <source>Apply image set to all selected files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/imagetags.ui" line="138"/>
        <source>Apply to all</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>MainWindow</name>
    <message>
        <location filename="../../ui/mainwindow.ui" line="14"/>
        <source>Coquillo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/mainwindow.ui" line="79"/>
        <source>&amp;Coquillo</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/mainwindow.ui" line="85"/>
        <source>&amp;Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/mainwindow.ui" line="100"/>
        <source>Main Toolbar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/mainwindow.ui" line="123"/>
        <source>&amp;Quit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/mainwindow.ui" line="126"/>
        <source>Exit application</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/mainwindow.ui" line="129"/>
        <source>Ctrl+Q</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/mainwindow.ui" line="137"/>
        <source>&amp;Configure...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/mainwindow.ui" line="140"/>
        <source>Open settings dialog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/mainwindow.ui" line="151"/>
        <source>&amp;Menubar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/mainwindow.ui" line="154"/>
        <source>Toggle menubar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/mainwindow.ui" line="157"/>
        <source>Ctrl+M</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/mainwindow.ui" line="165"/>
        <source>&amp;Statusbar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/mainwindow.ui" line="168"/>
        <source>Toggle statusbar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/mainwindow.ui" line="177"/>
        <source>Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/mainwindow.ui" line="180"/>
        <source>Write changes into the files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/mainwindow.ui" line="183"/>
        <source>Ctrl+S</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/mainwindow.ui" line="192"/>
        <source>Revert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/mainwindow.ui" line="195"/>
        <source>Discard all changes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/mainwindow.ui" line="204"/>
        <source>Reload</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/mainwindow.ui" line="207"/>
        <source>Reload selected directories and discard changes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/mainwindow.ui" line="210"/>
        <source>Ctrl+R</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/mainwindow.ui" line="219"/>
        <source>Select All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/mainwindow.ui" line="222"/>
        <source>Select all items</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/mainwindow.ui" line="225"/>
        <source>Ctrl+A</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/mainwindow.ui" line="234"/>
        <source>Abort</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/mainwindow.ui" line="237"/>
        <source>Abort current action</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/mainwindow.ui" line="240"/>
        <source>Esc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/mainwindow.ui" line="251"/>
        <source>&amp;Toolbar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/mainwindow.ui" line="254"/>
        <source>Toggle toolbar</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/mainwindow.ui" line="263"/>
        <source>Next item</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/mainwindow.ui" line="266"/>
        <source>Select next item</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/mainwindow.ui" line="269"/>
        <source>PgDown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/mainwindow.ui" line="278"/>
        <source>Previous item</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/mainwindow.ui" line="281"/>
        <source>Select previous item</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/mainwindow.ui" line="284"/>
        <source>PgUp</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/mainwindow.ui" line="296"/>
        <source>Open tag search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/mainwindow.ui" line="299"/>
        <source>Search for tags on the internet</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ParserWidget</name>
    <message>
        <location filename="../../ui/parserwidget.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/parserwidget.ui" line="20"/>
        <source>Pattern</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/parserwidget.ui" line="36"/>
        <source>(Preview)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/parserwidget.ui" line="58"/>
        <source>Legend</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/parserwidget.ui" line="69"/>
        <source>Name of the artist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/parserwidget.ui" line="72"/>
        <source>%a: artist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/parserwidget.ui" line="87"/>
        <source>Name of the album</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/parserwidget.ui" line="90"/>
        <source>%b: album</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/parserwidget.ui" line="105"/>
        <source>Content of comment field</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/parserwidget.ui" line="108"/>
        <source>%c: comment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/parserwidget.ui" line="123"/>
        <source>Disc number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/parserwidget.ui" line="126"/>
        <source>%d: disc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/parserwidget.ui" line="141"/>
        <source>Genre of the track</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/parserwidget.ui" line="144"/>
        <source>%g: genre</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/parserwidget.ui" line="159"/>
        <source>Number of tracks in the set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/parserwidget.ui" line="162"/>
        <source>%m: tracks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/parserwidget.ui" line="177"/>
        <source>Track number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/parserwidget.ui" line="180"/>
        <source>%n: track</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/parserwidget.ui" line="195"/>
        <source>Original artist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/parserwidget.ui" line="198"/>
        <source>%o: orig. art.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/parserwidget.ui" line="213"/>
        <source>Name of the composer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/parserwidget.ui" line="216"/>
        <source>%p: composer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/parserwidget.ui" line="231"/>
        <source>Year of release</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/parserwidget.ui" line="234"/>
        <source>%y: year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/parserwidget.ui" line="249"/>
        <source>Name of the track</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/parserwidget.ui" line="252"/>
        <source>%t: title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/parserwidget.ui" line="267"/>
        <source>Album artist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/parserwidget.ui" line="270"/>
        <source>%q: album art.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/parserwidget.ui" line="282"/>
        <source>%i: ignore</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/parserwidget.ui" line="307"/>
        <source>&amp;Apply</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RawData</name>
    <message>
        <location filename="../../ui/rawdata.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/rawdata.ui" line="20"/>
        <source>This is a read-only view of the raw metadata contained in the file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/rawdata.ui" line="30"/>
        <source>Tag</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>RenameWidget</name>
    <message>
        <location filename="../../ui/renamewidget.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/renamewidget.ui" line="20"/>
        <source>Pattern</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/renamewidget.ui" line="36"/>
        <source>(Preview)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/renamewidget.ui" line="58"/>
        <source>Legend</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/renamewidget.ui" line="69"/>
        <source>Name of the artist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/renamewidget.ui" line="72"/>
        <source>%a: artist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/renamewidget.ui" line="87"/>
        <source>Name of the album</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/renamewidget.ui" line="90"/>
        <source>%b: album</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/renamewidget.ui" line="105"/>
        <source>Content of comment field</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/renamewidget.ui" line="108"/>
        <source>%c: comment</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/renamewidget.ui" line="123"/>
        <source>Disc number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/renamewidget.ui" line="126"/>
        <source>%d: disc</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/renamewidget.ui" line="141"/>
        <source>Genre of the track</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/renamewidget.ui" line="144"/>
        <source>%g: genre</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/renamewidget.ui" line="159"/>
        <source>Number of tracks in the set</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/renamewidget.ui" line="162"/>
        <source>%m: tracks</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/renamewidget.ui" line="177"/>
        <source>Track number</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/renamewidget.ui" line="180"/>
        <source>%n: track</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/renamewidget.ui" line="195"/>
        <source>Original artist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/renamewidget.ui" line="198"/>
        <source>%o: orig. art.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/renamewidget.ui" line="213"/>
        <source>Name of the composer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/renamewidget.ui" line="216"/>
        <source>%p: composer</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/renamewidget.ui" line="231"/>
        <source>Year of release</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/renamewidget.ui" line="234"/>
        <source>%y: year</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/renamewidget.ui" line="249"/>
        <source>Name of the track</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/renamewidget.ui" line="252"/>
        <source>%t: title</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/renamewidget.ui" line="267"/>
        <source>Album artist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/renamewidget.ui" line="270"/>
        <source>%q: album art.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/renamewidget.ui" line="295"/>
        <source>&amp;Apply</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SettingsDialog</name>
    <message>
        <location filename="../../ui/settingsdialog.ui" line="14"/>
        <source>Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/settingsdialog.ui" line="24"/>
        <location filename="../../ui/settingsdialog.ui" line="96"/>
        <source>General</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/settingsdialog.ui" line="30"/>
        <source>Home Directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/settingsdialog.ui" line="39"/>
        <source>Select directory</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/settingsdialog.ui" line="53"/>
        <source>Behaviour</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/settingsdialog.ui" line="59"/>
        <source>Use safe filenames for portability</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/settingsdialog.ui" line="66"/>
        <source>Remove empty directories after renaming files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/settingsdialog.ui" line="90"/>
        <source>Tags</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/settingsdialog.ui" line="104"/>
        <source>Scale pictures to</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/settingsdialog.ui" line="130"/>
        <source>x</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/settingsdialog.ui" line="159"/>
        <source>px</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/settingsdialog.ui" line="181"/>
        <source>Parse disc number from album name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/settingsdialog.ui" line="193"/>
        <source>Searches for &quot;(Disc %d)&quot; and &quot;(CD %d)&quot;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/settingsdialog.ui" line="208"/>
        <source>Pad numbers in filenames to width</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/settingsdialog.ui" line="251"/>
        <source>Affects capital symbols %D, %M, %N</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/settingsdialog.ui" line="264"/>
        <source>MPEG (.mp3)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/settingsdialog.ui" line="270"/>
        <source>Write ID3v1 tags in addition to ID3v2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/settingsdialog.ui" line="280"/>
        <source>FLAC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/settingsdialog.ui" line="286"/>
        <source>Write ID3v2 tags in addition to native tags</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>SortPicker</name>
    <message>
        <location filename="../../ui/sortpicker.ui" line="14"/>
        <source>Form</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/sortpicker.ui" line="32"/>
        <source>Sort by</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/sortpicker.ui" line="48"/>
        <source>Order items by column.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TagSearchDialog</name>
    <message>
        <location filename="../../ui/tagsearchdialog.ui" line="14"/>
        <source>Query web database</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/tagsearchdialog.ui" line="24"/>
        <location filename="../../ui/tagsearchdialog.ui" line="104"/>
        <source>Search</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/tagsearchdialog.ui" line="30"/>
        <source>Keywords</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/tagsearchdialog.ui" line="36"/>
        <source>Album</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/tagsearchdialog.ui" line="43"/>
        <source>Artist</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/tagsearchdialog.ui" line="123"/>
        <source>Results</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/tagsearchdialog.ui" line="184"/>
        <location filename="../../ui/tagsearchdialog.ui" line="323"/>
        <source>Album Details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/tagsearchdialog.ui" line="240"/>
        <source>Customize results</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/tagsearchdialog.ui" line="246"/>
        <source>Selected files</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../../ui/tagsearchdialog.ui" line="265"/>
        <location filename="../../ui/tagsearchdialog.ui" line="275"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
</context>
</TS>
