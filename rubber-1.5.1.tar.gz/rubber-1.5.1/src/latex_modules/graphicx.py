# The 'graphics' and 'graphicx' packages are treated as equivalent.
import rubber.latex_modules.graphics
# No need to even inherit.
Module = rubber.latex_modules.graphics.Module
