package a.b
package c {
  object A
}
package c {
  package object d {
    val hello: String = "there"
  }
}
