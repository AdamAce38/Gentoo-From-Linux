#ifndef __STDBOOL_H__
#define __STDBOOL_H__

#ifndef __cplusplus

typedef unsigned int bool;

#define true 1
#define false 0

#endif //__cplusplus

#endif //__STDBOOL_H__