#ifndef CGREEN_RUNNER_H
#define CGREEN_RUNNER_H

/* Cgreen runner module */

extern int runner(TestReporter *reporter, const char *test_library, const char *suite_name, const char *test_name, bool verbose, bool no_run);

#endif
