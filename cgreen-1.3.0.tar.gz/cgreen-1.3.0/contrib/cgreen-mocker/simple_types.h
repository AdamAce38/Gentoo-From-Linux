int return_int(void);
char return_char(char c);
char* return_pointer_to_char(char *string);
