double return_double(double d, int i);
