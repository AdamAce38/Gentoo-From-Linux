#include <string.h>

int split_words(char *sentence) {
    return 0;
}
