int split_words(char *sentence);
void words(const char *sentence, void (*callback)(const char *, void *), void *memo);
