/* config.h.in.  Generated automatically from configure.in by autoheader.  */

#undef PATH_SEPARATOR

/* Define if you don't have tm_zone but do have the external array
   tzname.  */
/* #undef HAVE_TZNAME */

/* Define if you have the ANSI C header files.  */
#define STDC_HEADERS 1

/* Define if you have the <unistd.h> header file.  */
#define HAVE_UNISTD_H 1

/* Define if you have the z library (-lz).  */
#define HAVE_LIBZ 1

/* Define if you have the z library (-lbz2).  */
#define HAVE_LIBBZ2 1

/* Define if you can safely include both <sys/time.h> and <time.h>.  */
#define TIME_WITH_SYS_TIME 1

/* Define if you have the <sys/time.h> header file.  */
#define HAVE_SYS_TIME_H 1

/* Define if you have the <unixlib/local.h> header file.  */
#define HAVE_UNIXLIB_LOCAL_H 1

/* Define if your struct tm has tm_zone.  */
#define HAVE_STRUCT_TM_TM_ZONE 1
