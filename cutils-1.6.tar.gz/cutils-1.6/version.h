#define CUTILS_VERSION "cutils 1.6"
