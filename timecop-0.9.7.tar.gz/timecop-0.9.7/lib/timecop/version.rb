class Timecop
  VERSION = "0.9.7"
end
