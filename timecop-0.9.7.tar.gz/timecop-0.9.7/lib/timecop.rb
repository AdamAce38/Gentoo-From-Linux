require File.join(File.dirname(__FILE__), "timecop", "timecop")
require File.join(File.dirname(__FILE__), "timecop", "version")
