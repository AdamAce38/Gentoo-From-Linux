class Admin < User
  has_many :companies
end
