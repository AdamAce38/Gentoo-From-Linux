void myprint(void);
