#include <stdio.h>
#include "myclib.h"

void myprint(void) {
  printf("hello from C\n");
}
