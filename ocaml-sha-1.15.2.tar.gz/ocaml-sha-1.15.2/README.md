General Information
===================
This is the binding for SHA interface code in OCaml. Offering the same
interface than the MD5 digest included in ocaml standard library.
It's currently providing SHA1, SHA256 and SHA512 hash functions.

This library is licensed under the
[ISC license](https://opensource.org/licenses/ISC).

Documentation
=============
the documentation can be found in mli files in ocamldoc format.
