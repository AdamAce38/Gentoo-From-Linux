-- from http://www.roesler-ac.de/wolfram/hello.htm
-- Hello World in Haskell

module Hello where
hello::String
hello = "Hello World!"
