int set_port_speed(char *host, char *community, char *port, long speed, int  duplex);

