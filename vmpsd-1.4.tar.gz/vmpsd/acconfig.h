/* Define if you have UCD SNMP  */ 
#undef HAVE_SNMP 

