# frozen_string_literal: true

# Released under the MIT License.
# Copyright, 2022, by Samuel Williams.

class Acorn; end
class Banana; end
class Cat; end
class Dog; end
