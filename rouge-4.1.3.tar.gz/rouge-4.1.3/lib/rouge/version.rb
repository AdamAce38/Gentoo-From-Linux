# -*- coding: utf-8 -*- #
# frozen_string_literal: true

module Rouge
  def self.version
    "4.1.3"
  end
end
