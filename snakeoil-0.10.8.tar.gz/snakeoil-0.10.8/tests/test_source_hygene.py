from snakeoil.test.modules import ExportedModules


class Test_modules(ExportedModules):
    pass
