from snakeoil.test.slot_shadowing import SlotShadowing


class Test_slot_shadowing(SlotShadowing):
    pass
