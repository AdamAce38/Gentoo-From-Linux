"""Various command-line related support"""
