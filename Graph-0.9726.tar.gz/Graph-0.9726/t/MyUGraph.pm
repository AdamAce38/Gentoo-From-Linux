package UGraph;
use strict; use warnings;
require Graph::Undirected;
@UGraph::ISA=qw(Graph::Undirected);
1;
