package DGraph;
use strict; use warnings;
require Graph::Directed;
@DGraph::ISA=qw(Graph::Directed);
1;
