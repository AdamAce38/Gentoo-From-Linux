package MyGraph;

use strict; use warnings;
use Graph;
use base 'Graph';

1;
