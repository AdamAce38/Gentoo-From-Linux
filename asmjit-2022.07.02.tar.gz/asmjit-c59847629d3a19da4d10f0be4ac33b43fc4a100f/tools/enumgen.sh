#!/usr/bin/env sh
set -e
node ./enumgen.js $@
