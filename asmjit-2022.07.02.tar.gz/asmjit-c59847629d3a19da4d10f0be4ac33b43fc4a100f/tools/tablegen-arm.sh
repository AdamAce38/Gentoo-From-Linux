#!/bin/sh

node ./tablegen-arm.js
