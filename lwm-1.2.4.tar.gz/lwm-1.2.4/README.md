lwm
===

*lwm* is a window manager for X that tries to keep out of your face. There are no icons, no button bars, no icon docks, no root menus, no nothing: if you want all that, then other programs can provide it. There's no configurability either: if you want that, you want a different window manager; one that helps your operating system in its evil conquest of your disc space and its annexation of your physical memory. 

[http://www.jfc.org.uk/software/lwm.html](http://www.jfc.org.uk/software/lwm.html)

