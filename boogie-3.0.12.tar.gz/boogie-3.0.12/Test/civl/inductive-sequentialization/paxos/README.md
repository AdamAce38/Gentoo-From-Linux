* `Paxos.bpl`: Shared definitions (types, consts, functions, axioms, shared vars)
* `PaxosActions.bpl`: Atomic actions of event handlers
* `PaxosSeq.bpl`: IS proof
* `PaxosImpl.bpl`: Low-level implementation
* `is.sh`: script for running the test
