## Zutty - Zero-cost Unicode Teletype

Before coming into serious contact with Zutty (e.g., reporting a bug,
*asking for anything*), all the below pages are **required reading**:

- [README](https://tomscii.sig7.se/zutty)
- [User guide](https://tomscii.sig7.se/zutty/doc/USAGE.html)
- [Frequently Asked Questions](https://tomscii.sig7.se/zutty/wiki/FAQ.html)
