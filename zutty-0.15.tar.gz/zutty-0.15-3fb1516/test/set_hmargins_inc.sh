printf "\\e[?69h\\e[20;60s"
