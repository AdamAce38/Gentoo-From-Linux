export PS1="\u@\h:\w$ "
export PROMPT_COMMAND=
