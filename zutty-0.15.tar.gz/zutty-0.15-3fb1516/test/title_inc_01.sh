printf "\e]0;one two three ...\e\\"
