import Config
config :kernel, :elixir_reboot, true
config :elixir_reboot, :key, :value
