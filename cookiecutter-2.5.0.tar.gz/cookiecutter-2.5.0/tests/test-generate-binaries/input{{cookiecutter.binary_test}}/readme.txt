I eat {{ cookiecutter.binary_test }}
