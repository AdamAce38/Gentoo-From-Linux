History
-------

0.1.0 ({% now 'utc', '%Y-%m-%d' %})
{{ "-" * 18 }}

First release on PyPI.
