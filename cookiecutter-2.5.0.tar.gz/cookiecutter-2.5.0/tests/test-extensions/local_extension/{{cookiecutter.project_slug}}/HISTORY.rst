History
-------

0.1.0
-----

First release of {{cookiecutter.test_value_class_based}} on PyPI.
{{cookiecutter.test_value_function_based}}
