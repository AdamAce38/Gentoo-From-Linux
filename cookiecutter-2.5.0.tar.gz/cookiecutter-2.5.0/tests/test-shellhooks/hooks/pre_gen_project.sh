#!/bin/bash

echo 'pre generation hook';
touch 'shell_pre.txt'
