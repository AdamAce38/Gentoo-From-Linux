#!/bin/bash

echo 'Pre-Prompt hook';
touch '_cookiecutter.json'
