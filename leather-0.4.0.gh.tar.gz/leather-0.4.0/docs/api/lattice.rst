=======
Lattice
=======

.. automodule:: leather.lattice
    :no-members:

.. autoclass:: leather.Lattice
