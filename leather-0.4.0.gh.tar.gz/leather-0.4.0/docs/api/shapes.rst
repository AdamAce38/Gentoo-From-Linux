======
Shapes
======

.. automodule:: leather.shapes
    :no-members:

.. autoclass:: leather.Shape

.. autoclass:: leather.Bars

.. autoclass:: leather.Columns

.. autoclass:: leather.Dots

.. autoclass:: leather.Line

.. autofunction:: leather.style_function
