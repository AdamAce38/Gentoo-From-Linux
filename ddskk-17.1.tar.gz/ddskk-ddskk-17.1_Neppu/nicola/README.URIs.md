
- 日本語入力コンソーシアム (NICOLA)

  http://nicola.sunicom.co.jp/


- NICOLA 配列 (NIHONGO-NYURYOKU CONSORTIUM LAYOUT) 規格書

  http://nicola.sunicom.co.jp/spec/kikaku.htm


- Q's Nicolatter for X

  http://www.nslabs.jp/xnicolatter.rhtml


- OASYS のホームページ

  http://www.ykanda.jp/


- リンク切れ

  - キーボード工房，omelet

    http://www.eva.hi-ho.ne.jp/%7Eminoura/kbd/

  - NICOLA-SKK

    http://www.eva.hi-ho.ne.jp/%7Eminoura/kbd/skk.html

  - scim-anthy

    http://scim-imengine.sourceforge.jp/hiki.cgi?SCIMAnthy



<!--
Local Variables:
   mode: markdown
   coding: utf-8
End:
 -->
