#######
Copying
#######

Copyright 1991-2007 Masahiko Sato（佐藤雅彦）,
Yukiyoshi Kameyama（亀山幸義）, NAKAJIMA Mikio（中島幹夫）,
IRIE Tetsuya（入江）, Kitamoto Tsuyoshi（北本剛）,
Teika Kazura（定家）, Tsukamoto Tetsuo（塚本徹雄）
and Tsuyoshi AKIHO（秋保強）.
Revised by Kiyotaka Sakai（酒井清隆） and Satoshi Harauchi（原内聡）.

Permission is granted to make and distribute verbatim copies of
this manual provided the copyright notice and this permission notice
are preserved on all copies.

Permission is granted to copy and distribute modified versions of this
manual under the conditions for verbatim copying, provided that the
entire resulting derived work is distributed under the terms of a
permission notice identical to this one.

Permission is granted to copy and distribute translations of this manual
into another language, under the above conditions for modified versions,
except that this permission notice may be stated in a translation
approved by the author.
