|PyPi|_ |Conda|_ |Supported Python versions|_ |GitHub Actions|_ |Codecov|_

.. |PyPi| image:: https://img.shields.io/pypi/v/cycler.svg?style=flat
.. _PyPi: https://pypi.python.org/pypi/cycler

.. |Conda| image:: https://img.shields.io/conda/v/conda-forge/cycler
.. _Conda:  https://anaconda.org/conda-forge/cycler

.. |Supported Python versions| image:: https://img.shields.io/pypi/pyversions/cycler.svg
.. _Supported Python versions: https://pypi.python.org/pypi/cycler

.. |GitHub Actions| image:: https://github.com/matplotlib/cycler/actions/workflows/tests.yml/badge.svg
.. _GitHub Actions: https://github.com/matplotlib/cycler/actions

.. |Codecov| image:: https://codecov.io/github/matplotlib/cycler/badge.svg?branch=main&service=github
.. _Codecov: https://codecov.io/github/matplotlib/cycler?branch=main

cycler: composable cycles
=========================

Docs: https://matplotlib.org/cycler/
