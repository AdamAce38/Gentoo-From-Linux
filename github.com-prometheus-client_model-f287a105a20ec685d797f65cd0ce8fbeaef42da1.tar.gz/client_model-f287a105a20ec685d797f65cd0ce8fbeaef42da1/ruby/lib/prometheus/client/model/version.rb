module Prometheus
  module Client
    module Model
      VERSION = '0.1.0'
    end
  end
end
