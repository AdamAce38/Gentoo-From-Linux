#!/bin/sh

vim -c 'cexpr system("bin/vint test/fixture/cli/vital.vim")'
