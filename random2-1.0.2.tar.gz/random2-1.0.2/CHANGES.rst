=======
CHANGES
=======

1.0.2 (2023-12-18)
------------------

- Change support to Python 3.10, 3.11, 3.12, and 3.13 only.


1.0.1 (2013-03-15)
------------------

- Fix setup.py so that an install of the package will actually work.


1.0.0 (2013-03-06)
------------------

- Initial PyPI release.
