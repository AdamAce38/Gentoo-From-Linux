.. -*- mode: rst -*-

Contributors
============

This is the (preliminary) list of contributors in no particular order:

- Dinu Gherman
- Claude Paroz
- Sebastian Wehrmann
- Robin Becker
- Tom Turner

If you are not listed here, but feel like you should be, please contact
the maintainers. If you create a pull request, feel free to add your
name to this file, too!
