LICENSES
========

The SVG samples in this folder are included under the following licenses.
(More license information for other files to be added...)

``Berlin_location_map.svg``

- Source: Wikimedia.org,
  https://commons.wikimedia.org/wiki/File:Berlin_location_map.svg
- License: Creative Commons Attribution-Share Alike 3.0 Unported,
  https://creativecommons.org/licenses/by-sa/3.0/deed.en
- Comment: ``Berlin_location_map_gz.svgz`` is a gzipped version of
  ``Berlin_location_map.svg``.

``test_part.svg``

- Source: Andy Brock
- License: Creative Commons Attribution-Share Alike 3.0 Unported,
  https://creativecommons.org/licenses/by-sa/3.0/deed.en

