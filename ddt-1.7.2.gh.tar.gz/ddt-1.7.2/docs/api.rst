API
===

.. automodule:: ddt
    :members:

.. automodule:: named_data
    :members: