from collections import OrderedDict


class Snapshot(OrderedDict):
    pass
