#!/bin/sh

for i in man/*.2; do
  echo $i
done
