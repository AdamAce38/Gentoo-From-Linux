# SPDX-License-Identifier: LGPL-2.1-or-later
#
# This file is part of libnvme.
# Copyright (c) 2022 Dell Inc.
#
# Authors: Martin Belanger <Martin.Belanger@dell.com>

__version__ = @PROJECT_VERSION@
__git_version__ = @GIT_VERSION@
