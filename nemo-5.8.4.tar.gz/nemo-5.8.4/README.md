![build](https://github.com/linuxmint/nemo/actions/workflows/build.yml/badge.svg)

Nemo
====
File Manager for Cinnamon

Nemo is the file manager for the Cinnamon desktop environment. 
