# frozen_string_literal: true

class Model < ActiveRecord::Base
  self.table_name = "dummy_table"
end
