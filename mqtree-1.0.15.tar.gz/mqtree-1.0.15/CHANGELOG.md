# Version 1.0.15

* Updating p1_utils to version 1.0.25.

# Version 1.0.14

* Updating p1_utils to version 1.0.23.
* Switch from using Travis to Github Actions as CI

# Version 1.0.13

* Updating p1_utils to version 1.0.22.

# Version 1.0.12

* Add missing applications to mqtree.app

# Version 1.0.11

* Updating p1_utils to version 1.0.21.
* Don't link with ssl/crypto libs

# Version 1.0.10

* Updating p1_utils to version 1.0.20.

# Version 1.0.9

* Copy recent rebar.config.script from fast_tls
* Add support for Travis and Erlang/OTP 23.0

# Version 1.0.8

* Updating p1_utils to version 1.0.19.

# Version 1.0.7

* Updating p1_utils to version 1.0.18.
* Update copyright year

# Version 1.0.6

* Updating p1_utils to version 1.0.17.
* Fix repo url in README

# Version 1.0.5

* Improve dialyzer handling

