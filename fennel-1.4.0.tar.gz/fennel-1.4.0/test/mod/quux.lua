return foo or false
