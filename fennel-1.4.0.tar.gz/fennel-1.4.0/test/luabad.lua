return {bad=function() assert(_G["io"]) return "bad" end}
