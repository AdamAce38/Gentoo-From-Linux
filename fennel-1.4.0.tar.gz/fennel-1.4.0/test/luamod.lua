return {abc=function() return "abc" end}
