@protocol V
(V(V(V(V(V(V
/*  Takne from #2053 submitted by @chrismwendt */
