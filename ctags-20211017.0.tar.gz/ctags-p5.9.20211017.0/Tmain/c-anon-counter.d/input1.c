enum {
  A, B,
} x;

struct {
  int C, D;
} y;

union {
  int E, F;
} z;
