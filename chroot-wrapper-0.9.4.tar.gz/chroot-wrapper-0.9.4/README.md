Wrapper for chroot that sets up some namespaces and basic bind mounts before
calling chroot. Supports control groups as well, configured via a
configuration file.
