{
  :type => :git,
}
