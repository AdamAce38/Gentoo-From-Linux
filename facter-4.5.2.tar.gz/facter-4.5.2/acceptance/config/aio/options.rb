{
  :type => 'aio',
}
