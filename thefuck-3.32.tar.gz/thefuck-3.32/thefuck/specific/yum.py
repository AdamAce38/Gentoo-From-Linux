from thefuck.utils import which

yum_available = bool(which('yum'))
