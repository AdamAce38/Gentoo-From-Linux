# Alumni

Thanks to the following folks who used to maintain Cosign (please keep this
list sorted)!

- [**@asraa**](https://github.com/asraa)
- [**@dlorenc**](https://github.com/dlorenc)
- [**@font**](https://github.com/font)
- [**@loosebazooka**](https://github.com/loosebazooka)
- [**@luhring**](https://github.com/luhring)
- [**@lukehinds**](https://github.com/lukehinds)
- [**@n3wscott**](https://github.com/n3wscott)
- [**@vaikas**](https://github.com/vaikas)
