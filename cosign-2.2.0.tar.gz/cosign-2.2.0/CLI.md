# Cosign CLI Conventions

* The *primary* output of any command should be to STDOUT. The format should be
  described in the documentation of each command.
* Output to STDERR is informational only.
