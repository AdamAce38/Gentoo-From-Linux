===============
Validating Data
===============

Validation is no longer an optional feature. All data models are validated.
