History
-------

0.5.1
+++++
* Fix line width calculation in max_width when using coloured text (thanks to @wkentaro) 

0.5.0
+++++
* Added option prompt


0.4.1
+++++
* Fix bug in logic that decides whether progress bars should be hidden or not


0.4.0
+++++
* clint.textui.prompt now has a query function with validators! (thanks to @aeby) - see `examples/prompt.py`
* Clint docs are now included in sdist (thanks to @alunduil)
* Misc. bug fixes


0.3.7
+++++
* Clint now obeys the CLINT_FORCE_COLOR environmental variable


0.3.6
+++++
* Fixed faulty PyPI deployment


0.3.5
+++++
* progress.bar is now a context manager - doesn't require an iterable anymore (thanks to @jric)
* Bug fixes


0.3.4
+++++
* Fixed Python 3 basestring deprecation
* Fixed examples


0.3.3
+++++
* Fixed Python 3 build issues
* Fixed README and HISTORY being installed to /usr
* Support added for bold text


0.3.2
+++++
* Unknown


0.3.1
+++++
* Unknown


0.3.0
+++++

* Python 3 support!


0.2.4
+++++

* New eng module
* Win32 Bugfix


0.2.3
+++++

* Only init colors if they are used (iPython compatability)
* New progress module
* Various bugfixes


0.2.2
+++++

* Auto Color Disabling
* Progress Namespace Change
* New Progress Bars
* textui.puts newline fix


0.2.1 (2011-03-24)
++++++++++++++++++

* Python 2.5 Support
* List of available colors


0.2.0 (2011-03-23)
++++++++++++++++++

* Column Printing!!!
* (Auto/Manual) Disabling of Colors
* Smarter Colors
* max_width, min_width
* Strip cli colors
* bug fixes


0.1.2 (2011-03-21)
++++++++++++++++++

* Bugfixes


0.1.1 (2011-03-20)
++++++++++++++++++

* Bugfixes
* Indent Newline Injection
* resources: flags, not_flags, files, not_files
* Lots of Examples


0.1.0 (2011-03-20)
++++++++++++++++++

* Initial Release!

