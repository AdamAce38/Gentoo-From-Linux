Contribute
----------

Python-guide is under active development, and contributors are welcome.

If you have a feature request, suggestion, or bug report, please open a new issue on GitHub_. To submit patches, please send a pull request on GitHub_. Make sure you add yourself to AUTHORS_.


If you'd like to contribute, there's plenty to do. Here's a short todo list.

    .. include:: ../TODO.rst


.. _GitHub: http://github.com/kennethreitz/python-guide/
.. _AUTHORS: http://github.com/kennethreitz/python-guide/blob/master/AUTHORS


