Matcher Internals
=================

Details of the Matcher internals.

.. toctree::

    matcher_internals/object_matchers
    matcher_internals/number_matchers
    matcher_internals/text_matchers
    matcher_internals/logical_matchers
    matcher_internals/sequence_matchers
    matcher_internals/dictionary_matchers
    matcher_internals/decorator_matchers


