Matcher Library
===============

Library of Matcher implementations.

.. toctree::

    matcher_library/object_matchers
    matcher_library/number_matchers
    matcher_library/text_matchers
    matcher_library/logical_matchers
    matcher_library/sequence_matchers
    matcher_library/dictionary_matchers
    matcher_library/decorator_matchers
