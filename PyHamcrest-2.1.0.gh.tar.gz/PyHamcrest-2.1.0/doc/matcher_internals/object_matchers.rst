.. _object-matcher-internals:

Object Matchers
---------------

Matchers that inspect objects.


.. automodule:: hamcrest.core.core.isequal
.. automodule:: hamcrest.library.object.haslength
.. automodule:: hamcrest.library.object.hasstring
.. automodule:: hamcrest.library.object.hasproperty
.. automodule:: hamcrest.core.core.isinstanceof
.. automodule:: hamcrest.core.core.isnone
.. automodule:: hamcrest.core.core.issame
.. automodule:: hamcrest.core.core.raises
