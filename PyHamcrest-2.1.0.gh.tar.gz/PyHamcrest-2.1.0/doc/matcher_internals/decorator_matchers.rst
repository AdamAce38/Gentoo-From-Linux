.. _decorator-matcher-internals:

Decorator Matchers
------------------

Matchers that decorate other matchers for better expression.


.. automodule:: hamcrest.core.core.described_as
.. automodule:: hamcrest.core.core.is_
