.. _number-matcher-internals:

Number Matchers
---------------

Matchers that perform numeric comparisons.

.. automodule:: hamcrest.library.number.iscloseto
.. automodule:: hamcrest.library.number.ordering_comparison
