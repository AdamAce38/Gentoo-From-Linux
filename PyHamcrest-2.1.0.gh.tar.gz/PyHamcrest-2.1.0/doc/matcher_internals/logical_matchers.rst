.. _logical-matcher-internals:

Logical Matchers
----------------

Boolean logic using other matchers.

.. automodule:: hamcrest.core.core.allof
.. automodule:: hamcrest.core.core.anyof
.. automodule:: hamcrest.core.core.isanything
.. automodule:: hamcrest.core.core.isnot
