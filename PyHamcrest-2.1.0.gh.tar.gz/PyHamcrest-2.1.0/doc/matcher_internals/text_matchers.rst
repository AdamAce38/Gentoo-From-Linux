.. _text-matcher-internals:

Text Matchers
-------------

Matchers that perform text comparisons.

.. automodule:: hamcrest.library.text.stringcontains
.. automodule:: hamcrest.library.text.stringendswith
.. automodule:: hamcrest.library.text.isequal_ignoring_case
.. automodule:: hamcrest.library.text.isequal_ignoring_whitespace
.. automodule:: hamcrest.library.text.stringmatches
.. automodule:: hamcrest.library.text.stringstartswith
.. automodule:: hamcrest.library.text.stringcontainsinorder
