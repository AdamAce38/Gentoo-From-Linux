.. _sequence-matcher-internals:

Sequence Matchers
-----------------

Matchers of sequences.


.. automodule:: hamcrest.library.collection.issequence_containinginorder
.. automodule:: hamcrest.library.collection.issequence_containinginanyorder
.. automodule:: hamcrest.library.collection.issequence_containing
.. automodule:: hamcrest.library.collection.isin
.. automodule:: hamcrest.library.collection.issequence_onlycontaining
.. automodule:: hamcrest.library.collection.is_empty
