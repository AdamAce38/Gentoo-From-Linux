.. _dictionary-matcher-internals:

Dictionary Matchers
-------------------

Matchers of dictionaries.



.. automodule:: hamcrest.library.collection.isdict_containingentries
.. automodule:: hamcrest.library.collection.isdict_containing
.. automodule:: hamcrest.library.collection.isdict_containingkey
.. automodule:: hamcrest.library.collection.isdict_containingvalue
