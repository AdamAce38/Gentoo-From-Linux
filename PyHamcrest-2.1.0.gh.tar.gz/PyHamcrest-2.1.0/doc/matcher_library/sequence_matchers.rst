Sequence Matchers
-----------------

Matchers of sequences.

See also, :ref:`Sequence matcher internals<sequence-matcher-internals>`.


contains_exactly
^^^^^^^^^^^^^^^^

.. currentmodule:: hamcrest.library.collection.issequence_containinginorder
.. autofunction:: contains_exactly

contains_inanyorder
^^^^^^^^^^^^^^^^^^^

.. currentmodule:: hamcrest.library.collection.issequence_containinginanyorder
.. autofunction:: contains_inanyorder

has_item, has_items
^^^^^^^^^^^^^^^^^^^

.. currentmodule:: hamcrest.library.collection.issequence_containing
.. autofunction:: has_items

is_in
^^^^^

.. currentmodule:: hamcrest.library.collection.isin
.. autofunction:: is_in

only_contains
^^^^^^^^^^^^^

.. currentmodule:: hamcrest.library.collection.issequence_onlycontaining
.. autofunction:: only_contains

empty
^^^^^

.. currentmodule:: hamcrest.library.collection.is_empty
.. autofunction:: empty
