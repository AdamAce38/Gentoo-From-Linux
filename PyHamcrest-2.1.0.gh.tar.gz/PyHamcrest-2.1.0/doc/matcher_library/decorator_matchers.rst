Decorator Matchers
------------------

Matchers that decorate other matchers for better expression.

See also, :ref:`Decorator matcher internals<decorator-matcher-internals>`.


described_as
^^^^^^^^^^^^

.. currentmodule:: hamcrest.core.core.described_as
.. autofunction:: described_as


is\_
^^^^

.. currentmodule:: hamcrest.core.core.is_
.. autofunction:: is_
