Dictionary Matchers
-------------------

Matchers of dictionaries.

See also, :ref:`Dictionary matcher internals<dictionary-matcher-internals>`


has_entries
^^^^^^^^^^^

.. currentmodule:: hamcrest.library.collection.isdict_containingentries
.. autofunction:: has_entries

has_entry
^^^^^^^^^

.. currentmodule:: hamcrest.library.collection.isdict_containing
.. autofunction:: has_entry

has_key
^^^^^^^

.. currentmodule:: hamcrest.library.collection.isdict_containingkey
.. autofunction:: has_key

has_value
^^^^^^^^^

.. currentmodule:: hamcrest.library.collection.isdict_containingvalue
.. autofunction:: has_value
