Logical Matchers
----------------

Boolean logic using other matchers.

See also, :ref:`Logical matcher internals<logical-matcher-internals>`


all_of
^^^^^^

.. currentmodule:: hamcrest.core.core.allof
.. autofunction:: all_of

any_of
^^^^^^

.. currentmodule:: hamcrest.core.core.anyof
.. autofunction:: any_of

anything
^^^^^^^^

.. currentmodule:: hamcrest.core.core.isanything
.. autofunction:: anything

is_not
^^^^^^

.. currentmodule:: hamcrest.core.core.isnot
.. autofunction:: is_not 
