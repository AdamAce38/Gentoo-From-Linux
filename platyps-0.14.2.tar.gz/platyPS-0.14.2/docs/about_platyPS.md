﻿# platyPS
## about_platyPS

# SHORT DESCRIPTION
Write PowerShell External Help in Markdown.

# LONG DESCRIPTION

PlatyPS provides a way to

- Write PowerShell External Help in Markdown
- Generate markdown help (example) for your existing modules
- Keep markdown help up-to-date with your code

Markdown help docs can be generated from old external help files (also known as MAML-xml help),
the command objects (reflection), or both.

PlatyPS can also generate cab files for Update-Help.
