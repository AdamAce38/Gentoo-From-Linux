function Get-Nest
{
    [CmdletBinding()]
    param(
	[Parameter()] [string] $str
	)
}