﻿namespace Markdown.MAML.Model.Markdown
{
    public enum MarkdownNodeType
    {
        Unknown = 0,
        Document,
        Paragraph,
        Heading,
        CodeBlock
    }
}
