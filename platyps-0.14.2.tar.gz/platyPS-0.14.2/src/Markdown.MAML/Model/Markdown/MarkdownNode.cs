﻿namespace Markdown.MAML.Model.Markdown
{
    public abstract class MarkdownNode
    {
        public abstract MarkdownNodeType NodeType { get; }
    }
}
