﻿namespace Markdown.MAML.Model.YAML
{
    public class YamlExample
    {
        public string Name { get; set; }
        public string PreCode { get; set; }
        public string Code { get; set; }
        public string PostCode { get; set; }
    }
}