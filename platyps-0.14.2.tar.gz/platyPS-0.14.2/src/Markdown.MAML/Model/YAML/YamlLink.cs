﻿namespace Markdown.MAML.Model.YAML
{
    public class YamlLink
    {
        public string Href { get; set; }
        public string Text { get; set; }
    }
}