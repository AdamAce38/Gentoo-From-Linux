﻿namespace Markdown.MAML.Model.YAML
{
    public class YamlModule
    {
        public string Name { get; set; }
    }
}