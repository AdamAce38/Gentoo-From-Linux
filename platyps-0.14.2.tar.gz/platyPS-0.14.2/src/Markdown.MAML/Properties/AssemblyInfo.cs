using System.Runtime.CompilerServices;

[assembly: InternalsVisibleToAttribute("Markdown.MAML.Test")]
