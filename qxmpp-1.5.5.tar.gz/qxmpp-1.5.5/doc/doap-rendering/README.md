<!--
SPDX-FileCopyrightText: 2022 Melvin Keskin <melvo@olomono.de>

SPDX-License-Identifier: CC0-1.0
-->

# DOAP rendering

Run `doc/doap-rendering/update-xeplist.sh` to get the latest XEP metadata
before building the documentation.

