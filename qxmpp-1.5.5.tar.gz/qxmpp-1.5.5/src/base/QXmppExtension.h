// SPDX-FileCopyrightText: 2022 Linus Jahn <lnj@kaidan.im>
//
// SPDX-License-Identifier: LGPL-2.1-or-later

#ifndef QXMPPEXTENSION_H
#define QXMPPEXTENSION_H

#include "QXmppGlobal.h"

class QXMPP_EXPORT QXmppExtension
{
};

#endif  // QXMPPEXTENSION_H
