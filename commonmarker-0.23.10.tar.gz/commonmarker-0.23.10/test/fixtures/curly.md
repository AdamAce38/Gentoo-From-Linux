This curly quote “makes commonmarker throw an exception”.
