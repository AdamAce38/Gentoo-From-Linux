I am **strong**
