One extension:

| a   | b   |
| --- | --- |
| c   | d   |
| **x** | |

Another extension:

~~hi~~
