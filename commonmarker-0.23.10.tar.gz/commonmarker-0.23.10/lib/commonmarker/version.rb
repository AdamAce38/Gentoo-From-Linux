# frozen_string_literal: true

module CommonMarker
  VERSION = "0.23.10"
end
