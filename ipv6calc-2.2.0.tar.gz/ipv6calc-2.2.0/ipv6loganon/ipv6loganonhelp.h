/*
 * Project    : ipv6calc
 * File       : ipv6loganonhelp.h
 * Version    : $Id: c2d605bf90a3a032553872c3918a3d6bd1a38ed1 $
 * Copyright  : 2007-2014 by Peter Bieringer <pb (at) bieringer.de>
 * License    : GNU GPL v2
 *
 * Information:
 *  Header file for ipv6loganonhelp.c
 */

extern void printversion(void);
extern void printversion_help(void);
extern void ipv6loganon_printinfo(void);
extern void ipv6loganon_printhelp(void);
