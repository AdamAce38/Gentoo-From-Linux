/*
 * Project    : ipv6calc
 * File       : librfc1924.h
 * Version    : $Id: e960f94c695627dc8f7448cdc1d32f6d99f4ada8 $
 * Copyright  : 2001-2014 by Peter Bieringer <pb (at) bieringer.de>
 *
 * Information:
 *  Header file for librfc1924.c
 */ 

#include "libipv6addr.h"

/* prototypes */
extern int ipv6addrstruct_to_base85(const ipv6calc_ipv6addr *ipv6addrp, char *resultstring, const size_t resultstring_length);
extern int base85_to_ipv6addrstruct(const char *addrstring, char *resultstring, const size_t resultstring_length, ipv6calc_ipv6addr *ipv6addrp);
extern int librfc1924_formatcheck(const char *string, char *infostring, const size_t infostring_length);
