# Copyright 2004-2023, Paul Johnson (paul@pjcj.net)

# This software is free.  It is licensed under the same terms as Perl itself.

# The latest version of this software should be available from my homepage:
# http://www.pjcj.net

package E4;

print "E4\n";

sub E4 { print "E4::E4\n" }

1
