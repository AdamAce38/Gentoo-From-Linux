/* ***************************************************************
 * Functions exported from Haskell
 * ***************************************************************/

#include <HsFFI.h>
#include <lua.h>

/*  exported from Lua.Call */
int hslua_callhsfun(lua_State *L);
