================================
qtawesome: Iconic Fonts for PyQt
================================

.. toctree::

   introduction
   usage
   icon_browser
   api_documentation
