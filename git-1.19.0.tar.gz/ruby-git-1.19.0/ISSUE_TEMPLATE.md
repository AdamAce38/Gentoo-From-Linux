### Subject of the issue
Describe your issue here.

### Your environment
* version of git and ruby-git
* version of ruby

### Steps to reproduce
Tell us how to reproduce this issue. 

### Expected behaviour
What did you expect to happen?

### Actual behaviour
What actually happened?