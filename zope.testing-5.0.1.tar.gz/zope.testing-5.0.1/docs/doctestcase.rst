.. include:: ../src/zope/testing/doctestcase.txt

