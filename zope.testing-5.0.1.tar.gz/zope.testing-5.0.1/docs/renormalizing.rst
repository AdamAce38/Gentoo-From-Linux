.. include:: ../src/zope/testing/renormalizing.txt

