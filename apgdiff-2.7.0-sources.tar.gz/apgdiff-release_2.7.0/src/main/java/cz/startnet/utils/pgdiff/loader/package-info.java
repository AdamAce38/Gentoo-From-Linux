/**
 * Contains PostgreSQL dump loader.
 */
package cz.startnet.utils.pgdiff.loader;
