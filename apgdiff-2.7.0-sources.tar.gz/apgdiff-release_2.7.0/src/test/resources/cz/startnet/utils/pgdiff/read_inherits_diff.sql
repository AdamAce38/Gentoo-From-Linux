
ALTER TABLE testtable
	ADD COLUMN IF NOT EXISTS field2 information_schema.cardinal_number;
