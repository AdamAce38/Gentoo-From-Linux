CREATE table "test1" (
"id" BIGINT,
"value" VARCHAR(255)
);