create table todos (
	 id integer
);

create schema data;
create table data.sub_tasks (
	 id integer
);
