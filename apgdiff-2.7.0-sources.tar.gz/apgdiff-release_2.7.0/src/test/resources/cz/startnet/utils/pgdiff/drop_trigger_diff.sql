
DROP TRIGGER IF EXISTS test_table_trigger ON test_table;
