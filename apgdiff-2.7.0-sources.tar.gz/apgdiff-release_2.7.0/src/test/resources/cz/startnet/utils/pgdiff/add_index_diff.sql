
CREATE INDEX IF NOT EXISTS testindex3 ON testtable USING btree (field3);
