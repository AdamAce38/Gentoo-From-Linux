/* create table begin */
create table "test2"(
"id" serial NOT NULL
);