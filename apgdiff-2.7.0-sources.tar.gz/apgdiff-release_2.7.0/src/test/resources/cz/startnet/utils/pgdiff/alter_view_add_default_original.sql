CREATE VIEW test AS
	SELECT test_col FROM test2;
