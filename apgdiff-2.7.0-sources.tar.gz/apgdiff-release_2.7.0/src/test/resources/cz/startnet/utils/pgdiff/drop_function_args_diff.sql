
DROP FUNCTION IF EXISTS power_number("input" integer);
