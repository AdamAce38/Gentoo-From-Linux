CREATE TABLE test
(
    test TEXT DEFAULT '*/'
);