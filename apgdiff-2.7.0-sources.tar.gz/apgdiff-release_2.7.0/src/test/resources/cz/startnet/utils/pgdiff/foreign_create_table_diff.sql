
CREATE FOREIGN TABLE IF NOT EXISTS foreign_to_create (
	id bigint
)SERVER ats
OPTIONS (
    updatable 'false'
);
