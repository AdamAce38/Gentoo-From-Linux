create view vx (x) as select 2;
