create table items(id integer, name text);

create view items_view as select id from items;
