create table items(id integer, name text);
