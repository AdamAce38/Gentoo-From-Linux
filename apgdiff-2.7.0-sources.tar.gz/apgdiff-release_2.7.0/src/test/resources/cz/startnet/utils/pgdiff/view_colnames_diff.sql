DROP VIEW IF EXISTS vx;

CREATE VIEW vx (x) AS
	select 2;
