CREATE FUNCTION drop_fk_except_for(tables_in character varying[]) RETURNS SETOF character varying
    LANGUAGE plpgsql
    AS $$
DECLARE
BEGIN
  -- aaa
END;
$$;