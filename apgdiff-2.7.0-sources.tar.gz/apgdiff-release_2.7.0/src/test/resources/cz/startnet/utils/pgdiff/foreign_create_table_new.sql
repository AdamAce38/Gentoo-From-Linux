
CREATE FOREIGN TABLE foreign_to_create (
	id bigint
) SERVER ats
OPTIONS (
    updatable 'false'
);
