CREATE TABLE IF NOT EXISTS empty_table (
);

ALTER TABLE empty_table OWNER TO fordfrog;
