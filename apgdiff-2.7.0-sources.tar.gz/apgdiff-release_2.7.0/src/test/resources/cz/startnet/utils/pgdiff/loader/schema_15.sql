CREATE TABLE test (id bigint);

COMMENT ON TABLE test IS 'multiline
comment
';