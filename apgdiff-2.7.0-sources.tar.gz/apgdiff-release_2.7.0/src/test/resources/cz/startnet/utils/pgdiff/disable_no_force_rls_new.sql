create table items (
	id integer
);

create table projects (
	id integer
);
