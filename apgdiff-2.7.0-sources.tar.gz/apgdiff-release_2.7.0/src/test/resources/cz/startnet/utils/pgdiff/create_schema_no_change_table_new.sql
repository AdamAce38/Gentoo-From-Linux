CREATE SCHEMA public;
CREATE TABLE public.node (instance_id text);

