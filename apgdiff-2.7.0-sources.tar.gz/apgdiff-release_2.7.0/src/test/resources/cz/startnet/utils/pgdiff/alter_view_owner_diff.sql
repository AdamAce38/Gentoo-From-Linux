
ALTER VIEW items_view OWNER TO webuser;
