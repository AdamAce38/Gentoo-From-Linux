
    ALTER TABLE test_table DISABLE TRIGGER test_table_trigger;
