
REVOKE ALL ON SEQUENCE table1_id_seq FROM public;

REVOKE ALL ON TABLE table1 FROM public;