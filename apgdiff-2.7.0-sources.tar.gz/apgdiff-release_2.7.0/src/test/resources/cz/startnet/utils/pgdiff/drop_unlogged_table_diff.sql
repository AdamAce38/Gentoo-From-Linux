SET search_path = radstg, pg_catalog;

DROP TABLE IF EXISTS asset_country_weight;
