ALTER TYPE descr_type
	ADD ATTRIBUTE date_create timestamp without time zone;