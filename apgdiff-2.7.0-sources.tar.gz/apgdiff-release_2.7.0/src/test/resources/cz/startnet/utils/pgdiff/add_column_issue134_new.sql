CREATE table "test1" (
"id" BIGINT,
"type" SMALLINT /* 1: aaa, 2:bbb */,
"value" VARCHAR(255)
);