#ifndef _MBOX_H_
#define _MBOX_H_

#include "globals.h"

void mbox_handle( struct mbox_struct * mb );

#endif

