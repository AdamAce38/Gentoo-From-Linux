/* This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; version 2 dated June, 1991.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program;  if not, write to the Free Software
   Foundation, Inc., 675 Mass Ave., Cambridge, MA 02139, USA. */

#define MG_SOCKLIB_H

#include "config.h"
#include <netinet/in.h>
#include <sys/types.h>
#ifdef HAVE_OPENSSL_SSL_H
#include <openssl/ssl.h>
#include <openssl/bio.h>
#endif

#ifdef __QNX__
#define O_NDELAY O_NONBLOCK
#endif

#define SOCKET_DELAY 0
#define SOCKET_NDELAY 1

#define SOCKET_RESET 0
#define SOCKET_SET 1
#define HOST_NAMELEN 64

typedef struct {
   struct sockaddr_in sin;	/* sin and sinlen store address and length	*/
   socklen_t sinlen;				/* information of the server socket			*/
   int bindflag;			/* used to ensure bind() is only used once	*/
   int sd;					/* Socket descriptor						*/
#ifdef HAVE_OPENSSL_SSL_H
   SSL *ssl;            /* descriptor for ssl connection */
   char *sslBufMalloc, *sslBuf;  /* ssl read buffer */
   unsigned int sslBufSize;      /* its current size */
#endif
} SOCKET;

SOCKET *Sopen(void);
int Sclose(SOCKET *);
int Sserver(SOCKET *, int, int);
int Sclient(SOCKET *, char *, int);
size_t Sread(int sd, char *string, int n, int timeout);
size_t Swrite(int sd, char *string);
#ifdef HAVE_OPENSSL_SSL_H
int Sslclient(SOCKET *, char *trustedCaDir);
size_t Sslread(SOCKET *s, char *string, int n, int timeout);
size_t Sslwrite(SOCKET *s, char *string);
#endif
