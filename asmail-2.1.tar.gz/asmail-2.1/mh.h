#ifndef _MH_H_
#define _MH_H_

#include <ctype.h>
#include "globals.h"

void mh_handle( struct mbox_struct * mb );

int parse_sequence(char *sequence);
int tokenizeString(char *string, int size, char ***output);
int readLine(FILE *stream, char **line, int *size);
int count_mh(struct mbox_struct * mb, int *mod_time);
int count_mh_sequences(struct mbox_struct * mb, int *mod_time );
int count_mh_files(struct mbox_struct * mb);


#endif

