#ifndef _GUI_H_
#define _GUI_H_

#include "globals.h"

void startx( void * ptr );

#endif
