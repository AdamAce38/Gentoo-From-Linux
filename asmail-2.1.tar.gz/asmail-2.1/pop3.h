/*
 * asmail is the AfterStep mailbox monitor
 * Copyright (c) 2002 Albert Dorofeev <albert@tigr.net>
 * For the updates see http://www.tigr.net/
 *
 * This software is distributed under GPL. For details see LICENSE file.
 */

#ifndef _POP3_H_
#define _POP3_H_

#include "globals.h"

#define PORT_POP3 110
void pop3_handle( struct mbox_struct * mb );

#endif

