//go:build windows && arm64
// +build windows,arm64

//go:generate goversioninfo -arm=true -64=true

package main
