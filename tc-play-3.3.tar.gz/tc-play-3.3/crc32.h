uint32_t crc32(const void *buf, size_t size);
uint32_t crc32_intermediate(uint32_t crc, uint8_t d);
