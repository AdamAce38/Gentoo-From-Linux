warn "Lazy loading of jbuilder templates is deprecated and will be removed in Tilt 3.  Require tilt/jbuilder manually.", uplevel: 1
require "tilt/jbuilder"
