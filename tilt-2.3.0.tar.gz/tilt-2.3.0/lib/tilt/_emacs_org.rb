warn "Lazy loading of emacs org templates is deprecated and will be removed in Tilt 3.  Require tilt/emacs_org manually.", uplevel: 1
require "tilt/emacs_org"
