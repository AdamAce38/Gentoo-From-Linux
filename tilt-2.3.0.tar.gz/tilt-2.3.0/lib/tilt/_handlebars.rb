warn "Lazy loading of handlebars templates is deprecated and will be removed in Tilt 3.  Require tilt/handlebars manually.", uplevel: 1
require "tilt/handlebars"
