# frozen_string_literal: true
require_relative 'template'
require 'slim'

Tilt::SlimTemplate = Slim::Template
