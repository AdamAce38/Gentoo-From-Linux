warn "Lazy loading of org templates is deprecated and will be removed in Tilt 3.  Require org-ruby manually.", uplevel: 1
require "org-ruby"
