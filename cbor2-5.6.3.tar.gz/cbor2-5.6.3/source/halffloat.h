#include <stdint.h>

float unpack_float16(uint16_t);
uint16_t pack_float16(float f);
