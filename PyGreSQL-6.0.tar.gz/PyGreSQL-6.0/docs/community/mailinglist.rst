Mailing list
------------

You can join
`the mailing list <https://mail.vex.net/mailman/listinfo/pygresql>`_
to discuss future development of the PyGreSQL interface or if you have
questions or problems with PyGreSQL that are not covered in the
:doc:`documentation <../contents/index>`.

This is usually a low volume list except when there are new features
being added.
