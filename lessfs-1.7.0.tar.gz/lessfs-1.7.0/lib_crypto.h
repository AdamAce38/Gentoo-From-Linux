DAT *lfsencrypt(unsigned char *, unsigned long);
DAT *lfsdecrypt(DAT *);
