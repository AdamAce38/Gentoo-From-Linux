compr *lfssnappy_decompress(unsigned char *, int);
compr *lfssnappy_compress(unsigned char *, int);
