#ifndef __VULKAN_PRIVATE_EXTENSIONS_H__
#define __VULKAN_PRIVATE_EXTENSIONS_H__

/* Nothing here at the moment. Add hacks here! */

#endif
