#include "macro.h"
using namespace std;
int                    gv_swap_choice = 0;
bool                   gv_symetric = false;
int                    gv_nbruns = 0;
bool                   gv_matching_symbol_flag = true;
int                    gv_align_alphabet_size = 3;
int                    gv_seed_alphabet_size = 3;
vector< double >       gv_bsel_weight;
vector< int >          gv_signature;
bool                   gv_signature_flag = false;
double                 gv_bsel_minprob,gv_bsel_maxprob;
int                    gv_minspan = 1, gv_maxspan = 5;
double                 gv_minweight = -1e32, gv_maxweight = 1e32;
bool                   gv_weight_interval = false;
double                 gv_lossless_threshold = 0;
char *                 gv_bsymbols_array = NULL;
bool                   gv_bsymbols_flag  = false;
bool                   gv_sleeping_flag = false;
bool                   gv_nb_processes_flag = false;
int                    gv_nb_processes = 0;



int power(int x, int n) {
  int res = 1;
  int u   = x;
  for(int i = 1; i <= n ; i<<=1){
    if (i&n)
      res *= u;
    u *= u;
  }
  return res;
}


double power(double x, int n) {
  double res = 1.0;
  double u   = x;
  for(int i = 1; i <= n ; i<<=1){
    if (i&n)
      res *= u;
    u *= u;
  }
  return res;
}


