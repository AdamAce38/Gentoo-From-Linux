#include "seed.h"
	
std::ostream& operator<<(std::ostream& os, seed& s){
  os << s.str();
  return os;
}
