Welcome to |project| documentation!
===================================

.. sidebar-links::
   :home:
   :pypi:

.. toctree::
   :maxdepth: 1

   history


.. tidelift-referral-banner::

.. automodule:: keyrings.alt.file
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: keyrings.alt.Gnome
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: keyrings.alt.Google
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: keyrings.alt.keyczar
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: keyrings.alt.multi
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: keyrings.alt.Windows
    :members:
    :undoc-members:
    :show-inheritance:

.. automodule:: keyrings.alt.file_base
    :members:
    :undoc-members:
    :show-inheritance:


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
