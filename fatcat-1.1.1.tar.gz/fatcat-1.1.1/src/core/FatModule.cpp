#include "FatModule.h"

FatModule::FatModule(FatSystem &system_)
    : system(system_)
{
}
