#include "FatChain.h"

FatChain::FatChain()
    : orphaned(true),
    directory(false),
    elements(1),
    length(1),
    size(0)
{
}
