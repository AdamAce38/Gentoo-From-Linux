struct TheStruct
{
	int x;
	int y;
};
