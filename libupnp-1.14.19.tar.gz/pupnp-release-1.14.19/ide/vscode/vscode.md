If you want to use VSCode, move the contents of dot_vscode to .vscode in the root folder.

