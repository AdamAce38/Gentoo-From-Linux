If you want to use qt creator, move the contents of

1. the pupnp subfolder to the root folder.
1. the generator subfolter to the upnp/generator folder.

Unfortunately, the files "\*.creator.user" must be created on a user basis, so you are on your own here.

