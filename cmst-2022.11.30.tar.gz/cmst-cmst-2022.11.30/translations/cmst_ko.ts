<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.1" language="ko">
<context>
    <name>Agent</name>
    <message>
        <location filename="../apps/cmstapp/code/agent/ui/agent.ui" line="14"/>
        <source>Agent Input</source>
        <translation>에이전트 입력</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/agent/ui/agent.ui" line="45"/>
        <source>Passphrase</source>
        <translation>암호문구</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/agent/ui/agent.ui" line="64"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If an old passphrase is available it will be shown here for reference.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;이전 암호문구를 사용할 수 있는 경우 참조용으로 여기에 표시됩니다.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/agent/ui/agent.ui" line="74"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Type the passphrase here.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;여기에 암호문구를 입력합니다.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/agent/ui/agent.ui" line="87"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Check this box to obscure the password characters.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;암호 문자를 가리려면 이 확인란을 선택합니다.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/agent/ui/agent.ui" line="90"/>
        <source>&amp;Hide Passphrase</source>
        <translation>암호문구 숨김(&amp;H)</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/agent/ui/agent.ui" line="97"/>
        <source>O&amp;ld Passphrase</source>
        <translation>이전 암호문구(&amp;L)</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/agent/ui/agent.ui" line="107"/>
        <source>&amp;Passphrase</source>
        <translation>암호문구(&amp;P)</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/agent/ui/agent.ui" line="120"/>
        <source>Hidden Network</source>
        <translation>숨겨진 네트워크</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/agent/ui/agent.ui" line="126"/>
        <source>&amp;Name</source>
        <translation>이름(&amp;N)</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/agent/ui/agent.ui" line="136"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Type the name of the hidden network you wish to connect to.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;연결하려는 숨겨진 네트워크의 이름을 입력합니다.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/agent/ui/agent.ui" line="149"/>
        <source>Service Set Identifier</source>
        <translation>서비스 세트 식별자</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/agent/ui/agent.ui" line="155"/>
        <source>&amp;SSID</source>
        <translation>&amp;SSID</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/agent/ui/agent.ui" line="175"/>
        <source>Wireless Internet Service Provider roaming (WISPr)</source>
        <translation>무선 인터넷 서비스 공급자 로밍 (WISPr)</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/agent/ui/agent.ui" line="181"/>
        <source>&amp;Username</source>
        <translation>사용자이름(&amp;U)</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/agent/ui/agent.ui" line="191"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;WISPr username.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;WISPr 사용자이름입니다.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/agent/ui/agent.ui" line="201"/>
        <source>Passwor&amp;d</source>
        <translation>암호(&amp;D)</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/agent/ui/agent.ui" line="211"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;WISPr password.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;WISPr 암호입니다.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/agent/ui/agent.ui" line="224"/>
        <source>Extensible Authentication Protocol (EAP)</source>
        <translation>확장 가능 인증 프로토콜 (EAP)</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/agent/ui/agent.ui" line="230"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Type your Identity for the Extensible Authentication Protocol&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;확장 가능한 인증 프로토콜의 ID 입력하기&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/agent/ui/agent.ui" line="240"/>
        <source>&amp;Identity</source>
        <translation>&amp;ID</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/agent/ui/agent.ui" line="253"/>
        <source>WiFi Protected Setup (WPS)</source>
        <translation>WiFi 보호 설정 (WPS)</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/agent/ui/agent.ui" line="261"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;When checked use WPS push button authentication.  &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;체크하면 WPS 푸시 버튼 인증을 사용합니다.  &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/agent/ui/agent.ui" line="264"/>
        <source>Use Push &amp;Button Authentication</source>
        <translation>푸시 버튼 인증 사용하기(&amp;B)</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/agent/ui/agent.ui" line="294"/>
        <source>&amp;WPS Pin</source>
        <translation>WPS 핀(&amp;W)</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/agent/ui/agent.ui" line="310"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Enter a WPS pin.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;WPS 핀을 입력합니다.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/agent/ui/agent.ui" line="329"/>
        <source>Browser Login Requested</source>
        <translation>브라우저 로그인 요청됨</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/agent/ui/agent.ui" line="338"/>
        <source>Choose or enter a browser:</source>
        <translation>브라우저 선택 또는 입력하기:</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/agent/ui/agent.ui" line="345"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;ConnMan is requesting that you open a web browser to complete the login process.&lt;/p&gt;&lt;p&gt;We have scanned your PATH for browsers and any browsers found are shown in the list below. You may select any one browser to use it for the login. If your web browser is not shown in the list you may enter it directly in the&lt;span style=&quot; font-weight:600;&quot;&gt; Choose or enter a browser box&lt;/span&gt;.&lt;/p&gt;&lt;p&gt;To launch the browser click the &lt;span style=&quot; font-weight:600;&quot;&gt;Launch Browser&lt;/span&gt; button. &lt;/p&gt;&lt;p&gt;If you wish to login manually close this dialog, start your web browser and proceed to the URL shown in the &lt;span style=&quot; font-weight:600;&quot;&gt;Login URL&lt;/span&gt; box.&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Brave Browser Users:&lt;/span&gt; Note that Brave does not seem to accept a URL to start with. After the browser starts you will need to enter the URL manually. &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;ConnMan은 로그인 프로세스를 완료하기 위해 웹 브라우저를 열도록 요청하고 있습니다.&lt;/p&gt;&lt;p&gt;우리는 브라우저의 PATH를 스캔했으며 발견된 모든 브라우저는 아래 목록. 하나의 브라우저를 선택하여 로그인에 사용할 수 있습니다. 웹 브라우저가 목록에 표시되지 않으면&lt;span style=&quot; font-weight:600;&quot;&gt; 브라우저 상자 선택 또는 입력하기&lt;/span&gt;에 직접 입력할 수 있습니다.&lt;/p&gt;&lt;p&gt;실행하려면 브라우저에서 &lt;span style=&quot; font-weight:600;&quot;&gt;브라우저 시작하기&lt;/span&gt; 버튼을 클릭합니다. &lt;/p&gt;&lt;p&gt;직접 로그인하려면 이 대화 상자를 닫으십시오. 웹 브라우저를 시작하고 &lt;span style=&quot; font-weight:600;&quot;&gt;로그인 URL&lt;/span&gt; 상자에 표시된 URL로 이동하십시오. &lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Brave 브라우저 사용자:&lt;/span&gt; Brave는 시작할 URL을 허용하지 않는 것 같습니다. 브라우저가 시작된 후 URL을 직접 입력해야 합니다. &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/agent/ui/agent.ui" line="360"/>
        <source>Login URL:</source>
        <translation>로그인 URL:</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/agent/ui/agent.ui" line="367"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Connman is requesting you continue login with a web browser. This box shows the URL that contains the login page.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Connman은 웹 브라우저로 로그인을 계속할 것을 요청합니다. 이 상자에는 로그인 페이지가 포함된 URL이 표시됩니다.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Use  the Firefox browser.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translatorcomment>Removed double space</translatorcomment>
        <translation type="vanished">&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Use the Firefox browser.&lt;/p&gt;&lt;/body&gt;&lt;html&gt;</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/agent/ui/agent.ui" line="379"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Use this button to launch the selected browser. The browser will open at the page shown in the Login URL box.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;선택한 브라우저를 실행하려면 이 버튼을 사용하십시오. 브라우저는 로그인 URL 상자에 표시된 페이지에서 열립니다.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/agent/ui/agent.ui" line="382"/>
        <source>Launch &amp;Browser</source>
        <translation>브라우저 시작하기(&amp;B)</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/agent/ui/agent.ui" line="414"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;What&apos;s This&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;이건 뭘까요&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/agent/ui/agent.ui" line="417"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/agent/ui/agent.ui" line="441"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Continue the connection process.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;연결 프로세스를 계속합니다.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/agent/ui/agent.ui" line="444"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Accept and use the answers you have provided in this dialog. &lt;/p&gt;&lt;p&gt;This will send your input to the connman daemon to continue the connection process.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;이 대화상자에서 입력한 답변을 수락하고 사용합니다. &lt;/p&gt;&lt;p&gt;이렇게 하면 연결 프로세스를 계속하기 위해 Connman 데몬으로 입력이 전송됩니다.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/agent/ui/agent.ui" line="447"/>
        <source>O&amp;K</source>
        <translation>확인(&amp;K)</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/agent/ui/agent.ui" line="454"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Cancel the connection process.&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;연결 프로세스를 취소합니다.&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/agent/ui/agent.ui" line="457"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Cancel the dialog. &lt;/p&gt;&lt;p&gt;This will send a message to the connman daemon that you have cancelled the connection request.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;대화상자를 취소합니다. &lt;/p&gt;&lt;p&gt;연결 요청을 취소했다는 메시지를 connman 데몬에 보냅니다.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/agent/ui/agent.ui" line="460"/>
        <source>&amp;Cancel</source>
        <translation>취소하기(&amp;C)</translation>
    </message>
</context>
<context>
    <name>AgentDialog</name>
    <message>
        <location filename="../apps/cmstapp/code/agent/agent_dialog.cpp" line="298"/>
        <source> Information</source>
        <translation> 정보</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/agent/agent_dialog.cpp" line="299"/>
        <source>You have requested the %1 browser, but we cannot find a terminal program to open it with.  Currenty we can start %1 using these terminals: &lt;b&gt;roxterm&lt;/b&gt; and &lt;b&gt;xterm&lt;/b&gt;.&lt;br&gt;&lt;br&gt;To continue you need to manually open a terminal and then enter: &quot;%1 %2&quot;</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ConnmanAgent</name>
    <message>
        <location filename="../apps/cmstapp/code/agent/agent.cpp" line="82"/>
        <source>Connman Error</source>
        <translation>Connman 오류</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/agent/agent.cpp" line="83"/>
        <source>Connman returned the following error:&lt;b&gt;&lt;center&gt;%1&lt;/b&gt;&lt;br&gt;Would you like to retry?</source>
        <translation>Connman이 다음 오류를 반환했습니다.&lt;b&gt;&lt;center&gt;%1&lt;/b&gt;&lt;br&gt;다시 시도하시겠습니까?</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/agent/agent.cpp" line="131"/>
        <source>Agent Request Failed</source>
        <translation>에이전트 요청 실패함</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/agent/agent.cpp" line="132"/>
        <source>The agent request failed before a reply was returned.</source>
        <translation>응답이 반환되기 전에 에이전트 요청이 실패했습니다.</translation>
    </message>
</context>
<context>
    <name>ConnmanCounter</name>
    <message>
        <location filename="../apps/cmstapp/code/counter/counter.cpp" line="67"/>
        <location filename="../apps/cmstapp/code/counter/counter.cpp" line="84"/>
        <source>%L1 Bytes</source>
        <translation>%L1 바이트</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/counter/counter.cpp" line="69"/>
        <location filename="../apps/cmstapp/code/counter/counter.cpp" line="86"/>
        <source>%L1 KB</source>
        <translation>%L1 KB</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/counter/counter.cpp" line="71"/>
        <location filename="../apps/cmstapp/code/counter/counter.cpp" line="88"/>
        <source>%L1 MB</source>
        <translation>%L1 MB</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/counter/counter.cpp" line="73"/>
        <location filename="../apps/cmstapp/code/counter/counter.cpp" line="90"/>
        <source>%L1 GB</source>
        <translation>%L1 GB</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/counter/counter.cpp" line="76"/>
        <source>&lt;b&gt;Transmit:&lt;/b&gt;&lt;br&gt;TX Total: %1 (%2),  TX Errors: %3,  TX Dropped: %4</source>
        <translation>&lt;b&gt;전송하기:&lt;/b&gt;&lt;br&gt;TX 총계: %1(%2), TX 오류: %3, TX 끊어짐: %4</translation>
    </message>
    <message numerus="yes">
        <location filename="../apps/cmstapp/code/counter/counter.cpp" line="77"/>
        <location filename="../apps/cmstapp/code/counter/counter.cpp" line="79"/>
        <location filename="../apps/cmstapp/code/counter/counter.cpp" line="80"/>
        <location filename="../apps/cmstapp/code/counter/counter.cpp" line="94"/>
        <location filename="../apps/cmstapp/code/counter/counter.cpp" line="96"/>
        <location filename="../apps/cmstapp/code/counter/counter.cpp" line="97"/>
        <source>%Ln Packet(s)</source>
        <translation>
            <numerusform>%Ln 패킷</numerusform>
        </translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/counter/counter.cpp" line="93"/>
        <source>&lt;br&gt;&lt;br&gt;&lt;b&gt;Received:&lt;/b&gt;&lt;br&gt;RX Total: %1 (%2),  RX Errors: %3,  RX Dropped: %4</source>
        <translation>&lt;br&gt;&lt;br&gt;&lt;b&gt;수신됨:&lt;/b&gt;&lt;br&gt;RX 합계: %1 (%2), RX 오류: %3,  RX 수신중단: %4</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/counter/counter.cpp" line="100"/>
        <source>&lt;br&gt;&lt;br&gt;&lt;b&gt;Connect Time:&lt;/b&gt;&lt;br&gt;</source>
        <translation>&lt;br&gt;&lt;br&gt;&lt;b&gt;연결 시간:&lt;/b&gt;&lt;br&gt;</translation>
    </message>
    <message numerus="yes">
        <location filename="../apps/cmstapp/code/counter/counter.cpp" line="111"/>
        <source>%n Day(s)</source>
        <translation>
            <numerusform>%n일</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="../apps/cmstapp/code/counter/counter.cpp" line="118"/>
        <source>%n Hour(s)</source>
        <translation>
            <numerusform>%n시간</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="../apps/cmstapp/code/counter/counter.cpp" line="125"/>
        <source>%n Minute(s)</source>
        <translation>
            <numerusform>%n분</numerusform>
        </translation>
    </message>
    <message numerus="yes">
        <location filename="../apps/cmstapp/code/counter/counter.cpp" line="131"/>
        <source>%n Second(s)</source>
        <translation>
            <numerusform>%n초</numerusform>
        </translation>
    </message>
</context>
<context>
    <name>ConnmanVPNAgent</name>
    <message>
        <location filename="../apps/cmstapp/code/vpn_agent/vpnagent.cpp" line="82"/>
        <source>Connman Error</source>
        <translation>Connman 오류</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_agent/vpnagent.cpp" line="83"/>
        <source>Connman returned the following error:&lt;b&gt;&lt;center&gt;%1&lt;/b&gt;&lt;br&gt;Would you like to retry?</source>
        <translation>Connman이 다음 오류를 반환했습니다.&lt;b&gt;&lt;center&gt;%1&lt;/b&gt;&lt;br&gt;다시 시도하시겠습니까?</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_agent/vpnagent.cpp" line="119"/>
        <source>Agent Request Failed</source>
        <translation>에이전트 요청 실패함</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_agent/vpnagent.cpp" line="120"/>
        <source>The agent request failed before a reply was returned.</source>
        <translation>응답이 반환되기 전에 에이전트 요청이 실패했습니다.</translation>
    </message>
</context>
<context>
    <name>ControlBox</name>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="20"/>
        <source>Dialog</source>
        <translation>대화상자</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="48"/>
        <source>&amp;Status</source>
        <translation>상태(&amp;S)</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="100"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;This checkbox controls the global setting for switching all radios on or off. When checked all radios are powered down.&lt;/p&gt;&lt;p&gt;When the system is In offline mode it is possible to turn individual devices back on. When leaving offline mode the individual policy of each device determines if the radio is turned back on or not.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="103"/>
        <source>All Devices &amp;Off</source>
        <translation>모든 장치 끄기(&amp;O)</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="69"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;OfflineMode&lt;/span&gt;&lt;/p&gt;&lt;p&gt;The offline mode indicates the global setting for switching all radios on or off. Changing offline mode to true results in powering down all devices. When leaving offline mode the individual policy of each device decides to switch the radio back on or not. &lt;/p&gt;&lt;p&gt;During offline mode, it is still possible to switch certain technologies manually back on. For example the limited usage of WiFi or Bluetooth devices might be allowed in some situations.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="35"/>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="477"/>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="577"/>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="743"/>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="872"/>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="912"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="72"/>
        <source>Global Properties</source>
        <translation>전역 속성</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="80"/>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="132"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;The global setting for switching all radios on or off. When offline mode is engaged all radios are powered down.&lt;/p&gt;&lt;p&gt;While in offline mode it is possible to turn individual devices back on. When leaving offline mode the individual policy of each device determines if the radio is turned back on or not.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="83"/>
        <source>OfflineMode: Unavailable</source>
        <translation>오프라인모드: 사용할 수 없음</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="90"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;The global connection state of the system.  Possible values are &amp;quot;offline&amp;quot;, &amp;quot;idle&amp;quot;, &amp;quot;ready&amp;quot;, and &amp;quot;online&amp;quot;.  &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="93"/>
        <source>State: Unavailable</source>
        <translation>상태: 사용할 수 없음</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="166"/>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="149"/>
        <source>Technologies</source>
        <translation>기술</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="215"/>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="357"/>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="714"/>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="843"/>
        <source>Name</source>
        <translation>이름</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="220"/>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="362"/>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="848"/>
        <source>Type</source>
        <translation>유형</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="225"/>
        <source>Powered</source>
        <translation>전원 연결됨</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="230"/>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="724"/>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="2432"/>
        <source>Connected</source>
        <translation>연결됨</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="235"/>
        <source>Tethering</source>
        <translation>테더링</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="253"/>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="635"/>
        <source>Resc&amp;an</source>
        <translation>다시 스캔(&amp;A)</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="302"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;This box lists all services that connman can connect to.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;이 상자에는 Connman이 연결할 수 있는 모든 서비스가 나열됩니다.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="305"/>
        <source>Services</source>
        <translation>서비스</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="367"/>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="853"/>
        <source>State</source>
        <translation>상태</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="372"/>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="863"/>
        <source>Connection</source>
        <translation>연결</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="388"/>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1953"/>
        <source>Move Before</source>
        <translation>앞으로 이동</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="401"/>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1958"/>
        <source>Move After</source>
        <translation>뒤로 이동</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="421"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;When checked hide the connection name in the Services box.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;선택하면 서비스 상자에서 연결 이름을 숨깁니다.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="424"/>
        <source>&amp;Less</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="445"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;This page will show the details of the service selected in the box at the top. If the selected service is not in the READY or ONLINE state then most of the details will be blank. &lt;/p&gt;&lt;p&gt;You may override service details by using the &lt;span style=&quot; font-weight:600;&quot;&gt;Configuration&lt;/span&gt; button at the bottom right. &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="448"/>
        <source>&amp;Details</source>
        <translation>세부 정보(&amp;D)</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="460"/>
        <source>Ser&amp;vice</source>
        <translation>서비스(&amp;V)</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="470"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Use this Combobox to select the service for which you wish to view the detailed information.&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;이 콤보 상자를 사용하여 자세한 정보를 보려는 서비스를 선택합니다.&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="567"/>
        <source>Configuration</source>
        <translation>구성</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="580"/>
        <source>&amp;Wireless</source>
        <translation>무선(&amp;W)</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="586"/>
        <source>Wireless Services</source>
        <translation>무선 서비스</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="592"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select a wifi service in the table below and press this button to connect the service. &lt;/p&gt;&lt;p&gt;If there is only one wifi service listed in the table pressing this button will automatically select that service and attempt to connect. &lt;/p&gt;&lt;p&gt;If information about the service is needed, a passphrase for instance, you will be prompted for it. &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;아래 표에서 Wi-Fi 서비스를 선택하고 이 버튼을 누르면 서비스가 연결됩니다. &lt;/p&gt;&lt;p&gt;표에 하나의 Wi-Fi 서비스만 나열되어 있는 경우 이 버튼을 누르면 자동으로 해당 서비스를 선택하고 연결을 시도합니다. &lt;/p&gt;&lt;p&gt;예를 들어 암호문구와 같은 서비스에 대한 정보가 필요한 경우 해당 정보를 입력하라는 메시지가 표시됩니다.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="595"/>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="764"/>
        <source>Connect</source>
        <translation>연결하기</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="602"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select a wifi service in the table below and press this button to disconnect it. &lt;/p&gt;&lt;p&gt;If there is only one wifi service in the &amp;quot;ready&amp;quot; or &amp;quot;online&amp;quot; state pressing this button will automatically select that service and disconnect it. &lt;/p&gt;&lt;p&gt;This may also be used to abort a previous connection attempt.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="605"/>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="777"/>
        <source>Disconnect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="615"/>
        <source>Remove</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="648"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;This label shows the number of WiFi technologies (devices) that were found, and the number that are powered on. There must be at least one WiFi technology found and powered in order for the box below to show services.&lt;/p&gt;&lt;p&gt;To turn a technology on or off go to the &lt;span style=&quot; font-weight:600;&quot;&gt;Technologies&lt;/span&gt; box in the &lt;span style=&quot; font-weight:600;&quot;&gt;Status&lt;/span&gt; tab and double click on the text that shows in the &lt;span style=&quot; font-weight:600;&quot;&gt;Powered&lt;/span&gt; column for the technology.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="651"/>
        <source>Wifi State</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1293"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If checked CMST will implement an internet kill switch for VPN connections. If a VPN connection drops while the kill switch is enabled all technologies will be powered off.&lt;/p&gt;&lt;p&gt;The way this works is the service order is monitored. If the topmost service is of type VPN and then if it changes to something other than VPN and if the change was not initiated by the user (for instance by using the &lt;span style=&quot; font-weight:600;&quot;&gt;Disconnect&lt;/span&gt; button in the VPN tab), then CMST will cycle through all technologies powering each one down in turn. &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1296"/>
        <source>Enable VPN Internet Kill Switch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1249"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If checked the system notification daemon will popup a notify message when a significant connman related event is received.&lt;/p&gt;&lt;p&gt;Notifications can be handled by the System Tray Icon, or by a Notify daemon if one is installed. Both can not be active at the same time.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;체크하면 시스템 알림 데몬은 중요한 connman 관련 이벤트가 수신될 때 알림 메시지를 표시합니다.&lt;/p&gt;&lt;p&gt;알림은 시스템 트레이 아이콘 또는 설치된 경우 알림 데몬으로 처리할 수 있습니다. 둘 다 동시에 활성화될 수 없습니다.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1172"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If checked the Start Up Options in the right hand pane will be enabled. Start up options set in this pane will be read and used next time the program starts. Start up options are also available as command line switches and an option provided on the command line will take precedence over an option set in the right hand pane. The options in this pane are provided as a convienence to avoid the necessity of editing a systemd service or other start up file. &lt;/p&gt;&lt;p&gt;Settings are stored in&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;;&quot;&gt;: ~&lt;/span&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-weight:600;&quot;&gt;/.config/cmst/cmst.conf &lt;/span&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;;&quot;&gt;&lt;br/&gt;This is a standard ini type text file.&lt;/span&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1175"/>
        <source>Enable Start Options from GUI (right hand pane)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1339"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;These entries control various options for CMST at program start. Changing or setting these will only take effect at the next program start. &lt;/p&gt;&lt;p&gt;All of these options are available from the command line, and if a command line option is provided it will take precedence over these settings.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1342"/>
        <source>Start Up Options</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1516"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;pre style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;;&quot;&gt;Command Line Option: &lt;/span&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-weight:600;&quot;&gt;-m&lt;/span&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;;&quot;&gt; or &lt;/span&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-weight:600;&quot;&gt;--minimized&lt;/span&gt;&lt;/pre&gt;&lt;/body&gt;&lt;/html&gt;
&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Start the GUI minimized in the system tray.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;pre style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;;&quot;&gt;명령줄 옵션: &lt;/span&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-weight:600;&quot;&gt;-m&lt;/span&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;;&quot;&gt; 또는 &lt;/span&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-weight:600;&quot;&gt;--minimized&lt;/span&gt;&lt;/pre&gt;&lt;/body&gt;&lt;/html&gt;
&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;시스템 트레이에 최소화된 GUI를 시작합니다.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1348"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;pre style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;;&quot;&gt;Command Line Option: &lt;/span&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-weight:600;&quot;&gt;-w&lt;/span&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;;&quot;&gt; or &lt;/span&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-weight:600;&quot;&gt;--wait-time&lt;/span&gt;&lt;/pre&gt;&lt;/body&gt;&lt;/html&gt;
&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Specify the wait time in seconds before starting the system tray icon (default is 0 seconds).&lt;/p&gt;&lt;p&gt;If CMST is started and tries to create a tray icon before the system tray itself is created a dialog will be displayed explaining that. This sometimes happens when the program is started automatically. If you know the tray will exist once the system is up you may specify a wait time and CMST will wait that number of seconds before trying to create the tray icon. This is to give the window manager or panel time to create the tray before we try to place the icon there.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;pre style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;;&quot;&gt;명령줄 옵션: &lt;/span&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-weight:600;&quot;&gt;-w&lt;/span&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;;&quot;&gt; 또는 &lt;/span&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-weight:600;&quot;&gt;--wait-time&lt;/span&gt;&lt;/pre&gt;&lt;/body&gt;&lt;/html&gt;
&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;시스템 트레이 아이콘을 시작하기 전에 대기 시간을 초 단위로 지정합니다(기본값은 0초).&lt;/p&gt;&lt;p&gt;CMST가 시작되고 시스템 트레이 자체가 생성되기 전에 트레이 아이콘을 생성하려고 하면 설명하는 대화 상자가 표시됩니다. 저것. 이것은 프로그램이 자동으로 시작될 때 가끔 발생합니다. 시스템이 가동되면 트레이가 존재한다는 것을 알고 있는 경우 대기 시간을 지정할 수 있으며 CMST는 트레이 아이콘을 생성하기 전에 해당 시간(초) 동안 대기합니다. 이것은 아이콘을 배치하기 전에 창 관리자 또는 패널에 트레이를 생성할 시간을 주기 위한 것입니다.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1362"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;pre style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;;&quot;&gt;Command Line Option: &lt;/span&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-weight:600;&quot;&gt;--counter-update-rate&lt;/span&gt;&lt;/pre&gt;&lt;/body&gt;&lt;/html&gt;
&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Specify the frequency in seconds between counter updates (default is 10 seconds). &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1366"/>
        <source>Counter Update Rate </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1594"/>
        <source>External Programs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1774"/>
        <source>Aw&amp;Oken</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1781"/>
        <source>A&amp;rtwork</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1963"/>
        <source>Rescan</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1971"/>
        <source>Offline Mode</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="250"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Force a rescan of all WiFi technologies. This is similar to issuing the command &lt;span style=&quot; font-weight:600;&quot;&gt;connmanctl scan wifi&lt;/span&gt; from the command line.&lt;/p&gt;&lt;p&gt;The button will become inactive while the scan is occuring.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="719"/>
        <source>Favorite</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="729"/>
        <source>Security</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="734"/>
        <source>Signal Strength</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="875"/>
        <source>&amp;Counters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="896"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;The service being monitored by the counters.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="899"/>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1658"/>
        <source>Service:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="942"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Counters for the &amp;quot;online&amp;quot; service connection that is not marked roaming. &lt;/p&gt;&lt;p&gt;Counters may not always be available. The counters could have been disabled at the command line (-c or --disable-counters) or occasionally the connection will register &amp;quot;ready&amp;quot; instead of &amp;quot;online&amp;quot;. Online is a &amp;quot;ready&amp;quot; connection that has verified internet connectivity. It is possible to be online with only a &amp;quot;ready&amp;quot; connection, however the counters only work for they &amp;quot;online&amp;quot; connection.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="915"/>
        <source>Home</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="945"/>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1001"/>
        <source>Counter not available.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="971"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Counters for the &amp;quot;online&amp;quot; service connection marked &amp;quot;roaming&amp;quot;.&lt;/p&gt;&lt;p&gt;In the case of cellular services this normally indicates connections to a foreign provider.&lt;/p&gt;&lt;p&gt;Counters may not always be available. The counters could have been disabled at the command line (-c or --disable-counters) or occasionally the connection will register &amp;quot;ready&amp;quot; instead of &amp;quot;online&amp;quot;. Online is a &amp;quot;ready&amp;quot; connection that has verified internet connectivity. It is possible to be online with only a &amp;quot;ready&amp;quot; connection, however the counters only work for they &amp;quot;online&amp;quot; connection.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="974"/>
        <source>Roaming</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1021"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Counter Settings&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1024"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;The threshold values for counter updates (counter resolution).  Data and time work together to define how often the fields are updated.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1027"/>
        <source>Settings:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1042"/>
        <source>&amp;Preferences</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1527"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;pre style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;;&quot;&gt;Command Line Option: &lt;/span&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;; font-weight:600;&quot;&gt;-c&lt;/span&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;;&quot;&gt; or &lt;/span&gt;&lt;span style=&quot; font-family:&apos;monospace&apos;; font-weight:600;&quot;&gt;--enable-counters&lt;/span&gt;&lt;/pre&gt;&lt;p&gt;Enable Connman RX and TX counters.  Counters are experimental in Connman and enabling them will write a large amount of data to the system logs.&lt;/p&gt;&lt;p&gt;Counters are turned off by default, and is a change from the way it was originally.  Up to and including version 2017.09.19 counters were enabled by default.  All versions subsequent to that counters are disabled by default.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1530"/>
        <source>Enable Counters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1503"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;pre style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;;&quot;&gt;Command Line Option: &lt;/span&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-weight:600;&quot;&gt;-n&lt;/span&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;;&quot;&gt; or &lt;/span&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-weight:600;&quot;&gt;--disable-vpn&lt;/span&gt;&lt;/pre&gt;&lt;p&gt;Disable VPN. This will hide the VPN tab and will also skip trying to make a connection to connman-vpn. The later is useful if your Connman was built with the --disable-vpn feature.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1506"/>
        <source>Disable VPN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1471"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;pre style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;;&quot;&gt;Command Line Option: &lt;/span&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-weight:600;&quot;&gt;-M&lt;/span&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;;&quot;&gt; or &lt;/span&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-weight:600;&quot;&gt;--disable-minimized&lt;/span&gt;&lt;/pre&gt;&lt;p&gt;Disable the minimize button. Use when you want to have the window manager have sole control of minimizing the interface.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1474"/>
        <source>Disable Minimized</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1071"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Preferences for the interface are in this box.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1074"/>
        <source>Interface</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1090"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If checked the display of tooltips will be enabled for the interface widgets.&lt;/p&gt;&lt;p&gt;Tooltips are the small popups that appear when you hover the mouse pointer over an area of the interface. &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1093"/>
        <source>Enable ToolTips (Interface)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1103"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Normally counters are cumulative and will retain the connect time and the TX and RX counts between boots. &lt;/p&gt;&lt;p&gt;When this box is checked the counters will reset to zero every time CMST is started, and if CMST is running everytime a Connman service is started. &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1106"/>
        <source>Reset Counters</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1113"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;When checked additional controls for advanced users are displayed.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1116"/>
        <source>Advanced Controls</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1460"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;pre style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;;&quot;&gt;Command Line Option: &lt;/span&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-weight:600;&quot;&gt;-d&lt;/span&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;;&quot;&gt; or &lt;/span&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-weight:600;&quot;&gt;--disable-tray-icon&lt;/span&gt;&lt;/pre&gt;&lt;/body&gt;&lt;/html&gt;
&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Disable the system tray icon.&lt;/p&gt;&lt;p&gt;May be needed for system trays not compliant with the Freedesktop.org system tray specification.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;pre style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;;&quot;&gt;명령줄 옵션: &lt;/span&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-weight:600;&quot;&gt;-d&lt;/span&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;;&quot;&gt; 또는 &lt;/span&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-weight:600;&quot;&gt;--disable-tray-icon&lt;/span&gt;&lt;/pre&gt;&lt;/body&gt;&lt;/html&gt;
&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;시스템 트레이 아이콘을 비활성화합니다.&lt;/p&gt;&lt;p&gt;Freedesktop.org 시스템 트레이 사양과 호환되지 않는 시스템 트레이에 필요할 수 있습니다.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1434"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Disabled because currently Connman will accept this option but will do nothing with it.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1437"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Specify the amount of data in KB that must be transmitted before the counters update (default is 1024 KB).&lt;/p&gt;&lt;p&gt;Connman will accept this entry, but according to a comment in the Connman code the actual feature still needs to be implemented and the selection is therefore disabled.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1440"/>
        <source>Counter Update KB</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1376"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Specify the wait time in seconds before starting the system tray icon (default is 0 seconds).&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;시스템 트레이 아이콘을 시작하기 전에 대기 시간을 초 단위로 지정합니다(기본값: 0초).&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1409"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Specify the amount of data in KB that must be transmitted before the counters update (default is 1024 KB).&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1520"/>
        <source>Start Minimized</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1352"/>
        <source>Wait Time</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1464"/>
        <source>Disable Tray Icon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1080"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If checked the state of the GUI will be restored from settings saved on disk. Settings include the geometry and position of the dialog and the current tab. &lt;/p&gt;&lt;p&gt;These settings will be used at next boot to restore the user interface to the way it was at shutdown.&lt;/p&gt;&lt;p&gt;The settings file is: ~&lt;span style=&quot; font-weight:600;&quot;&gt;/.config/cmst/cmst.conf &lt;/span&gt;&lt;br/&gt;This is a standard ini type text file.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1083"/>
        <source>Retain State</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1450"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;pre style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;;&quot;&gt;Command Line Option: &lt;/span&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-weight:600;&quot;&gt;-i&lt;/span&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;;&quot;&gt; or &lt;/span&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-weight:600;&quot;&gt;--icon-theme&lt;/span&gt;&lt;/pre&gt;&lt;p&gt;Use an icon theme from your system. You may specify the theme in the box at the right, or if the box is left blank CMST will try and use the system wide icon theme (if one is defined).&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1453"/>
        <source>Use Icon Theme</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1553"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Specify the frequency in seconds between counter updates (default is 10 seconds). &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1395"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;pre style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;;&quot;&gt;Command Line Option: &lt;/span&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-weight:600;&quot;&gt;--fake-transparency&lt;/span&gt;&lt;/pre&gt;&lt;/body&gt;&lt;/html&gt;
&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Used to work around a QT bug where system tray icons display with white or black backgrounds instead of being transparent.&lt;/p&gt;&lt;p&gt;You can specify the icon background color here. Format is a hex number in the form RRGGBB.  If the spedified color matches the tray background we&apos;ve effectively created fake transparency. &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;pre style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;;&quot;&gt;명령줄 옵션: &lt;/span&gt;&lt;span style=&quot; font-family:&apos;Courier New,courier&apos;; font-weight:600;&quot;&gt;--fake-transparency&lt;/span&gt;&lt;/pre&gt;&lt;/body&gt;&lt;/html&gt;
&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;시스템 트레이 아이콘이 투명하지 않고 흰색 또는 검은색 배경으로 표시되는 QT 버그를 해결하는 데 사용됩니다.&lt;/p&gt;&lt;p&gt;여기에서 아이콘 배경색을 지정할 수 있습니다. 형식은 RRGGBB 형식의 16진수입니다. 지정된 색상이 트레이 배경과 일치하면 가짜 투명도를 효과적으로 생성한 것입니다. &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="612"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select a wifi service in the table below and press this button to remove the service. &lt;/p&gt;&lt;p&gt;If a service has previously been successfully connected (Favorite is true) this button will remove the Favorite property. The service will also be disconnected if it is currently connected. If the service required a passphrase then the passphrase it will be cleared and forgotten.&lt;/p&gt;&lt;p&gt;If a connection attempt failed this can slso be used to reset the service.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;아래 표에서 Wi-Fi 서비스를 선택하고 이 버튼을 누르면 서비스가 제거됩니다. &lt;/p&gt;&lt;p&gt;서비스가 이전에 성공적으로 연결된 경우(Favorite가 true임) 이 버튼은 Favorite 속성을 제거합니다. 현재 연결되어 있는 경우 서비스도 연결 해제됩니다. 서비스에 암호문구가 필요한 경우 암호문구는 지워지고 잊어버리게 됩니다.&lt;/p&gt;&lt;p&gt;연결 시도가 실패하면 이 암호문구를 사용하여 서비스를 재설정할 수 있습니다.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="746"/>
        <source>&amp;VPN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="752"/>
        <source>VPN Services</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="761"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select a vpn service in the table below and press this button to connect the service. &lt;/p&gt;&lt;p&gt;If there is only one vpn service listed in the table pressing this button will automatically select that service and attempt to connect. &lt;/p&gt;&lt;p&gt;If information about the service is needed, a passphrase for instance, you will be prompted for it. &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;아래 표에서 VPN 서비스를 선택하고 이 버튼을 누르면 서비스가 연결됩니다. &lt;/p&gt;&lt;p&gt;테이블에 하나의 VPN 서비스만 나열되어 있는 경우 이 버튼을 누르면 자동으로 해당 서비스를 선택하고 연결을 시도합니다. &lt;/p&gt;&lt;p&gt;예를 들어 암호문구와 같은 서비스에 대한 정보가 필요한 경우 해당 정보를 입력하라는 메시지가 표시됩니다. &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="774"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select a vpn service in the table below and press this button to disconnect it. &lt;/p&gt;&lt;p&gt;If there is only one vpn service in the &amp;quot;ready&amp;quot; or &amp;quot;online&amp;quot; state pressing this button will automatically select that service and disconnect it. &lt;/p&gt;&lt;p&gt;This may also be used to abort a previous connection attempt.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="858"/>
        <source>Host</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1399"/>
        <source>Fake Transparency</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1484"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Specify the background color as a hex number in the format: RRGGBB.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1540"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Icon theme to use. For this theme to be used it must be installed on your system. If the theme is not installed, or if you spell the name wrong CMST will fall back to using its internal icon set.&lt;/p&gt;&lt;p&gt;If this box is blank CMST will try and use the system wide icon theme (if one is defined).&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1188"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Preferences for the system tray are in this box.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;시스템 트레이에 대한 환경설정이 이 상자에 있습니다.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1191"/>
        <source>System Tray</source>
        <translation>시스템 트레이</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1210"/>
        <source>Hide Tray Icon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1230"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If checked the system tray icon will popup a status message when you hover the mouse over it.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;체크하면 시스템 트레이 아이콘 위에 마우스를 가져가면 상태 메시지가 나타납니다.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1233"/>
        <source>Enable System Tray Popups</source>
        <translation>시스템 트레이 팝업 활성화</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1220"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If checked the system tray will popup a notify message when a significant connman related event is received.&lt;/p&gt;&lt;p&gt;Notifications can be handled by the System Tray Icon, or by a Notify daemon if one is installed.  Both can not be active at the same time.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;체크하면 시스템 트레이는 중요한 connman 관련 이벤트가 수신될 때 알림 메시지를 표시합니다.&lt;/p&gt;&lt;p&gt;알림은 시스템 트레이 아이콘 또는 설치된 경우 알림 데몬에 의해 처리될 수 있습니다. 둘 다 동시에 활성화될 수 없습니다.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1223"/>
        <source>System Tray Notifications</source>
        <translation>시스템 트레이 알림</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1252"/>
        <source>Notifications</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1261"/>
        <source>Notification Daemon</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1274"/>
        <source>Server Status</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="163"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Connman refers to hardware devices as technologies. This box will display information about all known technologies.&lt;/p&gt;&lt;p&gt;To turn a technology on or off click on the button that shows in the &lt;span style=&quot; font-weight:600;&quot;&gt;Powered&lt;/span&gt; column for the technology.&lt;/p&gt;&lt;p&gt;To tether a technology click the button in the &lt;span style=&quot; font-weight:600;&quot;&gt;Tethering&lt;/span&gt; column to on. When tethering is enabled the default service is bridged to all clients connected through the tethered technology. If the &lt;span style=&quot; font-weight:600;&quot;&gt;Tethering&lt;/span&gt; columns are not shown clear the check in &lt;span style=&quot; font-weight:600;&quot;&gt;Less&lt;/span&gt; checkbox below this window.&lt;/p&gt;&lt;p&gt;Note that by default wired connections cannot be tethered. This behavior can be overwritten in the connman.conf file. &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="240"/>
        <source>ID:Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="273"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;To edit the ID and Password of a tethered WiFi device click this button.&lt;/p&gt;&lt;p&gt;The ID and Password are what clients will have to enter to connect to the ad-hoc network. This is only valid for WiFi connections&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="276"/>
        <source>ID:Pass</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="283"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;When checked the tethering columns will be hidden.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="286"/>
        <source>Less</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="385"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Move the selected service before another in the list.&lt;/p&gt;&lt;p&gt;The button will only become active if the selected service can be moved and if there is another valid service which it can be used as a target.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="398"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Move the selected service after another in the list.&lt;/p&gt;&lt;p&gt;The button will only become active if the selected service can be moved and if there is another valid service which it can be used as a target.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1287"/>
        <source>Program Control</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1313"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If checked CMST will place an entry in the autostart directory for the current user, unchecking will remove said entry. This directory is typically: &lt;span style=&quot; font-weight:600;&quot;&gt;${HOME}/.config/autostart&lt;/span&gt;. &lt;/p&gt;&lt;p&gt;CMST only add or remove the .desktop file from the autostart directory. Autostarting is typically dependent upon your Desktop Environment and must be enabled from there.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1316"/>
        <source>Enable Autostart</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1303"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If a Connman service falls into the &amp;quot;Failed&amp;quot; state it will normally remain in that state.&lt;/p&gt;&lt;p&gt;If this box is checked CMST will try to automatically reconnect a WiFi service that enters the &amp;quot;Failed&amp;quot; state. &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1306"/>
        <source>Retry Failed Connection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1134"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Color in #RGB format to colorize the internal icons with.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1144"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Open the color selection dialog. &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="135"/>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1147"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="564"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;The default configuration method for all services is automatic or something like DHCP. This should be good enough for most typical usage, but if it is not this button will allow manual configuration of Ethernet and IP settings for the selected Service.&lt;/p&gt;&lt;p&gt;This button will be disabled if the service is provisioned via an external config file or if the service is of type VPN. It is not possible to modify the properties of these services.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="622"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Select a wifi service in the table below and press this button to edit the service. &lt;/p&gt;&lt;p&gt;The service must have previously been successfully connected (Favorite is true) for this button to work. Pressing &lt;span style=&quot; font-weight:600;&quot;&gt;Edit&lt;/span&gt; will remove the service and then request credentials to establish the connection. If the service is currently connected it will be disconnected first. If the service required a passphrase then the old passphrase it will be cleared and forgotten.&lt;/p&gt;&lt;p&gt;Connman does not provide any methods to retrieve credentials (passphrases, etc.) as that is insecure. CMST will not work around this protection. All this button really does is automate pressing the &lt;span style=&quot; font-weight:600;&quot;&gt;Remove&lt;/span&gt; and &lt;span style=&quot; font-weight:600;&quot;&gt;Connect&lt;/span&gt; buttons above. Make sure you know all of the credentials to reconnect as the existing credentials will be cleared when this button is pressed.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;아래 표에서 Wi-Fi 서비스를 선택하고 이 버튼을 눌러 서비스를 편집합니다. &lt;/p&gt;&lt;p&gt;이 버튼이 작동하려면 서비스가 이전에 성공적으로 연결되어 있어야 합니다(즐겨찾기가 참임). &lt;span style=&quot; font-weight:600;&quot;&gt;편집하기&lt;/span&gt;을 누르면 서비스가 제거되고 연결을 설정하기 위해 자격 증명을 요청합니다. 서비스가 현재 연결되어 있으면 먼저 연결이 끊어집니다. 서비스에 암호문구가 필요한 경우 이전 암호문구는 지워지고 잊어집니다.&lt;/p&gt;&lt;p&gt;Connman은 안전하지 않으므로 자격 증명(암호문구 등)을 검색하는 방법을 제공하지 않습니다. CMST는 이 보호를 우회하지 않습니다. 이 버튼이 실제로 하는 일은 위의 &lt;span style=&quot; font-weight:600;&quot;&gt;제거하기&lt;/span&gt; 및 &lt;span style=&quot; font-weight:600;&quot;&gt;연결하기&lt;/span&gt; 버튼을 누르는 것을 자동화하는 것입니다. 이 버튼을 누르면 기존 자격 증명이 지워지므로 다시 연결할 자격 증명을 모두 알고 있어야 합니다.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="625"/>
        <source>Edit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="632"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Force a rescan of all WiFi technologies. This is similar to issuing the command &lt;span style=&quot; font-weight:600;&quot;&gt;connmanctl scan wifi&lt;/span&gt; from the command line.  This will also clear any selections in the table below.&lt;/p&gt;&lt;p&gt;The button will become inactive while the scan is occuring.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="674"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;This page shows the known WiFi services. &lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Name:&lt;/span&gt; The SSID of the network.&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Favorite:&lt;/span&gt; A heart symbol in this column indicates that this computer has previously made a connection to the network using this service.&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Connected:&lt;/span&gt; Shows the connection state of this service. Hover the mouse over the icon to popup a text description. Online signals that an Internet connectionis available and has been verified. Ready signals a successfully connected device. &lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Security: &lt;/span&gt;Describes the type of security used for this service. Possible values are &amp;quot;none&amp;quot;, &amp;quot;wep&amp;quot;, &amp;quot;psk&amp;quot;, &amp;quot;ieee8021x&amp;quot;, and &amp;quot;wps&amp;quot;.&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Signal Strength:&lt;/span&gt; The strength of the WiFi signal, normalized to a scale of 0 to 100.&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="800"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;This page shows the provisioned VPN services. Some cells in the table may only be available once a connection is estlablished. &lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Name:&lt;/span&gt; The name given in the provisioning file.&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Type:&lt;/span&gt; The VPN type (OpenConnect, OpenVPN, PPTP, etc)&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;State:&lt;/span&gt; Shows the connection state of this service. Hover the mouse over the icon to popup a text description. &lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Host: &lt;/span&gt;VPN Host IP.&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Domain:&lt;/span&gt; The VPN Domain.&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1157"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Internal icons can be colorized. You may select a color using the button to the left, or you may type in the #RGB color yourself.&lt;/p&gt;&lt;p&gt;If you type the entry it must have leading # sign. Example: #22aa44 &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1160"/>
        <source>Colorize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1197"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Hide the CMST tray icon during normal operations. Normal operations are defined as having the Global state in an &lt;span style=&quot; font-weight:600;&quot;&gt;Online&lt;/span&gt; or &lt;span style=&quot; font-weight:600;&quot;&gt;Ready&lt;/span&gt; mode. Any other state will cause the icon to be displayed in the system tray.  CMST is still running even if the icon is hidden.&lt;/p&gt;&lt;p&gt;If CMST is minimized while the icon is hiddden you will need to start another instance CMST to get the interface back. This second instance will restore interface from the first instance and then immediately abort. &lt;/p&gt;&lt;p&gt;If CMST is minimized while the tray icon is visible then simply clicking the tray icon will restore the interface. &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1200"/>
        <source>Hide Tray Icon Unless Needed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1207"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If checked the CMST icon will be hidden in the system tray. CMST is still running even if the icon is hidden.&lt;/p&gt;&lt;p&gt;If CMST is minimized while the icon is hiddden you will need to start another instance CMST to get the interface back. This second instance will restore interface from the first instance and then immediately abort. &lt;/p&gt;&lt;p&gt;If CMST is minimized while the tray icon is visible then simply clicking the tray icon will restore the interface. &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1591"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Programs or processes to execute after various events occur.&lt;/p&gt;&lt;p&gt;If the program or process requires command line arguments provide them here just as if you were typing at a command line. Example:&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;/path/to/program arg1 arg2 arg3&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Two events are checked. &lt;span style=&quot; font-weight:600;&quot;&gt;Before Connecting&lt;/span&gt; events are called after the Connect button is pressed in either the Wireless or VPN tabs. The program or process in the Execute box will only be executed prior to making a connection for the service shown in the Service box.  It will not be called when connecting to any other service.&lt;/p&gt;&lt;p&gt;The program or process in the &lt;span style=&quot; font-weight:600;&quot;&gt;After Connecting&lt;/span&gt; box will be called after Connman enters the ready or online state.&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1613"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;This area is to specify a program or process to run after a wifi or vpn service button is pressed, but before the connect method is sent to ConnMan. This is mainly used to modify a .cmst.config file which seems useful to modify certain short lived entries for openConnect vpn connections.&lt;/p&gt;&lt;p&gt;The program or process in the &lt;span style=&quot; font-weight:600;&quot;&gt;Execute&lt;/span&gt; box will only be executed prior to making a connection for the single service shown in the &lt;span style=&quot; font-weight:600;&quot;&gt;Service&lt;/span&gt; box. It will not be called when connecting to any other service. If a .cmst.config file is to be modified a check must in the &lt;span style=&quot; font-weight:600;&quot;&gt;Modify Service File&lt;/span&gt; box and the path and name of the file to be modified must be provided.&lt;/p&gt;&lt;p&gt;To modify a .cmst.config file CMST will read stdout of the program or process being called. Program output should be individual lines in KEY=VALUE format. If KEY exists in the .cmst.config file it will be replaced by the new VALUE. If KEY does not exist it will be appended. &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1616"/>
        <source>Before Connecting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1632"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Enter the program or process to be executed before Connman initiates a connection to the service listed in the box above. If left blank no program or process will be executed.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1635"/>
        <source>Execute:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1655"/>
        <source>Specify the service you are connecting to where you want a program or process to execute prior to initiating the connection.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1670"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If checked the configuration file shown below will be modified by whatever output the program provides.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1673"/>
        <source>Modify Service File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1682"/>
        <source>Service configuration file to be modified by the program.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1685"/>
        <source>FIle: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1722"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Enter the program or process to be executed after Connman enters the &lt;span style=&quot; font-weight:600;&quot;&gt;Ready&lt;/span&gt; or &lt;span style=&quot; font-weight:600;&quot;&gt;Online&lt;/span&gt; state.  If left blank no program or process will be executed.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1729"/>
        <source>After Connecting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1749"/>
        <source>&amp;Help</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1755"/>
        <source>&amp;About</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1761"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Display a dialog box containing information about this program. &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1764"/>
        <source>C&amp;MST</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1771"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Display a dialog box containing information about the Icon set used in this program. &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1788"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Display a dialog box containing information about the QT toolkit used to develop this program. &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1791"/>
        <source>&amp;QT</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1798"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Use this button to view the program license.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1801"/>
        <source>&amp;License</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1808"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Use this button to view the change log of the program.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1811"/>
        <source>ChangeLo&amp;g</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1849"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Help&lt;/span&gt;&lt;/p&gt;&lt;p&gt;Program help is mainly provided by the &amp;quot;What&apos;s This&amp;quot; button in the lower left corner. Press the button and then click on an item you are interested in. &amp;quot;What&apos;s This&amp;quot; is also available via context menu by right clicking on a button, box or text area.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1885"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;What&apos;s This&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1888"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Use this button to find information about an element in the GUI by entering &amp;quot;What&apos;s This&amp;quot; mode. &lt;/p&gt;&lt;p&gt;You may also right click on an element to show the &amp;quot;What&apos;s This&amp;quot; text for it.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1898"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Open the provisioning editor to create or edit Connman configuration (provisioning) files.&lt;/p&gt;&lt;p&gt;These config files reside in /var/lib/connman which is owned by root:root. CMST will register a roothelper to allow reading and writing files in this directory. &lt;/p&gt;&lt;p&gt;To avoid abusing the root privileges the editor will only operate on files with names ending in &lt;span style=&quot; font-style:italic;&quot;&gt;.cmst.config&lt;/span&gt;. This file name ending will be added automatically during a file save and cannot be altered. &lt;/p&gt;&lt;p&gt;Using this editor it is not possible to edit or delete config files created by other means.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1901"/>
        <source>Provisioning Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1908"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Open the VPN provisioning editor to create or edit Connman configuration (provisioning) files for VPN connections.&lt;/p&gt;&lt;p&gt;These config files reside in /var/lib/connman-vpn which is owned by root:root. CMST will register a roothelper to allow reading and writing files in this directory. &lt;/p&gt;&lt;p&gt;To avoid abusing the root privileges the editor will only operate on files with names ending in &lt;span style=&quot; font-style:italic;&quot;&gt;.cmst.config&lt;/span&gt;. This file name ending will be added automatically during a file save and cannot be altered. &lt;/p&gt;&lt;p&gt;Using this editor it is not possible to edit or delete config files created by other means.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1911"/>
        <source>VPN Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1918"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Exit the program and remove the system tray icon. Connman will still be running as a daemon but will not be managed by this program.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1921"/>
        <source>E&amp;xit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1941"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Minimize the dialog. If you have the system tray Icon shown this dialog may be restored by right clicking on the tray icon. If the tray icon is hidden minimize will not be active.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1944"/>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="423"/>
        <source>Mi&amp;nimize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1976"/>
        <source>IDPass</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/ui/controlbox.ui" line="1979"/>
        <source>Set ID and Password for tethered wifi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="424"/>
        <source>Ma&amp;ximize</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="427"/>
        <source>&amp;Exit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="529"/>
        <source>About %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="150"/>
        <source>Service Details</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="151"/>
        <source>WiFi Connections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="152"/>
        <source>VPN Connections</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="557"/>
        <source>About AwOken</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="588"/>
        <source>License</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="596"/>
        <source>%1 change log is not available.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="598"/>
        <source>ChangeLog</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="721"/>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="2756"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="746"/>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="751"/>
        <source>&lt;b&gt;Service:&lt;/b&gt; %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="751"/>
        <source>Unable to determine service</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="783"/>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="893"/>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="930"/>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="964"/>
        <source>No Services Selected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="931"/>
        <source>You need to select a Wifi service before pressing the remove button.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="996"/>
        <source>Offline Mode Engaged</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1001"/>
        <source>Offline Mode Disabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1015"/>
        <source>Network Services:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1282"/>
        <source>Service Error: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1283"/>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1328"/>
        <source>Object Path: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1321"/>
        <source>VPN Engaged</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1325"/>
        <source>VPN Disengaged</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1411"/>
        <source>&lt;b&gt;Technology: %1&lt;/b&gt;&lt;p&gt;Please enter the WiFi AP SSID that clients will&lt;br&gt;have to join in order to gain internet connectivity.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1423"/>
        <source>&lt;b&gt;Technology: %1&lt;/b&gt;&lt;p&gt;Please enter the WPA pre-shared key clients will&lt;br&gt;have to use in order to establish a connection.&lt;p&gt;PSK length: minimum of 8 characters.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="2313"/>
        <source>Ethernet Connection
</source>
        <comment>icon_tool_tip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="2314"/>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="2342"/>
        <source>Service: %1
</source>
        <translation>서비스: %1
</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="2320"/>
        <source>WiFi Connection
</source>
        <comment>icon_tool_tip</comment>
        <translation>WiFi 연결
</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="2322"/>
        <source>SSID: %1
</source>
        <translation>SSID: %1
</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="2327"/>
        <source>Security: %1
</source>
        <translation>보안: %1
</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="2328"/>
        <source>Strength: %1%
</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="2340"/>
        <source>VPN Connection
</source>
        <comment>icon_tool_tip</comment>
        <translation>VPN 연결
</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="2341"/>
        <source>Type: %1
</source>
        <translation>유형: %1
</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="2343"/>
        <source>Host: %1</source>
        <translation>호스트: %1</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="2805"/>
        <source> Warning</source>
        <translation> 경고</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1641"/>
        <source>&lt;b&gt;Connection:&lt;/b&gt; %1</source>
        <translation>&lt;b&gt;연결:&lt;/b&gt; %1</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="530"/>
        <source>&lt;center&gt;%1 is a program to interface with the Connman daemon and to provide a system tray control.&lt;br&gt;&lt;center&gt;Version &lt;b&gt;%2&lt;/b&gt;&lt;center&gt;Release date: %3&lt;center&gt;Copyright c %4&lt;center&gt;by&lt;center&gt;Andrew J. Bibb&lt;center&gt;Vermont, USA&lt;br&gt;&lt;center&gt;&lt;b&gt;Translations:&lt;/b&gt;&lt;center&gt;Jianfeng Zhang (Chinese)&lt;center&gt;sqozz (German)&lt;center&gt;Ilya Shestopalov (Russian)&lt;center&gt;Heimen Stoffels (Dutch)&lt;center&gt; Yaşar Çiv (Turkish)&lt;br&gt;&lt;center&gt;&lt;b&gt;Build Information:&lt;/b&gt;&lt;center&gt;Compiled using QT version %5&lt;center&gt;Connman version %6</source>
        <translation>&lt;center&gt;%1은(는) Connman 데몬과 인터페이스하고 시스템 트레이 제어를 제공하는 프로그램입니다.&lt;br&gt;&lt;center&gt;버전 &lt;b&gt;%2&lt;/b&gt;&lt;center&gt;릴리스 날짜: %3&lt;center&gt;저작권 c %4&lt;center&gt;by&lt;center&gt;Andrew J. Bibb&lt;center&gt;미국, 버몬트주&lt;br&gt;&lt;center&gt;&lt;b&gt;번역:&lt;/b&gt;&lt;center&gt;이정희(한국어)&lt;center&gt;Jianfeng Zhang(중국어)&lt;center&gt;sqozz(독일어) &lt;center&gt;Ilya Shestopalov(러시아어)&lt;center&gt;Heimen Stoffels(네덜란드어)&lt;center&gt; Yaşar Çiv(터키어)&lt;br&gt;&lt;center&gt;&lt;b&gt;빌드 정보:&lt;/b&gt;&lt;center&gt;QT %5 버전을 사용하여 컴파일됨&lt;center&gt;Connman 버전 %6</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="571"/>
        <source>About Other Artwork</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="572"/>
        <source>&lt;center&gt;This program uses artwork from &lt;b&gt;Freepik&lt;/b&gt; obtained from www.flaticon.com:&lt;br&gt;&lt;br&gt;Released under the Flaticon Basic License&lt;br&gt;&lt;a href=&quot;url&quot;&gt;https://file000.flaticon.com/downloads/license/license.pdf&lt;/a&gt;&lt;br&gt;&lt;br&gt;&lt;b&gt;Artwork files:&lt;/b&gt;&lt;li&gt;radio.png&lt;/li&gt;&lt;li&gt;basic-plane.png&lt;/li&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="965"/>
        <source>You need to select a Wifi service before pressing the edit button.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="998"/>
        <source>All network devices are powered off, now in Airplane mode.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1003"/>
        <source>Power has been restored to all previously powered network devices.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1018"/>
        <source>The system is online.</source>
        <translation>시스템이 온라인 상태입니다.</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1024"/>
        <source>The system is offline.</source>
        <translation>시스템이 오프라인 상태입니다.</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1125"/>
        <source>VPN Kill Switch Engaged</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1126"/>
        <source>The connection to VPN service %1 was dropped and the VPN kill switch was engaged. All network devices are powered off.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1644"/>
        <source>&lt;br&gt;&lt;b&gt;Service Details:&lt;/b&gt;&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1646"/>
        <source>Service Type: %1&lt;br&gt;</source>
        <translation>서비스 유형: %1&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1648"/>
        <source>Service Name: %1&lt;br&gt;</source>
        <translation>서비스 이름: %1&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1649"/>
        <source>Service State: %1&lt;br&gt;</source>
        <translation>서비스 국가: %1&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1650"/>
        <source>Favorite: %1&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1650"/>
        <source>Yes</source>
        <comment>favorite</comment>
        <translation>예</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1650"/>
        <source>No</source>
        <comment>favorite</comment>
        <translation>아니요</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1651"/>
        <source>External Configuration File: %1&lt;br&gt;</source>
        <translation>외부 구성 파일: %1&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1651"/>
        <source>Yes</source>
        <comment>immutable</comment>
        <translation>예</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1651"/>
        <source>No</source>
        <comment>immutable</comment>
        <translation>아니요</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1653"/>
        <source>Auto Connect: %1&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1653"/>
        <source>On</source>
        <comment>autoconnect</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1653"/>
        <source>No</source>
        <comment>autoconnect</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1655"/>
        <source>&lt;br&gt;&lt;b&gt;IPv4&lt;/b&gt;&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1657"/>
        <source>IP Address Acquisition: %1&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1658"/>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1665"/>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1700"/>
        <source>IP Address: %1&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1659"/>
        <source>IP Netmask: %1&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1660"/>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1671"/>
        <source>IP Gateway: %1&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1662"/>
        <source>&lt;br&gt;&lt;b&gt;IPv6&lt;/b&gt;&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1664"/>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1677"/>
        <source>Address Acquisition: %1&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1668"/>
        <source>Prefix Length: &lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1670"/>
        <source>Prefix Length: %1&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1672"/>
        <source>Privacy: %1&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1674"/>
        <source>&lt;br&gt;&lt;b&gt;Proxy&lt;/b&gt;&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1679"/>
        <source>URL: %1&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1682"/>
        <source>Servers:&lt;br&gt;&amp;nbsp;&amp;nbsp;%1&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1683"/>
        <source>Excludes:&lt;br&gt;&amp;nbsp;&amp;nbsp;%1&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1688"/>
        <source>&lt;br&gt;&lt;b&gt;mDNS&lt;/b&gt;&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1689"/>
        <source>Support Enabled: %1&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1689"/>
        <source>Yes</source>
        <comment>mdns</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1689"/>
        <source>No</source>
        <comment>mdns</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1698"/>
        <source>&lt;br&gt;&lt;b&gt;Last Address Conflict&lt;/b&gt;&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1702"/>
        <source>MAC Address: %1&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1703"/>
        <source>Conflict detected on: %1&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1704"/>
        <source>Resolved: %1&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1704"/>
        <source>Yes</source>
        <comment>last_address_conflict</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1704"/>
        <source>No</source>
        <comment>last_address_conflict</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1713"/>
        <source>&lt;br&gt;&lt;b&gt;Name Servers&lt;/b&gt;&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1716"/>
        <source>&lt;br&gt;&lt;br&gt;&lt;b&gt;Time Servers&lt;/b&gt;&lt;br&gt;  </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1719"/>
        <source>&lt;br&gt;&lt;br&gt;&lt;b&gt;Search Domains&lt;/b&gt;&lt;br&gt;  </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1722"/>
        <source>&lt;br&gt;&lt;br&gt;&lt;b&gt;Ethernet&lt;/b&gt;&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1724"/>
        <source>Connection Method: %1&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1725"/>
        <source>Interface: %1&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1726"/>
        <source>Device Address: %1&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1727"/>
        <source>MTU: %1&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1729"/>
        <source>&lt;br&gt;&lt;b&gt;Wireless&lt;/b&gt;&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1734"/>
        <source>Security: %1&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1735"/>
        <source>Strength: %1&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1736"/>
        <source>Roaming: %1&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1736"/>
        <source>Yes</source>
        <comment>roaming</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1736"/>
        <source>No</source>
        <comment>roaming</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1738"/>
        <source>&lt;br&gt;&lt;b&gt;VPN Provider&lt;/b&gt;&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1740"/>
        <source>Host: %1&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1741"/>
        <source>Domain: %1&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1742"/>
        <source>Name: %1&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1743"/>
        <source>Type: %1&lt;br&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1836"/>
        <source>State: </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1842"/>
        <source>Engaged</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1847"/>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="2434"/>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="2507"/>
        <source>Disabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1850"/>
        <source>Offline Mode </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1904"/>
        <source>Yes</source>
        <comment>connected</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1904"/>
        <source>No</source>
        <comment>connected</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1911"/>
        <source>On</source>
        <comment>tethering</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1916"/>
        <source>Off</source>
        <comment>tethering</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="2257"/>
        <source>Update resolution of the counters is based on a threshold of %L1 KB of data and %L2 seconds of time.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="2315"/>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="2329"/>
        <source>Interface: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="2357"/>
        <source>Connection is in the Failure State, attempting to reestablish the connection</source>
        <comment>icon_tool_tip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="2361"/>
        <source>Connection is in the Failure State.</source>
        <comment>icon_tool_tip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="2367"/>
        <source>Not Connected</source>
        <comment>icon_tool_tip</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="2374"/>
        <source>Error retrieving properties via Dbus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="2375"/>
        <source>Connection status is unknown</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="2428"/>
        <source>Type: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="2429"/>
        <source>&lt;br&gt;Powered </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="2430"/>
        <source>On</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="2430"/>
        <source>Off</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="2432"/>
        <source>Not Connected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="2433"/>
        <source>&lt;br&gt;Tethering </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="2434"/>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="2507"/>
        <source>Enabled</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="2494"/>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="2524"/>
        <source>Connection : %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="2496"/>
        <source>Signal Strength: %1%</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="2498"/>
        <source>Favorite Connection</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="2498"/>
        <source>Never Connected</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="2505"/>
        <source>&lt;br&gt;Roaming</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="2506"/>
        <source>&lt;br&gt;Autoconnect is </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="2806"/>
        <source>&lt;center&gt;&lt;b&gt;Unable to find a systemtray on this machine.&lt;/b&gt;&lt;center&gt;&lt;br&gt;The program may still be used to manage your connections, but the tray icon will be disabled.&lt;center&gt;&lt;br&gt;&lt;br&gt;If you are seeing this message at system start up and you know a system tray exists once the system is up, try starting with the &lt;b&gt;-w&lt;/b&gt; switch and set a delay as necessary. The exact wait time will vary from system to system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="2987"/>
        <source>Could not find a connection to the system bus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="2988"/>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="2993"/>
        <source>%1 - Critical Error</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="2989"/>
        <source>Unable to find a connection to the system bus.&lt;br&gt;&lt;br&gt;%1 will not be able to communicate with connman.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="2992"/>
        <source>Could not create an interface to connman on the system bus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="2994"/>
        <source>Unable to create an interface to connman on the system bus.&lt;br&gt;&lt;br&gt;%1 will not be able to communicate with connman.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="2997"/>
        <source>Error reading or parsing connman.Manager.GetProperties</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="2998"/>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="3003"/>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="3008"/>
        <source>%1 - Warning</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="2999"/>
        <source>There was an error reading or parsing the reply from method connman.Manager.GetProperties.&lt;br&gt;&lt;br&gt;It is unlikely any portion of %1 will be functional.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="3002"/>
        <source>Error reading or parsing connman.Manager.GetTechnologies</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="3004"/>
        <source>There was an error reading or parsing the reply from method connman.Manager.GetTechnologies.&lt;br&gt;&lt;br&gt;Some portion of %1 may still be functional.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="3007"/>
        <source>Error reading or parsing connman.Manager.GetServices</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="3009"/>
        <source>There was an error reading or parsing the reply from method connman.Manager.GetServices.&lt;br&gt;&lt;br&gt;Some portion of %1 may still be functional.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="3016"/>
        <source>Could not create an interface to connman-vpn on the system bus</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="3079"/>
        <source>[Hidden Wifi]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="3133"/>
        <source>%1 version %2 by %3 has been detected on this system.&lt;p&gt;This server supports desktop Notification Specification version %4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="3145"/>
        <source>Attempt %1 of %2 looking for notification server.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="3148"/>
        <source>Unable to connect to a notification server after %1 tries.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="3261"/>
        <source>Colorize Icons</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="2493"/>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="2523"/>
        <source>&lt;p style=&apos;white-space:pre&apos;&gt;&lt;center&gt;&lt;b&gt;%1&lt;/b&gt;&lt;/center&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="558"/>
        <source>&lt;center&gt;This program uses the &lt;b&gt;AwOken&lt;/b&gt; icon set version 2.5&lt;br&gt;&lt;br&gt;Released under the&lt;br&gt;Creative Commons&lt;br&gt;Attribution-Share Alike 3.0&lt;br&gt;Unported License&lt;br&gt;&lt;a href=&quot;url&quot;&gt;http://creativecommons.org/licenses/by-sa/3.0/legalcode&lt;/a&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1891"/>
        <source>On</source>
        <comment>powered</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="1896"/>
        <source>Off</source>
        <comment>powered</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="2504"/>
        <source>Security: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="586"/>
        <source>%1 license is the MIT (Expat) license.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="784"/>
        <source>You need to select a service before pressing the connect button.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="894"/>
        <source>You need to select a service before pressing the disconnect button.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="2427"/>
        <source>&lt;p style=&apos;white-space:pre&apos;&gt;&lt;center&gt;&lt;b&gt;%1 Properties&lt;/b&gt;&lt;/center&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/control_box/controlbox.cpp" line="2057"/>
        <source>  WiFi Technologies:&lt;br&gt;  %1 Found, %2 Powered</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>GEN_Editor</name>
    <message>
        <location filename="../apps/cmstapp/code/gen_conf_ed/gen_conf_ed.cpp" line="214"/>
        <source>File save failed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/gen_conf_ed/gen_conf_ed.cpp" line="217"/>
        <source>%L1 KB written</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/gen_conf_ed/gen_conf_ed.cpp" line="219"/>
        <source>%L1 Bytes written</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/gen_conf_ed/gen_conf_ed.cpp" line="232"/>
        <source> Critical</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/gen_conf_ed/gen_conf_ed.cpp" line="233"/>
        <source>&lt;b&gt;DBus Error Name:&lt;/b&gt; %1&lt;br&gt;&lt;br&gt;&lt;b&gt;String:&lt;/b&gt; %2&lt;br&gt;&lt;br&gt;&lt;b&gt;Message:&lt;/b&gt; %3</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>IconManager</name>
    <message>
        <location filename="../apps/cmstapp/code/iconman/iconman.cpp" line="351"/>
        <source>A new icon definition file will be installed to &lt;b&gt;%1&lt;/b&gt; and a backup of the old definition file has been created as &lt;b&gt;%2&lt;/b&gt;                   &lt;p&gt;If the original definition file was customized and you wish to retain those changes you will need to manually merge them into the new file.                    &lt;p&gt;If the original was never customized or you just wish to delete the backup now you may select &lt;i&gt;Discard&lt;/i&gt; to delete the backup or &lt;i&gt;Save&lt;/i&gt; to retain it.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Peditor</name>
    <message>
        <location filename="../apps/cmstapp/code/peditor/ui/peditor.ui" line="14"/>
        <source>Property Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/peditor/ui/peditor.ui" line="35"/>
        <source>&amp;General</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/peditor/ui/peditor.ui" line="44"/>
        <source>AutoConnect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/peditor/ui/peditor.ui" line="76"/>
        <source>&amp;Nameservers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/peditor/ui/peditor.ui" line="152"/>
        <source>&amp;Domains</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/peditor/ui/peditor.ui" line="187"/>
        <source>IPv&amp;4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/peditor/ui/peditor.ui" line="209"/>
        <location filename="../apps/cmstapp/code/peditor/ui/peditor.ui" line="422"/>
        <source>Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/peditor/ui/peditor.ui" line="230"/>
        <source>Netmask</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/peditor/ui/peditor.ui" line="240"/>
        <location filename="../apps/cmstapp/code/peditor/ui/peditor.ui" line="369"/>
        <source>Gateway</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/peditor/ui/peditor.ui" line="268"/>
        <location filename="../apps/cmstapp/code/peditor/ui/peditor.ui" line="453"/>
        <location filename="../apps/cmstapp/code/peditor/ui/peditor.ui" line="489"/>
        <source>Method</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/peditor/ui/peditor.ui" line="299"/>
        <source>IPv&amp;6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/peditor/ui/peditor.ui" line="399"/>
        <source>Prefix Length</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/peditor/ui/peditor.ui" line="355"/>
        <source>Privacy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/peditor/ui/peditor.ui" line="471"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;User configuration of Proxy settings.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/peditor/ui/peditor.ui" line="474"/>
        <source>&amp;Proxy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/peditor/ui/peditor.ui" line="518"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Automatic proxy configuration URL.  Used by the &amp;quot;auto&amp;quot; method.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/peditor/ui/peditor.ui" line="511"/>
        <source>URL</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/peditor/ui/peditor.ui" line="114"/>
        <source>&amp;Timeservers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/peditor/ui/peditor.ui" line="206"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;The IPv4 address to use for this connection.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/peditor/ui/peditor.ui" line="237"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;The IPv4 gateway for this connection. This field is optional and may be left blank&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/peditor/ui/peditor.ui" line="227"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;The IPv4 netmask for this connection.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/peditor/ui/peditor.ui" line="41"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;If checked this service will auto-connect when no other connection is available. This is only available for services marked &amp;quot;Favorite&amp;quot;. &lt;/p&gt;&lt;p&gt;The service will not auto-connect while roaming.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <comment>property editor</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/peditor/ui/peditor.ui" line="73"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;The list of manually configured domain name servers. Some cellular networks don&apos;t provide correct name servers and this allows for an override.&lt;/p&gt;&lt;p&gt;This array is sorted by priority and the first entry in the list represents the nameserver with the highest priority.&lt;/p&gt;&lt;p&gt;When using manual configuration and no global nameservers are configured, then it is useful to configure this setting.&lt;/p&gt;&lt;p&gt;Enter one or more IP addresses. Separate each address you enter by a comma, semi-colon, vertical bar, or by white space.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/peditor/ui/peditor.ui" line="111"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;The list of manually configured time servers.&lt;/p&gt;&lt;p&gt;The first entry in the list represents the timeserver with the highest priority.&lt;/p&gt;&lt;p&gt;When using manual configuration this setting is useful to override all the other timeserver settings. This is service specific, hence only the values for the default service are used.&lt;/p&gt;&lt;p&gt;Changes to this property will result in restart of NTP query.&lt;/p&gt;&lt;p&gt;Enter one or more IP addresses. Separate each address you enter by a comma, semi-colon, vertical bar, or by white space.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/peditor/ui/peditor.ui" line="149"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;List of manually configures search domains.&lt;/p&gt;&lt;p&gt;Enter one or more IP addresses. Separate each address you enter by a comma, semi-colon, vertical bar, or by white space.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/peditor/ui/peditor.ui" line="195"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;The IPv4 address to use for this connection.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <comment>property editor</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/peditor/ui/peditor.ui" line="216"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;The IPv4 gateway for this connection. This field is optional and may be left blank&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <comment>property editor</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/peditor/ui/peditor.ui" line="247"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;The IPv4 netmask for this connection.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <comment>property editor</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/peditor/ui/peditor.ui" line="265"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Possible values of &lt;span style=&quot; font-weight:600;&quot;&gt;dhcp&lt;/span&gt;, &lt;span style=&quot; font-weight:600;&quot;&gt;manual&lt;/span&gt;, and &lt;span style=&quot; font-weight:600;&quot;&gt;off&lt;/span&gt;.&lt;/p&gt;&lt;p&gt;If &lt;span style=&quot; font-weight:600;&quot;&gt;manual&lt;/span&gt; is selected boxes for &lt;span style=&quot; font-weight:600;&quot;&gt;Address&lt;/span&gt;, &lt;span style=&quot; font-weight:600;&quot;&gt;Netmask&lt;/span&gt; and&lt;span style=&quot; font-weight:600;&quot;&gt; Gateway&lt;/span&gt; will become visible.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/peditor/ui/peditor.ui" line="321"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Enable or disable the IPv6 privacy extension as described in RFC 4941,&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Disabled&lt;/span&gt;: privacy extension is disabled and normal autoconf addresses are used.&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Enabled&lt;/span&gt;: the system prefers to use public addresses over temporary addresses.&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Prefered&lt;/span&gt;: privacy extension is enabled and the system prefers temporary addresses over public addresses.&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;&lt;br /&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/peditor/ui/peditor.ui" line="366"/>
        <location filename="../apps/cmstapp/code/peditor/ui/peditor.ui" line="389"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;The IPv6 gateway for this connection. This field is optional and may be left blank&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/peditor/ui/peditor.ui" line="379"/>
        <location filename="../apps/cmstapp/code/peditor/ui/peditor.ui" line="396"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;The prefix length of the IPv6 connection.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/peditor/ui/peditor.ui" line="409"/>
        <location filename="../apps/cmstapp/code/peditor/ui/peditor.ui" line="419"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;The IPv6 address to use for this connection.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/peditor/ui/peditor.ui" line="450"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Possible values are &amp;quot;auto&amp;quot;, &amp;quot;manual&amp;quot;,  and &amp;quot;off&amp;quot;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/peditor/ui/peditor.ui" line="542"/>
        <source>Servers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/peditor/ui/peditor.ui" line="619"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Check to enable mDNS.  Note that mDNS requires a DNS backend which supports it.&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <comment>property editor</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/peditor/ui/peditor.ui" line="561"/>
        <source>Excludes</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/peditor/ui/peditor.ui" line="352"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Enable or disable the IPv6 privacy extension as described in RFC 4941.&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Disabled&lt;/span&gt;: privacy extension is disabled and normal autoconf addresses are used.&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Enabled&lt;/span&gt;: the system prefers to use public addresses over temporary addresses.&lt;/p&gt;&lt;p&gt;&lt;span style=&quot; font-weight:600;&quot;&gt;Prefered&lt;/span&gt;: privacy extension is enabled and the system prefers temporary addresses over public addresses.&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/peditor/ui/peditor.ui" line="549"/>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans Serif&apos;; font-size:9pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Used when &amp;quot;manual&amp;quot; is set. List of proxy URIs. The URI without a protocol will be interpreted as the generic proxy URI.&lt;/p&gt;
&lt;p style=&quot; margin-top:12px; margin-bottom:12px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Enter one or more IP addresses. Separate each address you enter by a comma, semi-colon, or by white space.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <comment>property editor</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/peditor/ui/peditor.ui" line="568"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Used when &amp;quot;manual&amp;quot; is set.  A list of hosts which can be accessed directly.&lt;/p&gt;&lt;p&gt;&lt;br/&gt;&lt;/p&gt;&lt;p&gt;Enter one or more IP addresses.  Separate each address you enter by a comma, semi-colon, or by white space.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/peditor/ui/peditor.ui" line="602"/>
        <source>Check to enable mDNS. Note that mDNS requires a DNS backend which supports it.

</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/peditor/ui/peditor.ui" line="607"/>
        <source>&amp;mDNS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/peditor/ui/peditor.ui" line="622"/>
        <source>Enable mDNS </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/peditor/ui/peditor.ui" line="640"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;What&apos;s This&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/peditor/ui/peditor.ui" line="663"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Clear all entries on the current page.&lt;/p&gt;&lt;p&gt;This button will reset every field on the current page to the default value, which generally means nothing in the field.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/peditor/ui/peditor.ui" line="666"/>
        <source>Reset Pa&amp;ge</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/peditor/ui/peditor.ui" line="673"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Clear all fields on every page of the dialog.&lt;/p&gt;&lt;p&gt;This will reset every field on every page to the default value for the field. &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/peditor/ui/peditor.ui" line="676"/>
        <source>Reset &amp;All</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/peditor/ui/peditor.ui" line="703"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Accept the entries, send them to Connman, and close the dialog.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/peditor/ui/peditor.ui" line="706"/>
        <source>OK</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/peditor/ui/peditor.ui" line="713"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Close the dialog without sending any entries to Connman.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/peditor/ui/peditor.ui" line="716"/>
        <source>Cancel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>Provisioning</name>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/ui/provisioning_editor.ui" line="14"/>
        <source>Provisioning Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/ui/provisioning_editor.ui" line="23"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Text edit window.&lt;/p&gt;&lt;p&gt;You may type or cut and paste into this window. You may also use menus above to insert text fields.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/ui/provisioning_editor.ui" line="32"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Open an existing config file.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/ui/provisioning_editor.ui" line="35"/>
        <source>&amp;Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/ui/provisioning_editor.ui" line="48"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Write the displayed data to a config file.&lt;/p&gt;&lt;p&gt;The combo box is seeded with a list of CMST created config files to provide an easy way to overwrite one. You may also type a name in the ComboBox.&lt;/p&gt;&lt;p&gt;It is not necessary to provide a path nor a file extension as both will be stripped out and replaced allowed values. &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/ui/provisioning_editor.ui" line="51"/>
        <source>&amp;Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/ui/provisioning_editor.ui" line="68"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Delete a config file.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/ui/provisioning_editor.ui" line="71"/>
        <source>&amp;Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/ui/provisioning_editor.ui" line="94"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Clear all text from the editor window.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/ui/provisioning_editor.ui" line="97"/>
        <source>&amp;Clear Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/ui/provisioning_editor.ui" line="111"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;What&apos;s This&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/ui/provisioning_editor.ui" line="114"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Enter &amp;quot;Whats This&amp;quot; mode.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/ui/provisioning_editor.ui" line="137"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Exit the dialog.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/ui/provisioning_editor.ui" line="140"/>
        <source>E&amp;xit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/ui/provisioning_editor.ui" line="152"/>
        <source>[global]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/ui/provisioning_editor.ui" line="157"/>
        <location filename="../apps/cmstapp/code/provisioning/ui/provisioning_editor.ui" line="220"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/ui/provisioning_editor.ui" line="162"/>
        <source>Description</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/ui/provisioning_editor.ui" line="167"/>
        <source>[service_*]</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/ui/provisioning_editor.ui" line="175"/>
        <source>Type</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/ui/provisioning_editor.ui" line="183"/>
        <source>MAC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/ui/provisioning_editor.ui" line="191"/>
        <source>Nameservers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/ui/provisioning_editor.ui" line="199"/>
        <source>Timeservers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/ui/provisioning_editor.ui" line="207"/>
        <source>SearchDomains</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/ui/provisioning_editor.ui" line="215"/>
        <source>Domain</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/ui/provisioning_editor.ui" line="228"/>
        <source>SSID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/ui/provisioning_editor.ui" line="236"/>
        <source>EAP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/ui/provisioning_editor.ui" line="244"/>
        <source>CACertFile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/ui/provisioning_editor.ui" line="252"/>
        <source>ClientCertFile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/ui/provisioning_editor.ui" line="260"/>
        <source>PrivateKeyFile</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/ui/provisioning_editor.ui" line="265"/>
        <source>PrivateKeyPassphrase</source>
        <translation>개인키 암호문구</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/ui/provisioning_editor.ui" line="273"/>
        <source>PrivateKeyPassphraseType</source>
        <translation>개인키 암호문구 유형</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/ui/provisioning_editor.ui" line="278"/>
        <source>Identity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/ui/provisioning_editor.ui" line="286"/>
        <source>Phase2</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/ui/provisioning_editor.ui" line="291"/>
        <source>Passphrase</source>
        <translation>암호문구</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/ui/provisioning_editor.ui" line="299"/>
        <source>Security</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/ui/provisioning_editor.ui" line="307"/>
        <source>Hidden</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/ui/provisioning_editor.ui" line="312"/>
        <source>Eduroam (long)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/ui/provisioning_editor.ui" line="317"/>
        <source>Eduroam (short)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/ui/provisioning_editor.ui" line="322"/>
        <source>IPv4</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/ui/provisioning_editor.ui" line="325"/>
        <source>Set IPv4 to &quot;off&quot;, &quot;dhcp&quot;, or enter IPV4 address information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/ui/provisioning_editor.ui" line="330"/>
        <source>IPv6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/ui/provisioning_editor.ui" line="333"/>
        <source>Set IPv6 to &quot;off, &quot;auto&quot;, or enter IPv6 address information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/ui/provisioning_editor.ui" line="367"/>
        <source>DeviceName</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/ui/provisioning_editor.ui" line="370"/>
        <source>Interface name where this provisioning applies (ex: eth0)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/ui/provisioning_editor.ui" line="375"/>
        <source>mDNS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/ui/provisioning_editor.ui" line="378"/>
        <source>Set to true if mDNS domains can be resolved and the hostname registered.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/ui/provisioning_editor.ui" line="383"/>
        <source>AnonymousIdentity</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/ui/provisioning_editor.ui" line="386"/>
        <source>Anonymous identity string for EAP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/ui/provisioning_editor.ui" line="391"/>
        <source>SubjectMatch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/ui/provisioning_editor.ui" line="394"/>
        <source>Substring to be matched against the subject of the authentication server certificate for EAP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/ui/provisioning_editor.ui" line="399"/>
        <source>AltSubjectMatch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/ui/provisioning_editor.ui" line="402"/>
        <source>Semicolon separated string of entries to be matched against the alternative subject name of the authentication server certificate for EAP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/ui/provisioning_editor.ui" line="407"/>
        <source>DomainSuffixMatch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/ui/provisioning_editor.ui" line="410"/>
        <source>A FQDN used as a suffix match requirement for the authentication server.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/ui/provisioning_editor.ui" line="415"/>
        <source>DomainMatch</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/ui/provisioning_editor.ui" line="418"/>
        <source>A FQDN used as a full match requirement for the authentication server.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/ui/provisioning_editor.ui" line="343"/>
        <location filename="../apps/cmstapp/code/provisioning/ui/provisioning_editor.ui" line="346"/>
        <source>EAP-PEAP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/ui/provisioning_editor.ui" line="351"/>
        <location filename="../apps/cmstapp/code/provisioning/ui/provisioning_editor.ui" line="354"/>
        <source>EAP-TLS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/ui/provisioning_editor.ui" line="359"/>
        <location filename="../apps/cmstapp/code/provisioning/ui/provisioning_editor.ui" line="362"/>
        <source>EAP-TTLS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/ui/provisioning_editor.ui" line="338"/>
        <source>IPv6.Privacy</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ProvisioningEditor</name>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="118"/>
        <source>Global</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="124"/>
        <source>Service</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="144"/>
        <source>WiFi</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="171"/>
        <source>Templates</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="205"/>
        <source>File Path to the CA Certificate File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="206"/>
        <source>File Path to the Client Certificate File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="207"/>
        <source>File path to the Client Private Key File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="212"/>
        <source>Key Files (*.pem);;All Files (*.*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="237"/>
        <source>MAC address.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="238"/>
        <source>SSID: hexadecimal representation of an 802.11 SSID</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="239"/>
        <source>List of Nameservers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="240"/>
        <source>List of Timeservers</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="241"/>
        <source>List of DNS Search Domains</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="242"/>
        <source>Domain name to be used</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="243"/>
        <source>Enter the string representation of an 802.11 SSID.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="244"/>
        <source>Substring to be matched against the subject of the authentication server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="245"/>
        <source>List of entries to be matched against the alternative subject name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="246"/>
        <source>A fully qualified domain name used as a full match requirement for the authentication server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="247"/>
        <source>A fully qualified domain name used as a suffix match requirement for the authentication server</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="282"/>
        <source>Service type.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="283"/>
        <source>EAP type.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="284"/>
        <source>Private key passphrase type.</source>
        <translation>개인키 암호문구 유형입니다.</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="285"/>
        <source>Network security type.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="286"/>
        <source>Hidden network</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="287"/>
        <source>IPv6 Privacy</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="288"/>
        <source>IPv4 Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="289"/>
        <source>IPv6 Settings</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="294"/>
        <source>%1 - Item Input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="325"/>
        <source>Tag which will replace the * with&lt;br&gt;an identifier unique to the config file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="326"/>
        <source>Enter the network name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="327"/>
        <source>Enter a description of the network.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="328"/>
        <source>Password/Passphrase for the private key file.</source>
        <translation>개인 키 파일에 대한 암호/암호문구 입니다.</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="329"/>
        <source>Identity string for EAP.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="331"/>
        <source>RSN/WPA/WPA2 Passphrase</source>
        <translation>RSN/WPA/WPA2 암호문구</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="332"/>
        <source>Phase 2 (inner authentication with TLS tunnel)&lt;br&gt;authentication method.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="345"/>
        <source>%1 - Text Input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="368"/>
        <source>IPv4 Address. &lt;br&gt;&lt;br&gt;Enter the IPv4 network address in the form xxx.xxx.xxx.xxx</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="373"/>
        <source>IPv4 Netmask. &lt;br&gt;&lt;br&gt;The entry can be a mask length (example 24) or in the form xxx:xxx:xxx:xxx</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="414"/>
        <source>IPv6 Gateway .&lt;br&gt;&lt;br&gt;This is an optional entry, press cancel if there is no entry for gateway</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="511"/>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="550"/>
        <source> Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="378"/>
        <source>IPv4 Gateway.&lt;br&gt;&lt;br&gt;This is an optional entry, press cancel if there is no entry for gateway</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="659"/>
        <source> Critical</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="402"/>
        <source>IPv6 Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="290"/>
        <source>Enable mDNS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="330"/>
        <source>Anonymous identity string for EAP.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="333"/>
        <source>The interface name in which to apply the provisioning (ex. eth0)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="407"/>
        <source>%1 - Integer Input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="408"/>
        <source>Enter the IPv6 prefix length</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="512"/>
        <source>&lt;center&gt;No configuration files were found.&lt;br&gt;You may use this dialog to create one.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="518"/>
        <source>%1 - Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="519"/>
        <source>&lt;center&gt;Reading configuration file: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="526"/>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="557"/>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="578"/>
        <source>%1 - Select File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="527"/>
        <source>Select a file to load.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="551"/>
        <source>&lt;center&gt;No configuration files were found.&lt;br&gt;Nothing will be deleted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="558"/>
        <source>Select a file to be deleted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="579"/>
        <source>Enter a new file name or select&lt;br&gt;an existing file to overwrite.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="614"/>
        <source>File read completed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="626"/>
        <source>File deleted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="628"/>
        <source>Error encountered deleting.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="642"/>
        <source>File save failed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="645"/>
        <source>%L1 KB written</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="647"/>
        <source>%L1 Bytes written</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/provisioning/prov_ed.cpp" line="660"/>
        <source>&lt;b&gt;DBus Error Name:&lt;/b&gt; %1&lt;br&gt;&lt;br&gt;&lt;b&gt;String:&lt;/b&gt; %2&lt;br&gt;&lt;br&gt;&lt;b&gt;Message:&lt;/b&gt; %3</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>ScrollBox</name>
    <message>
        <location filename="../apps/cmstapp/code/scrollbox/ui/scrollbox.ui" line="14"/>
        <source>Scrollbox</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/scrollbox/ui/scrollbox.ui" line="38"/>
        <source>TextLabel</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>TranslateStrings</name>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="43"/>
        <source>connman system tray</source>
        <comment>Main Window Title</comment>
        <translation>connman 시스템 트레이</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="44"/>
        <source>cmst</source>
        <comment>Abbreviated Program Name - used for QMessageBox titles</comment>
        <translation>cmst</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="47"/>
        <source>idle</source>
        <comment>connman state string</comment>
        <translation>idle</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="48"/>
        <source>association</source>
        <comment>connman state string</comment>
        <translation>연결</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="49"/>
        <source>configuration</source>
        <comment>connman state string</comment>
        <translation>구성</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="50"/>
        <source>ready</source>
        <comment>connman state string</comment>
        <translation>준비됨</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="51"/>
        <source>online</source>
        <comment>connman state string</comment>
        <translation>온라인</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="52"/>
        <source>disconnect</source>
        <comment>connman state string</comment>
        <translation>연결끊기</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="53"/>
        <source>failure</source>
        <comment>connman state string</comment>
        <translation>실패</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="54"/>
        <source>offline</source>
        <comment>connman state string</comment>
        <translation>오프라인</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="56"/>
        <source>system</source>
        <comment>connman type string</comment>
        <translation>시스템</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="57"/>
        <source>ethernet</source>
        <comment>connman type string</comment>
        <translation>이더넷</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="58"/>
        <source>wifi</source>
        <comment>connman type string</comment>
        <translation>와이파이</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="59"/>
        <source>bluetooth</source>
        <comment>connman type string</comment>
        <translation>블루투스</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="60"/>
        <source>cellular</source>
        <comment>connman type string</comment>
        <translation>휴대전화</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="61"/>
        <source>gps</source>
        <comment>connman type string</comment>
        <translation>gps</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="62"/>
        <source>vpn</source>
        <comment>connman type string</comment>
        <translation>vpn</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="63"/>
        <source>gadget</source>
        <comment>connman type string</comment>
        <translation>가젯</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="64"/>
        <source>p2p</source>
        <comment>connman type string</comment>
        <translation>p2p</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="65"/>
        <source>wired</source>
        <comment>connman type string</comment>
        <translation>유선</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="67"/>
        <source>direct</source>
        <comment>connman proxy string</comment>
        <translation>직통</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="68"/>
        <source>manual</source>
        <comment>connman proxy string</comment>
        <translation>수동</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="69"/>
        <source>auto</source>
        <comment>connman proxy string</comment>
        <translation>자동</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="71"/>
        <source>psk</source>
        <comment>connman security string</comment>
        <translation>PSK</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="72"/>
        <source>ieee8021x</source>
        <comment>connman security string</comment>
        <translation>ieee8021x</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="73"/>
        <source>none</source>
        <comment>connman security string</comment>
        <translation>없음</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="74"/>
        <source>wep</source>
        <comment>connman security string</comment>
        <translation>WEP</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="75"/>
        <source>wps</source>
        <comment>connman security string</comment>
        <translation>WPS</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="76"/>
        <source>wps_advertising</source>
        <comment>connman security string</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="78"/>
        <source>Invalid arguments</source>
        <comment>connman error string</comment>
        <translation>잘못된 인수</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="79"/>
        <source>Permission denied</source>
        <comment>connman error string</comment>
        <translation>권한이 거부되었습니다</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="80"/>
        <source>Passphrase required</source>
        <comment>connman error string</comment>
        <translation>암호문구가 필요합니다</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="81"/>
        <source>Not registered</source>
        <comment>connman error string</comment>
        <translation>미등록</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="82"/>
        <source>Not unique</source>
        <comment>connman error string</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="83"/>
        <source>Not supported</source>
        <comment>connman error string</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="84"/>
        <source>Not implemented</source>
        <comment>connman error string</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="85"/>
        <source>Not found</source>
        <comment>connman error string</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="86"/>
        <source>No carrier</source>
        <comment>connman error string</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="87"/>
        <source>In progress</source>
        <comment>connman error string</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="88"/>
        <source>Already exists</source>
        <comment>connman error string</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="89"/>
        <source>Already enabled</source>
        <comment>connman error string</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="90"/>
        <source>Already disabled</source>
        <comment>connman error string</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="91"/>
        <source>Already connected</source>
        <comment>connman error string</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="92"/>
        <source>Not connected</source>
        <comment>connman error string</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="93"/>
        <source>Operation aborted</source>
        <comment>connman error string</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="94"/>
        <source>Operation timeout</source>
        <comment>connman error string</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="95"/>
        <source>Invalid service</source>
        <comment>connman error string</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="96"/>
        <source>Invalid property</source>
        <comment>connman error string</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="98"/>
        <source>disabled</source>
        <comment>connman privacy string</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="99"/>
        <source>enabled</source>
        <comment>connman privacy string</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="100"/>
        <source>prefered</source>
        <comment>connman privacy string - known misspelling but needed to avoid breaking code</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="101"/>
        <source>preferred</source>
        <comment>connman privacy string</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="103"/>
        <source>auto</source>
        <comment>connman ethernet connection method</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="104"/>
        <source>manual</source>
        <comment>connman ethernet connection method</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="106"/>
        <source>dhcp</source>
        <comment>connman ipv4 method string</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="107"/>
        <source>manual</source>
        <comment>connman ipv4 method string</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="108"/>
        <source>off</source>
        <comment>connman ipv4 method string</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="109"/>
        <source>fixed</source>
        <comment>connman ipv4 method string</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="110"/>
        <source>address</source>
        <comment>connamn ipv4 method string</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="112"/>
        <source>auto</source>
        <comment>connman ipv6 method string</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="113"/>
        <source>manual</source>
        <comment>connman ipv6 method string</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="114"/>
        <source>6to4</source>
        <comment>connman ipv6 method string</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="115"/>
        <source>off</source>
        <comment>connman ipv6 method string</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="117"/>
        <source>openconnect</source>
        <comment>connman vpn connection type</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="118"/>
        <source>openvpn</source>
        <comment>connman vpn connection type</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="119"/>
        <source>vpnc</source>
        <comment>connman vpn connection type</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="120"/>
        <source>l2tp</source>
        <comment>connman vpn connection type</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="121"/>
        <source>pptp</source>
        <comment>connman vpn connection type</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="122"/>
        <source>wireguard</source>
        <comment>connman vpn connection type</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="124"/>
        <source>true</source>
        <comment>connman mdns setting</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/trstring/tr_strings.cpp" line="125"/>
        <source>false</source>
        <comment>connman mdns setting</comment>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <source>auto</source>
        <comment>connamn ipv6 method string</comment>
        <translation type="vanished">Auto</translation>
    </message>
    <message>
        <source>manual</source>
        <comment>connamn ipv6 method string</comment>
        <translation type="vanished">Manual</translation>
    </message>
    <message>
        <source>off</source>
        <comment>connamn ipv6 method string</comment>
        <translation type="vanished">Off</translation>
    </message>
</context>
<context>
    <name>VPNAgent</name>
    <message>
        <location filename="../apps/cmstapp/code/vpn_agent/ui/vpnagent.ui" line="14"/>
        <source>VPN Agent Input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_agent/ui/vpnagent.ui" line="20"/>
        <source>Username</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_agent/ui/vpnagent.ui" line="30"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;WISPr username.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_agent/ui/vpnagent.ui" line="40"/>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_agent/ui/vpnagent.ui" line="50"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;WISPr password.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_agent/ui/vpnagent.ui" line="60"/>
        <source>Host</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_agent/ui/vpnagent.ui" line="74"/>
        <source>Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_agent/ui/vpnagent.ui" line="88"/>
        <source>OpenConnect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_agent/ui/vpnagent.ui" line="94"/>
        <source>CA Cert.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_agent/ui/vpnagent.ui" line="108"/>
        <source>Client Cert.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_agent/ui/vpnagent.ui" line="118"/>
        <source>Cookie</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_agent/ui/vpnagent.ui" line="128"/>
        <source>Server Cert.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_agent/ui/vpnagent.ui" line="142"/>
        <source>VPN Host</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_agent/ui/vpnagent.ui" line="157"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;What&apos;s This&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_agent/ui/vpnagent.ui" line="160"/>
        <source>...</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_agent/ui/vpnagent.ui" line="184"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Continue the connection process.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_agent/ui/vpnagent.ui" line="187"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Accept and use the answers you have provided in this dialog. &lt;/p&gt;&lt;p&gt;This will send your input to the connman daemon to continue the connection process.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_agent/ui/vpnagent.ui" line="190"/>
        <source>O&amp;K</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_agent/ui/vpnagent.ui" line="197"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Cancel the connection process.&lt;br/&gt;&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_agent/ui/vpnagent.ui" line="200"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Cancel the dialog. &lt;/p&gt;&lt;p&gt;This will send a message to the connman daemon that you have cancelled the connection request.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_agent/ui/vpnagent.ui" line="203"/>
        <source>&amp;Cancel</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_agent/ui/vpnagent.ui" line="225"/>
        <source>Save Credentials</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VPN_Editor</name>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/vpn_ed.cpp" line="206"/>
        <source>Global</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/vpn_ed.cpp" line="212"/>
        <source>OpenConnect</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/vpn_ed.cpp" line="235"/>
        <source>OpenVPN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/vpn_ed.cpp" line="262"/>
        <source>VPNC</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/vpn_ed.cpp" line="289"/>
        <source>L2TP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/vpn_ed.cpp" line="341"/>
        <source>PPTP</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/vpn_ed.cpp" line="411"/>
        <source>All Files (*.*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/vpn_ed.cpp" line="424"/>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/vpn_ed.cpp" line="425"/>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/vpn_ed.cpp" line="426"/>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/vpn_ed.cpp" line="427"/>
        <source>Cert Files (*.pem *.ca *.crt *.cert);;All Files (*.*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/vpn_ed.cpp" line="415"/>
        <source>User:Pass Files (*.up *.txt *.conf);;All Files (*.*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/vpn_ed.cpp" line="366"/>
        <source>WireGuard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/vpn_ed.cpp" line="418"/>
        <source>CA Files (*.ca *.cert *.crt *.pem);;All Files (*.*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/vpn_ed.cpp" line="419"/>
        <source>Cert Files (*.ca *.cert *.crt *.pem);;All Files (*.*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/vpn_ed.cpp" line="420"/>
        <source>Key Files (*.key *.ca *.cert *.crt *.pem);;All Files (*.*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/vpn_ed.cpp" line="421"/>
        <source>Config Files (*.ovpn *.conf *.config);;All Files (*.*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/vpn_ed.cpp" line="456"/>
        <source>VPN server IP address (ex: 1.2.3.4)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/vpn_ed.cpp" line="536"/>
        <source>%1 - Item Input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/vpn_ed.cpp" line="554"/>
        <source>%1 - Verify Option</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/vpn_ed.cpp" line="574"/>
        <source>User defined name for the VPN</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/vpn_ed.cpp" line="575"/>
        <source>Domain name for the VPN Service
(ex: corporate.com)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/vpn_ed.cpp" line="576"/>
        <source>Networks behind the VPN link, if more than one separate by a comma.
Format is network/netmask/gateway, and gateway can be omitted.
Ex: 10.10.20.0/255.255.255.0/10.20.1.5,192.168.99.1/24,2001:Ldb8::1/16

Networks = entry is optional and may be left blank.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/vpn_ed.cpp" line="580"/>
        <source>Network address in the form address/netmask/peer.
Ex: 10.2.0.2/24</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/vpn_ed.cpp" line="595"/>
        <source>%1 - Text Input</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/vpn_ed.cpp" line="663"/>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/vpn_ed.cpp" line="703"/>
        <source> Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/vpn_ed.cpp" line="664"/>
        <source>&lt;center&gt;No configuration files were found.&lt;br&gt;You may use this dialog to create one.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/vpn_ed.cpp" line="670"/>
        <source>%1 - Information</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/vpn_ed.cpp" line="671"/>
        <source>&lt;center&gt;Reading configuration file: %1</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/vpn_ed.cpp" line="678"/>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/vpn_ed.cpp" line="710"/>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/vpn_ed.cpp" line="731"/>
        <source>%1 - Select File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/vpn_ed.cpp" line="679"/>
        <source>Select a file to load.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/vpn_ed.cpp" line="704"/>
        <source>&lt;center&gt;No configuration files were found.&lt;br&gt;Nothing will be deleted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/vpn_ed.cpp" line="711"/>
        <source>Select a file to be deleted.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/vpn_ed.cpp" line="732"/>
        <source>Enter a new file name or select&lt;br&gt;an existing file to overwrite.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/vpn_ed.cpp" line="767"/>
        <source>File read completed</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/vpn_ed.cpp" line="779"/>
        <source>File deleted</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/vpn_ed.cpp" line="781"/>
        <source>Error encountered deleting.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/vpn_ed.cpp" line="795"/>
        <source>File save failed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/vpn_ed.cpp" line="798"/>
        <source>%L1 KB written</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/vpn_ed.cpp" line="800"/>
        <source>%L1 Bytes written</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/vpn_ed.cpp" line="812"/>
        <source> Critical</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/vpn_ed.cpp" line="813"/>
        <source>&lt;b&gt;DBus Error Name:&lt;/b&gt; %1&lt;br&gt;&lt;br&gt;&lt;b&gt;String:&lt;/b&gt; %2&lt;br&gt;&lt;br&gt;&lt;b&gt;Message:&lt;/b&gt; %3</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/vpn_ed.cpp" line="851"/>
        <source>OpenVPN Configurations (*.ovpn  *.conf);;All Files (*.*)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/vpn_ed.cpp" line="860"/>
        <source>Select the configuration file to import</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/vpn_ed.cpp" line="882"/>
        <source>Keep --auth-user-pass</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/vpn_ed.cpp" line="883"/>
        <source>The conf file will contain the &lt;b&gt;auth-user-pass&lt;/b&gt; entry which will require prompts sent to stdout and a reply on stdin.  This cannot be handled by Connman nor by CMST.&lt;p&gt;If this entry is removed you will need to create a &quot;user:pass&quot; file in order to have Connman make the VPN connection. In the next step you will be asked if you want to create this file and you will prompted for the user name and password.&lt;p&gt;&lt;b&gt;Do you wish to remove this entry?&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/vpn_ed.cpp" line="909"/>
        <source>Unable to write conf file &lt;b&gt;%1&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/vpn_ed.cpp" line="921"/>
        <source>Create User:Password File</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/vpn_ed.cpp" line="922"/>
        <source>Do you wish to create a user:password file for this connection?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/vpn_ed.cpp" line="927"/>
        <source>User</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/vpn_ed.cpp" line="928"/>
        <source>Enter the user name for this connection.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/vpn_ed.cpp" line="933"/>
        <source>Password</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/vpn_ed.cpp" line="934"/>
        <source>Enter the password for this connection.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/vpn_ed.cpp" line="951"/>
        <source>Unable to write user:password file &lt;b&gt;%1&lt;/b&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/vpn_ed.cpp" line="961"/>
        <source>Unable to read &lt;b&gt;%1&lt;/b&gt; - Aborting the import</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/vpn_ed.cpp" line="969"/>
        <source>OpenVPN import is complete.  The provisioning file may now be saved.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>VPN_Prov</name>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="14"/>
        <source>VPN Provisioning Editor</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="23"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Text edit window.&lt;/p&gt;&lt;p&gt;You may type or cut and paste into this window. You may also use menus above to insert text fields.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="32"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Open an existing config file.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="35"/>
        <source>&amp;Open</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="48"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Write the displayed data to a config file.&lt;/p&gt;&lt;p&gt;The combo box is seeded with a list of CMST created config files to provide an easy way to overwrite one. You may also type a name in the ComboBox.&lt;/p&gt;&lt;p&gt;It is not necessary to provide a path nor a file extension as both will be stripped out and replaced allowed values. &lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="51"/>
        <source>&amp;Save</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="68"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Delete a config file.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="71"/>
        <source>&amp;Delete</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="94"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Clear all text from the editor window.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;편집기 창에서 모든 텍스트를 지웁니다.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="97"/>
        <source>&amp;Clear Page</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="111"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;What&apos;s This&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="114"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Enter &amp;quot;Whats This&amp;quot; mode.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="137"/>
        <source>&lt;html&gt;&lt;head/&gt;&lt;body&gt;&lt;p&gt;Exit the dialog.&lt;/p&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="140"/>
        <source>E&amp;xit</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="160"/>
        <source>Name of the network.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="168"/>
        <source>Description of the network.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="201"/>
        <source>PPTP User Name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="209"/>
        <source>PPTP Password.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="217"/>
        <source>Set the maximum number of LCP configure-NAKs returned
before starting to send configure-Rejects (default is 10).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="226"/>
        <source>Send an LCP echo-request frame to the peer every n seconds.
 This option can be used with the lcp-echo-failure option to detect
that the peer is no longer connected.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="236"/>
        <source>Debug level.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="244"/>
        <source>Deny EAP authorization?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="252"/>
        <source>Deny PAP authorization?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="260"/>
        <source>Deny CHAP authorization?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="268"/>
        <source>Deny MSCHAP authorization?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="276"/>
        <source>Deny MSCHAPV2 authorization?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="284"/>
        <source>Disables BSD compression?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="292"/>
        <source>Disable deflate compression?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="300"/>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="532"/>
        <source>Require the use of MPPE?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="308"/>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="540"/>
        <source>Require the use of MPPE 40 bit?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="316"/>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="548"/>
        <source>Require the use of MPPE 128 bit?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="324"/>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="556"/>
        <source>Allow MPPE to use stateful mode?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="332"/>
        <source>Disable Van Jacobson compression?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="340"/>
        <source>L2TP User Name.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="348"/>
        <source>L2TP Password.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="356"/>
        <source>Maximum bandwidth to use.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="364"/>
        <source>Maximum transmit bandwidth to use.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="372"/>
        <source>Maximum receive bandwidth to use.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="380"/>
        <source>Use length bit?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="388"/>
        <source>Use challenge authentication?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="396"/>
        <source>Add a default route to the system routing tables, using the peer as the gatewa?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="404"/>
        <source>Sequence numbers included in the communication?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="412"/>
        <source>The window size of the control channel (number of unacknowledged packets, not bytes)</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="420"/>
        <source>Use only one control channel?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="428"/>
        <source>Redial if disconnected?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="436"/>
        <source>Wait n seconds before redial.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="444"/>
        <source>Give up redial tries after X attempts.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="452"/>
        <source>Require the remote peer to get authenticated via PAP?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="460"/>
        <source>Require the remote peer to get authenticated via CHAP?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="468"/>
        <source>Require the remote peer to authenticate itself?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="476"/>
        <source>Only accept connections from specified peer addresses?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="484"/>
        <source>Authentication file location.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="492"/>
        <source>The IP address of the interface on which the daemon listens.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="500"/>
        <source>Use IPsec Security Association tracking?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="508"/>
        <source>Specify which UDP port should be used.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="516"/>
        <source>Disable protocol compression?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="524"/>
        <source>Disable address/control compression?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="564"/>
        <source>Your Group username.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="572"/>
        <source>Your group password (cleartext).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="580"/>
        <source>Your username.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="588"/>
        <source>Your password (cleartext).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="596"/>
        <source>IKE authentication mode.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="604"/>
        <source>Name of the IKE DH Group.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="620"/>
        <source>Domain name for authentication.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="628"/>
        <source>Vendor of your IPSec gateway.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="636"/>
        <source>Local ISAKMP port to use.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="644"/>
        <source>Local UDP port number to use.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="652"/>
        <source>Application version to report.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="660"/>
        <source>NAT-Traversal method to employ.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="668"/>
        <source>Send DPD packet after not receiving anything for n seconds</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="676"/>
        <source>Enable single DES encryption.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="684"/>
        <source>Enables using no encryption for data traffic.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="692"/>
        <source>Certificate authority file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="700"/>
        <source>File containing peer&apos;s signed certificate.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="708"/>
        <source>File containing local peer&apos;s private key.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="748"/>
        <source>File containing the user:password credentials.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="862"/>
        <source>Provider WireGuard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="865"/>
        <source>Provider Wire Guard</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="870"/>
        <source>VPNC.DeviceType</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="873"/>
        <source>Wheher the VPN should use tun or tap.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="878"/>
        <source>WireGuard.Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="881"/>
        <source>Internal IP Address</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="886"/>
        <source>WireGuard.ListPort</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="889"/>
        <source>Local listen port (optional).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="894"/>
        <source>WireGuard.DNS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="897"/>
        <source>List of name servers (optional).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="902"/>
        <source>WireGuard.PrivateKey</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="905"/>
        <source>Private key of the interface.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="910"/>
        <source>WireGuard.PublicKey</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="913"/>
        <source>Public key of peer.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="918"/>
        <source>WireGuard.PresharedKey</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="921"/>
        <source>Preshared key of peer (optional).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="926"/>
        <source>WireGuard.AllowedIPs</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="929"/>
        <source>See cryptokey routing.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="934"/>
        <source>WireGuard.EndpointPort</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="937"/>
        <source>Endpoint listen port (optional).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="942"/>
        <source>WireGuard.PersistentKeepalive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="945"/>
        <source>Keep alive in seconds (optional).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="950"/>
        <source>OpenVPN.DeviceType</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="953"/>
        <source>Whether the VPN should use tun or tap.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="958"/>
        <source>OpenConnect.AllowSelfSignedCert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="961"/>
        <source>Define if self signed server certificates are allowed.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="966"/>
        <source>OpenConnect.AuthType</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="969"/>
        <source>Type of authentication used.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="974"/>
        <source>OpenConnect.DisableIPv6</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="977"/>
        <source>Do not ask for IPv6 connectivity.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="982"/>
        <source>OpenConnect.NoDTLS</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="985"/>
        <source>Disable DTLS and ESP.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="990"/>
        <source>OpenConnect.NoHTTPKeepalive</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="993"/>
        <source>Disable HTTP connection re-use.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="998"/>
        <source>OpenConnect.PKCSClientCert</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="1001"/>
        <source>Certificate and privatekey in a PKCS#1/PKCS#8/PKCS#12 structure.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="1006"/>
        <source>OpenConnect.Usergroup</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="1009"/>
        <source>Set login usergroup on remote server.</source>
        <translation>원격 서버에 로그인 사용자 그룹을 설정합니다.</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="1014"/>
        <source>OpenConnect.UserPrivateKey</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="1017"/>
        <source>SSL private key file needed by web authentication.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="716"/>
        <source>MTU of the tunnel.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="612"/>
        <source>DH group to use for perfect forward secrecy. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="724"/>
        <source>Peer certificate type (server/client).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="732"/>
        <source>Protocol type (udp/tcp-client/tcp-server).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="740"/>
        <source>TCP/UDP port number.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="756"/>
        <source>Get certificate password from console or file?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="764"/>
        <source>Don&apos;t cache --askpass or --auth-user-pass values?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="772"/>
        <source>Encrypt packets with cipher algorithm:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="780"/>
        <source>Authenticate packets using algorithm:</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="788"/>
        <source>Use fast LZO compression (yes/no/adaptive).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="796"/>
        <source>Require peer certificate signed (client/server).</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="804"/>
        <source>OpenVPN config file that can contain extra options.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="812"/>
        <source>SHA1 certificate fingerprint of the final VPN server.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="820"/>
        <source>File containing other certificate authorities.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="828"/>
        <source>Client certificate file, if needed for web authentication. </source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="836"/>
        <source>Request MTU from server to use as MTU of tunnel?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="844"/>
        <source>Read cookie from standard input?</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/vpn_prov_ed/ui/vpn_prov_editor.ui" line="852"/>
        <source>The final VPN server to use after completing web authentication.</source>
        <translation type="unfinished"></translation>
    </message>
</context>
<context>
    <name>main.cpp</name>
    <message>
        <location filename="../apps/cmstapp/code/main.cpp" line="76"/>
        <source>Another running instance of CMST has been detected.  This instance is aborting</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/main.cpp" line="85"/>
        <source>Bypass restoring the window state if restoring window state is specified in the settings file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/main.cpp" line="89"/>
        <source>Bypass restoring any start options in the settings file.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/main.cpp" line="97"/>
        <source>Disable the system tray icon.  May be needed for system trays not compliant with the Freedesktop.org system tray specification.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/main.cpp" line="82"/>
        <source>Connman System Tray.</source>
        <translation>Connman 시스템 트레이입니다.</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/main.cpp" line="93"/>
        <source>[Experimental] Enable data counters.</source>
        <translation>[실험용] 데이터 카운터를 활성화합니다.</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/main.cpp" line="103"/>
        <source>Use an icon theme from your system.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/main.cpp" line="104"/>
        <source>Icon Theme Name</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/main.cpp" line="109"/>
        <source>Log the connman inputRequest for debugging purposes.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/main.cpp" line="113"/>
        <source>Start the GUI minimized in the system tray.</source>
        <translation>시스템 트레이에서 최소화한 GUI를 시작합니다.</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/main.cpp" line="117"/>
        <source>Disable the minimize button. Use when you want to have the window manager have sole control of minimizing the interface.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/main.cpp" line="121"/>
        <source>Disable VPN support.</source>
        <translation type="unfinished"></translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/main.cpp" line="127"/>
        <source>Specify the wait time in seconds before starting the system tray icon.</source>
        <translation>시스템 트레이 아이콘을 시작하기 전 대기 시간(초)을 지정합니다.</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/main.cpp" line="128"/>
        <location filename="../apps/cmstapp/code/main.cpp" line="140"/>
        <source>seconds</source>
        <translation>초</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/main.cpp" line="133"/>
        <source>[Experimental] The number of kb that have to be transmitted before the counter updates.</source>
        <translation>[실험용] 카운터가 업데이트되기 전에 전송해야 하는 KB 수입니다.</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/main.cpp" line="134"/>
        <source>KB</source>
        <translation>KB</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/main.cpp" line="139"/>
        <source>[Experimental] The interval in seconds between counter updates.</source>
        <translation>[실험용] 카운터 업데이트 사이의 간격(초)입니다.</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/main.cpp" line="146"/>
        <source>If tray icon fake transparency is required, specify the background color to use (format: 0xRRGGBB)</source>
        <translation>트레이 아이콘 가짜 투명도가 필요한 경우 사용할 배경색을 지정합니다 (형식: 0xRRGGBB)</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/main.cpp" line="147"/>
        <source>RRGGBB</source>
        <translation>RRGGBB</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/main.cpp" line="155"/>
        <source>Use XFCE specific code.</source>
        <translation>XFCE 고유 코드를 사용합니다.</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/main.cpp" line="160"/>
        <source>Use MATE DE specific code.</source>
        <translation>MATE DE 고유 코드를 사용합니다.</translation>
    </message>
</context>
<context>
    <name>processReply</name>
    <message>
        <location filename="../apps/cmstapp/code/shared/shared.cpp" line="44"/>
        <source> Warning</source>
        <translation> 경고</translation>
    </message>
    <message>
        <location filename="../apps/cmstapp/code/shared/shared.cpp" line="45"/>
        <source>&lt;center&gt;&lt;b&gt;We received a DBUS reply message indicating an error.&lt;/b&gt;&lt;/center&gt;&lt;br&gt;&lt;br&gt;Error Name: %1&lt;br&gt;&lt;br&gt;Error Message: %2</source>
        <translation>&lt;center&gt;&lt;b&gt;오류를 나타내는 DBUS 응답 메시지를 받았습니다.&lt;/b&gt;&lt;/center&gt;&lt;br&gt;&lt;br&gt;오류 이름: %1&lt;br&gt;&lt;br&gt;오류 메시지: %2</translation>
    </message>
</context>
</TS>
