# Changelog for xml-hamlet

## 0.5.0.2

* Compat with TH 2.18 [#172](https://github.com/snoyberg/xml/pull/172)

## 0.5.0.1

* Compat with GHC 8.8.1 [#147](https://github.com/snoyberg/xml/issues/147)

## 0.5.0

* Upgrade to conduit 1.3

## 0.4.1.1

* Remove an upper bound

## 0.4.1

Add various hamlet features to xml-hamlet [#91](https://github.com/snoyberg/xml/pull/91)
