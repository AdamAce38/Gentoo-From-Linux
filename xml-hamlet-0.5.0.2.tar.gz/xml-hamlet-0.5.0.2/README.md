## xml-hamlet

Hamlet for XML
