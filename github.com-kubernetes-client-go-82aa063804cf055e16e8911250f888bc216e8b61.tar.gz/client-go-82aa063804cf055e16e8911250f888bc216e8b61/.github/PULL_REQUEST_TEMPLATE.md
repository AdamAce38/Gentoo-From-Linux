Sorry, client-go does not accept changes via pull requests at this time. Please
submit your pull request to the main repository:
https://github.com/kubernetes/kubernetes.  See the guidance here:
https://github.com/kubernetes/client-go#contributing-code.
