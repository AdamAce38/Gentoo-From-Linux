let error_message =
  "the direct mode of cinaps is no longer supported. Please use the \"cinaps\" stanza in \
   your dune file instead."
;;
