* 0: OK
* 1: Generic error
* 10: Init failed because $GIT\_DIR exists
* 11: Could not enter $GIT\_WORK\_TREE
* 12: No repository found
* 13: Required directory exists but is not a directory
* 16: Potentially harmful operation aborted
* 17: Files that would be overwritten exist; fix manually

* 50: Could not create directory
* 51: Could not create file
* 52: Could not move directory
* 53: Could not move file
* 54: Directory exists
* 55: File exists
* 56: 
* 57: Could not write to file
* 57: Could not delete directory
* 59: Could not delete file
