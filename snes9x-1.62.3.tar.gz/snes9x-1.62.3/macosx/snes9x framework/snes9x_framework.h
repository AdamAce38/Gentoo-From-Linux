//
//  snes9x_framework.h
//  snes9x framework
//
//  Created by Buckley on 7/4/19.
//

#import <Cocoa/Cocoa.h>


//! Project version number for snes9x_framework.
FOUNDATION_EXPORT double snes9x_frameworkVersionNumber;

//! Project version string for snes9x_framework.
FOUNDATION_EXPORT const unsigned char snes9x_frameworkVersionString[];

#import <snes9x_framework/port.h>
#import <snes9x_framework/mac-os.h>
#import <snes9x_framework/mac-cheat.h>

