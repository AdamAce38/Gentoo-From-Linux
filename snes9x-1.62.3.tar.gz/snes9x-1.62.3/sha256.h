#ifndef __SHA256_H
#define __SHA256_H

void sha256sum (unsigned char *data, unsigned int length, unsigned char *hash);

#endif
