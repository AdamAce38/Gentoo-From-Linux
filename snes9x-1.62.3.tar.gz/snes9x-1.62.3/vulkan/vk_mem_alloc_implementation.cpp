#define VMA_IMPLEMENTATION
#include "vulkan_context.hpp"