#include "ucspi-proxy.h"

const char filter_usage[] = "search replace [search replace ...]";
const char program[] = "ucspi-proxy-http-xlate";
