#include "ucspi-proxy.h"

const char program[] = "ucspi-proxy-log";
const char filter_usage[] = "";
