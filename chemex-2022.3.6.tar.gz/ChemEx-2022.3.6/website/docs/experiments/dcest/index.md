---
sidebar_label: D-CEST/cos-CEST
sidebar_position: 2
description: D-CEST/cos-CEST experiments
---

# D-CEST/cos-CEST experiments

This section contains information about the D-CEST/cos-CEST experiments that are
available in ChemEx.

import DocCardList from '@theme/DocCardList';

import {useCurrentSidebarCategory} from '@docusaurus/theme-common';

<DocCardList items={useCurrentSidebarCategory().items}/>
