---
sidebar_label: Relaxation
sidebar_position: 4
description: Relaxation experiments
---

# CPMG relaxation dispersion experiments

This section contains information about the relaxation experiments that are
available in ChemEx.

import DocCardList from '@theme/DocCardList';

import {useCurrentSidebarCategory} from '@docusaurus/theme-common';

<DocCardList items={useCurrentSidebarCategory().items}/>
