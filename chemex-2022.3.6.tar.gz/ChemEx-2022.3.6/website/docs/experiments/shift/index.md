---
sidebar_label: Exchange-induced chemical shift experiments
sidebar_position: 5
description: Shift
---

# Exchange-induced chemical shift experiments

This section contains information about the exchange-induced chemical shift
experiments that are available in ChemEx.

import DocCardList from '@theme/DocCardList';

import {useCurrentSidebarCategory} from '@docusaurus/theme-common';

<DocCardList items={useCurrentSidebarCategory().items}/>
