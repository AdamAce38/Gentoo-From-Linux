---
sidebar_position: 3
---

# Experiments

This section contains information about the experiments that are available in
ChemEx.

import DocCardList from '@theme/DocCardList';

import {useCurrentSidebarCategory} from '@docusaurus/theme-common';

<DocCardList items={useCurrentSidebarCategory().items}/>
