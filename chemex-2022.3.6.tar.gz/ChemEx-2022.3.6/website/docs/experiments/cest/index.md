---
sidebar_label: CEST
sidebar_position: 1
description: CEST experiments
---

# CEST experiments

This section contains information about the CEST experiments that are available
in ChemEx.

import DocCardList from '@theme/DocCardList';

import {useCurrentSidebarCategory} from '@docusaurus/theme-common';

<DocCardList items={useCurrentSidebarCategory().items}/>
