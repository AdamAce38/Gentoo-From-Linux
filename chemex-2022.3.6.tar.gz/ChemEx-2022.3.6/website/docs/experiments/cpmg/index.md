---
sidebar_label: CPMG
sidebar_position: 3
description: CPMG relaxation dispersion experiments
---

# CPMG relaxation dispersion experiments

This section contains information about the relaxation dispersion CPMG
experiments that are available in ChemEx.

import DocCardList from '@theme/DocCardList';

import {useCurrentSidebarCategory} from '@docusaurus/theme-common';

<DocCardList items={useCurrentSidebarCategory().items}/>
