---
sidebar_position: 3
---

import DocCardList from '@theme/DocCardList';

import {useCurrentSidebarCategory} from '@docusaurus/theme-common';

# Fitting datasets

Let's learn about how to fit chemical exchange experimental datasets using
ChemEx.

<DocCardList items={useCurrentSidebarCategory().items}/>
