---
sidebar_position: 2
lastmod: 2022-04-19T20:13:05.299Z
---

import DocCardList from '@theme/DocCardList';

import {useCurrentSidebarCategory} from '@docusaurus/theme-common';

# User Guide

Let's learn about the most important features of ChemEx.

<DocCardList items={useCurrentSidebarCategory().items}/>
