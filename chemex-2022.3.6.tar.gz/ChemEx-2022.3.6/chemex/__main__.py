"""chemex.__main__: executed when the chemex directory is called as script."""
from __future__ import annotations

from chemex.chemex import main

if __name__ == "__main__":
    main()
