#!/bin/sh

chemex pick_cest -e Experiments/*.toml -o Sandbox
