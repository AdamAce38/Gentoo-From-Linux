Example of 3-state exchange, test with several different fitting options

run_FIFU.sh: with correct FIFU model, without DRD-CEST datasets

run_FIU.sh: with incorrect FIU model, without DRD-CEST datasets

run_FIFU_drd.sh: with correct FIFU model, with DRD-CEST datasets

run_FIU_drd.sh: with incorrect FIU model, with DRD-CEST datasets

Correct exchange model (i.e. FIFU model) can only be distinguished by including DRD-CEST datasets
