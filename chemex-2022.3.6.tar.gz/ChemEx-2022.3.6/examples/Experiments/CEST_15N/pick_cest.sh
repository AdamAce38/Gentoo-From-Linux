#!/bin/sh

chemex pick_cest -e Experiments/13hz.toml -o Sandbox
