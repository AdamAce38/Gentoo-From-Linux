int pledge(const char *, const char *);
