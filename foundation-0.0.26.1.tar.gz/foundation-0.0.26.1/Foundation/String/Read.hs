module Foundation.String.Read
    ( readInteger
    , readIntegral
    , readNatural
    , readDouble
    , readRational
    , readFloatingExact
    ) where

import Basement.String
