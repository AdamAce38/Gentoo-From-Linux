#ifndef __stupid_dirname_h__
#define __stupid_dirname_h__


#include <string>

namespace PBD {
	extern char *dirname (const char *);
	extern std::string dirname (const std::string);
}
#endif  // __stupid_dirname_h__
