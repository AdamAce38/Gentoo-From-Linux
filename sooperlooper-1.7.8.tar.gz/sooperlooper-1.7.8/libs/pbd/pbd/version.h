#ifndef __pbd_version_h__
#define __pbd_version_h__

extern int pbd_major_version;
extern int pbd_minor_version;
extern int pbd_micro_version;

#endif // __pbd_version_h__
