#ifndef __unescape_h__
#define __unescape_h__

void unescape (char *);

#endif // __unescape_h__
