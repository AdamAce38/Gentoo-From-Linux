#ifndef __midipp_version_h__
#define __midipp_version_h__

extern int midipp_major_version;
extern int midipp_minor_version;
extern int midipp_micro_version;

#endif // __midipp_version_h__
