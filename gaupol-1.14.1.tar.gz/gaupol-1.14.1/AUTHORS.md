Osmo Salomaa <otsaloma@iki.fi>
