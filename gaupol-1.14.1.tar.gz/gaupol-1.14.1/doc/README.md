Documentation
=============

## For Users

* [Creating Subtitles](creating-subtitles.md)

## For Developers

* [API documentation on the aeidon library](https://otsaloma.io/gaupol/doc/api/aeidon.html)
