iso-codes JSON files are written by various authors and are copied
unmodified from [iso-codes][1]. The files are released under the GNU
Lesser General Public License (LGPL).

[1]: https://salsa.debian.org/iso-codes-team/iso-codes
