***********
Basic Usage
***********

Installation
============
Install ``signature_dispatch`` using ``pip``::

    $ pip install signature_dispatch

- Requires python≥3.6
- Uses `semantic versioning`_.

.. _`semantic versioning`: https://semver.org/
