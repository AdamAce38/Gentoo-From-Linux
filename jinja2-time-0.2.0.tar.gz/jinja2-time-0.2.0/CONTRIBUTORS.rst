=======
Credits
=======

Development Lead
----------------

* Raphael Pierzina (`@hackebrot`_)

Pull Requests and Patches
-------------------------

* Juan Madurga (`@jlmadurga`_)

Bug Reports and Suggestions
---------------------------

None yet. Why not be the first?

.. _`@hackebrot`: https://github.com/hackebrot
.. _`@jlmadurga`: https://github.com/jlmadurga
