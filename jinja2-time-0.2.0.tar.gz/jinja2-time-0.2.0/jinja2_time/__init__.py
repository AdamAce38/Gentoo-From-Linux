# -*- coding: utf-8 -*-

from .jinja2_time import TimeExtension

__author__ = 'Raphael Pierzina'
__email__ = 'raphael@hackebrot.de'
__version__ = '0.2.0'


__all__ = ['TimeExtension']
