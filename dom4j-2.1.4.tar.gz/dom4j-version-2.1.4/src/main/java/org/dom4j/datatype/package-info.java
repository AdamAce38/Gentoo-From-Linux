/**
 * An implementation of the <i>dom4j</i> API which supports the <a href="http://www.w3.org/TR/xmlschema-2/">XML Schema Data Types</a> specification.
 */
package org.dom4j.datatype;