/**
 * Provides input and output via SAX and DOM together with writing <i>dom4j</i> objects to streams as XML text.
 */
package org.dom4j.io;