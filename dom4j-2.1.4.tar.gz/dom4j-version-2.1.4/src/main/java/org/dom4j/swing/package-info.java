/**
 * A collection of adapters to allow easy integration with dom4j XML documents and Swing such as TreeModels and TableModels.
 */
package org.dom4j.swing;