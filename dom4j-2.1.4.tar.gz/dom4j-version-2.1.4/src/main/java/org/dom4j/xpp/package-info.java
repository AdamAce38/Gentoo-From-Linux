/**
 * Provides implementation classes to cleanly integrate dom4j with the XML Pull Parser <a href="http://www.extreme.indiana.edu/soap/xpp/">XPP</a>.
 */
package org.dom4j.xpp;