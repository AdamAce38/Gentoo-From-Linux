package org.dom4j.dtd;

/**
 * Created by filip on 5.7.15.
 */
public interface Decl {
}
