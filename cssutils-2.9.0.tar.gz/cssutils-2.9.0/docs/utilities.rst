====================
utilities
====================
A few utility functions which may help when working with CSS stylesheets.



``getUrls``
-----------
.. autofunction:: cssutils.getUrls

``replaceUrls``
---------------
.. autofunction:: cssutils.replaceUrls

``resolveImports``
------------------
.. autofunction:: cssutils.resolveImports
