:tocdepth: 2

.. _changes:

History
*******

.. include:: ../NEWS (links).rst
