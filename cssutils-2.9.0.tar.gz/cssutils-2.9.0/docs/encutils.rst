========================
``encutils`` module
========================

.. automodule:: encutils
   :members:

