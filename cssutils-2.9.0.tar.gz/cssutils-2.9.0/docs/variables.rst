========================
CSS Variables
========================

See :class:`cssutils.serialize.Preferences` about a way to replace all variable references with their actual values while serializing. As CSSVariables are not implemented in any (?) browser or other user agent cssutils preprocesses these. So you are able to use variables in your stylesheets without having to worry about UA support.

TODO: example
