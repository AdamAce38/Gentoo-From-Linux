/*
 static char *sccsid = "@(#)build.h  (c) C. Jullien 2016/08/24";
 */

#if	!defined( __EMACS_BUILD_H )
#define	__EMACS_BUILD_H

/*
 *	build.h :
 */

#if	!defined( EMBUILD )
#define	EMBUILD		2436
#endif

#endif
