## 2024-01-11: V0.086

- Fuzion language

  - When redefining an inherited feature, it is now enforced that the visibility
    is not restricted ([#2233](https://github.com/tokiwa-software/fuzion/pull/2233)).

  - Syntax sugar for access to tuple elements now permits using
    `t.0/t.1/...` instead of `t.values.0/t.values.1/...:` One can now use

            t := (3,4)
            say (t.0 + t.1)

    instead of

            t := (3,4)
            say (t.values.0 + t.values.1)

    ([#2392](https://github.com/tokiwa-software/fuzion/pull/2392)).

  - Added support for partial application ([#2265](https://github.com/tokiwa-software/fuzion/pull/2265)). In particular, the following
    partial calls are supported now:

    | partial expression | expands to                    | explanation |
    | ------------------ | ----------                    | ----------- |
    | f x y              | a,b,c -> f x y a b c          | partial call turned into a lambda |
    | f x y              | () -> f x y                   | a call may be turned into a nullary function |
    | ++ x               | a -> a ++ x                   | A prefix or postfix operator may be turned into an infix operator |
    | x ++               | a -> x ++ a                   | dto. |
    | -                  | a -> -a<br>—or—<br>a,b -> a-b | A single operator may become a prefix, postfix, or infix operator in a lambda |
    | .as_string         | a -> a.as_string              | A dot followed by a call is a call in a lambda that receives its target as an argument |
    | -1                 | a -> a - 1                    | a numeric literal with a sign may become an infix operator |

    Note that a single operator given as an argument to a call will be parsed as a postfix or infix operator, so it usually will have to be enclosed in parentheses as in

            (-)

    The same holds for partial application of the target of a call using `.` as in

            (.as_string)

  - When redefining an inherited feature, it is now enforced that the visibility is not restricted ([#2233](https://github.com/tokiwa-software/fuzion/pull/2233)).


- base library

  - `io.buffered.read_string` now may return `io.end_of_file` ([#2227](https://github.com/tokiwa-software/fuzion/pull/2227)).

  - `ctrie` has been moved to the `lock_free` module ([#2238](https://github.com/tokiwa-software/fuzion/pull/2238)).

  - The monoids `all`, `any`, and `parity` have been added to `bool.type` ([#2287](https://github.com/tokiwa-software/fuzion/pull/2287)).

  - Many useful features have been made public:

    - ranges like `codepoint.ascii` [#2289](https://github.com/tokiwa-software/fuzion/pull/2289),
    - `bool.as_option` [#2309](https://github.com/tokiwa-software/fuzion/pull/2309),
    - `io.buffered.read_bytes` [#2332](https://github.com/tokiwa-software/fuzion/pull/2332),
    - function composition features like `atop`, `flip`, etc. defined in `composition` [#2342](https://github.com/tokiwa-software/fuzion/pull/2342),
    - `(has_interval.infix` ..).upper [#2384](https://github.com/tokiwa-software/fuzion/pull/2384),
    - `String.trim` [#2374](https://github.com/tokiwa-software/fuzion/pull/2374),
    - `length` and others in `java.Array` [#2395](https://github.com/tokiwa-software/fuzion/pull/2395).

  - `option` now inherits from `Sequence` ([#2291](https://github.com/tokiwa-software/fuzion/pull/2291)).

  - `time.durations.as_string` has a fixed width now such that nice looking timing tables are easier to create ([#2330](https://github.com/tokiwa-software/fuzion/pull/2330)).

  - A `stack` data type using local mutation is available now ([#2351](https://github.com/tokiwa-software/fuzion/pull/2351)).

  - `map` and `flat_map` are now features of Sequence that produce a new
    Sequence. Specific variants for array or list that produce an array or a
    list have been renamed as map_to_array and map_to_list, etc., resp. ([#2317](https://github.com/tokiwa-software/fuzion/pull/2317)).

  - `count` and `drop` were redefined for array backed sequences to achieve O(1) performance ([#2337](https://github.com/tokiwa-software/fuzion/pull/2337)).

  - `reverse`, `map_pairs`, `fold1`, and `foldf` were added to `Sequence` ([#2341](https://github.com/tokiwa-software/fuzion/pull/2341)).

  - Unused features were removed from `effects.fz` ([#2352](https://github.com/tokiwa-software/fuzion/pull/2352)).

  - For debugging of functions, a feature `log` was added which is like `say`, but instead of returning unit, it returns its argument ([#2297](https://github.com/tokiwa-software/fuzion/pull/2297)).

  - Output of `list.as_string` has been improved for empty entries ([#2314](https://github.com/tokiwa-software/fuzion/pull/2314)).

  - Performance improvements for `io.stdin` and `io.buffered.reader` ([#2343](https://github.com/tokiwa-software/fuzion/pull/2343)).

  - Pipe operators `|>`, `||>`, `|||>`, etc. have been added ([#2355](https://github.com/tokiwa-software/fuzion/pull/2355)), so you can now do things like

            (3,4) ||> (+) |> say

    which will first destructure the tuple into `3` and `4`, then apply `infix +` to add these and pass the result as an argument to `say`.

  - `memoize` is now public ([#2248](https://github.com/tokiwa-software/fuzion/pull/2248)).

  - New feature `Sequence.scan` to create lists of results of folding all prefixes of a `list` ([#2197](https://github.com/tokiwa-software/fuzion/pull/2197)). e.g.,

            [1,2,3,4,5].scan i32.type.sum

    results in

            [1,3,6,10,15]

  - `marray` has been replaced by `mutate.array` ([#1930](https://github.com/tokiwa-software/fuzion/pull/1930)).

  - A new module `lock_free.fum` was added with a lock-free `stack` implementation as a first entry ([#1917](https://github.com/tokiwa-software/fuzion/pull/1917)).


- Front end

  - `this.type` can now be used inside of the corresponding type feature ([#2296](https://github.com/tokiwa-software/fuzion/pull/2296)).

  - Support for partial application with type parameters has been implemented
    ([#2355](https://github.com/tokiwa-software/fuzion/pull/2355)). This was required, e.g., for the pipe operator to work with partial
    application as in

            "Hello> |> say.

  - Error output for this-types now uses `xyz.this` instead of `xyz.this.type` to match the current syntax ([#2356](https://github.com/tokiwa-software/fuzion/pull/2356)).

  - Fixed type inference for numeric literals wrapped in a `lazy` value ([#2363](https://github.com/tokiwa-software/fuzion/pull/2363)).

  - Fixed false detection of ambiguous code due to partial applications ([#2298](https://github.com/tokiwa-software/fuzion/pull/2298)).

  - Improved type inference for function argument types ([#2316](https://github.com/tokiwa-software/fuzion/pull/2316)).

  -  Mark result clazz of intrinsic constructor as instantiated, this paves part of the way for `fzjava` integration with the JVM backend ([#2394](https://github.com/tokiwa-software/fuzion/pull/2394)).

  - A contract whose result type is not bool now results in an error ([#2268](https://github.com/tokiwa-software/fuzion/pull/2268)).

  - Type inference from anonymous feature now results in the base type if that is a ref type, which is typically the desired type ([#2254](https://github.com/tokiwa-software/fuzion/pull/2254)).

  - Added concept of effective visibility which is the combination of the outer
    feature's visibility and its own visibility.  Visibility checks now use
    effective visibility when verifying argument and result type
    visibility. ([#2246](https://github.com/tokiwa-software/fuzion/pull/2246)).

  - Fixed feature lookup for features added in modules ([#2245](https://github.com/tokiwa-software/fuzion/pull/2245)).


- Middle end

  - Reduce recursion depth of `CFG` and `DFA` to improve performance and avoid stack overflows ([#2338](https://github.com/tokiwa-software/fuzion/pull/2338)).

  - Fixed null-pointer exceptions and check-condition failures ([#2357](https://github.com/tokiwa-software/fuzion/pull/2357)).

  - Fixed crashes when empty block is used to return a unit type result that is a tagged element in a choice ([#2267](https://github.com/tokiwa-software/fuzion/pull/2267)).

  - Fixed inheritance of types for the case of a type parameter that is replaced
    by an actual type twice: via the inheritance change and in an outer feature
    ([#2243](https://github.com/tokiwa-software/fuzion/pull/2243)).

  - Support for calls as compile-time constants ([#2067](https://github.com/tokiwa-software/fuzion/pull/2067)).


- JVM back end

  - JVM backend runtime now has its own version of `OpenResource.java` for resource handling ([#2256](https://github.com/tokiwa-software/fuzion/pull/2256)).

  - Reduced code size by joining precondition and routine body into one Java method ([#2196](https://github.com/tokiwa-software/fuzion/pull/2196)).

  - Internal improvements: Added null type ([#2089](https://github.com/tokiwa-software/fuzion/pull/2089)).

  - Code is no longer run in the main thread, but all code is run in an instance of `FuzionThread` ([#2177](https://github.com/tokiwa-software/fuzion/pull/2177)).


- C back end

  - Enable `-fno-omit-frame-pointer` by default to enhance debugging ([#2373](https://github.com/tokiwa-software/fuzion/pull/2373)).

  - Fixed an old and tough bug where a value result from a dynamically bound call could result in a dangling reference on the C stack ([#2260](https://github.com/tokiwa-software/fuzion/pull/2260)).

  - Now uses C's compound literals to create Fuzion's String constants ([#2225](https://github.com/tokiwa-software/fuzion/pull/2225)).


## 2023-10-31: V0.085

- Fuzion language

  - The syntax for a routine with an explicit result type now uses `=>`
    [#2037](https://github.com/tokiwa-software/fuzion/pull/2037) as in

            the_answer u8 => 42

- Front end

  - An error is now produced if actual type parameters do not meet the
    constraints given for the formal type parameter
    [#1054](https://github.com/tokiwa-software/fuzion/issues/1054),
    [#1818](https://github.com/tokiwa-software/fuzion/pull/1818).

  - Improved type inference for empty arrays
    [#1899](https://github.com/tokiwa-software/fuzion/issues/1899),
    [#2124](https://github.com/tokiwa-software/fuzion/pull/2124)) enabling code
    like the following:

            a =>
              if true
                []
              else
                [3]

- JVM back end

  - Added support for `concur.spawn`
    [#2038](https://github.com/tokiwa-software/fuzion/pull/2038)
        and `concur.atomic`
        [#2036](https://github.com/tokiwa-software/fuzion/pull/2036).

  - Improved stack trace printing in case of precondition failure
    [#2049](https://github.com/tokiwa-software/fuzion/pull/2049).

  - Improved stack overflow handling, now shows Fuzion stack trace
     [#2060](https://github.com/tokiwa-software/fuzion/pull/2060).

  - Added support for tail recursion optimization
    [#2051](https://github.com/tokiwa-software/fuzion/pull/2051).

  - Added checks to avoid accidental modification of immutable arrays by
    intrinsic functions
    [#2099](https://github.com/tokiwa-software/fuzion/pull/2099).

  - Added support for memory mapping of files
    [#2126](https://github.com/tokiwa-software/fuzion/pull/2126).

  - The JVM backend is now enabled when running the tests, a build fails
    if the JVM backend fails to run the tests
    [#2149](https://github.com/tokiwa-software/fuzion/pull/2149).

- C back end

  - Improved support for `concur.atomic` to support compare-and-swap for choice
    and value types and avoid accessing uninitialized memory
    [#2123](https://github.com/tokiwa-software/fuzion/pull/2123).

- base library

  - A set of features for function composition was added which is a start
    towards providing a framework for function composition
    [#2046](https://github.com/tokiwa-software/fuzion/issues/2046),
    [#2047](https://github.com/tokiwa-software/fuzion/pull/2047).

  - Added `io.buffered.reader` effect
    [#1554](https://github.com/tokiwa-software/fuzion/pull/1554).

  - The base library type `void` is now implemented as an empty choice type
    [#1962](https://github.com/tokiwa-software/fuzion/pull/1962).  Also added
    default identity features `id` with one argument, that is return, and with
    no argument, that returns a unary identity function.

  - Several visibility fixes
    [#2157](https://github.com/tokiwa-software/fuzion/pull/2157),
    [#2152](https://github.com/tokiwa-software/fuzion/pull/2152).


## 2023-08-08: V0.084

- Fuzion language

  - Preparational improvements and changes with respect to
    visibility (see:
    [#1690](https://github.com/tokiwa-software/fuzion/pull/1690),
    [#1691](https://github.com/tokiwa-software/fuzion/pull/1691),
    [#1695](https://github.com/tokiwa-software/fuzion/pull/1695),
    [#1714](https://github.com/tokiwa-software/fuzion/pull/1714),
    [#1731](https://github.com/tokiwa-software/fuzion/pull/1731),
    [#1734](https://github.com/tokiwa-software/fuzion/pull/1734),
    [#1736](https://github.com/tokiwa-software/fuzion/pull/1736),
    [#1744](https://github.com/tokiwa-software/fuzion/pull/1744))
    have resulted in visibility finally being enforced by the
    Fuzion compiler:
    [#1745](https://github.com/tokiwa-software/fuzion/pull/1745).

  - Type inference for arguments from actuals in a call:
    [#1722](https://github.com/tokiwa-software/fuzion/pull/1722).
    In a declaration like

            point(x, y i32) is


    The argument type `i32` can be omitted if there are calls to
    that feature:

            point(x, y) is

            p1 := point 3 4
            p2 := point 5 12


  - Support for *free types*
    [#1774](https://github.com/tokiwa-software/fuzion/pull/1722)
    to simplify declarations using type parameters. It is now
    possible to write

            first (s Sequence T) => s.nth 0


    instead of

            first (T type, s Sequence T) => s.nth 0


    Free types can be anonymous using `_`:

            first (s Sequence _) => s.nth 0


    one can also use constraints as in

            add_to_all (s array N:numeric, v N) => s.map x->x+v

            say (add_to_all [1, 2, 3] 10)


    or complex type expressions like

            g(v A | (B : numeric)) => ...


  - Explicit `ref` types have been removed:
    [#1705](https://github.com/tokiwa-software/fuzion/pull/1705).
    If a `ref` type variant is required, one must now declare a
    `ref` feature and inherit from this.

  - The type of an outer instance `a` is now just `a.this`, it used
    to be `a.this.type`:
    [#1706](https://github.com/tokiwa-software/fuzion/pull/1706).
    This is consistent with, e.g., `nil` being \--depending on
    context\-- either a type or a call resulting in a value.

  - The `set` keyword to assign a new value to a field is no longer
    permitted:
    [#1720](https://github.com/tokiwa-software/fuzion/pull/1720).

    As an alternative, use the `mutate` effect in your code.

- front end

  - Improve support for lazy values:
    [#1667](https://github.com/tokiwa-software/fuzion/pull/1667),
    [#1672](https://github.com/tokiwa-software/fuzion/pull/1672).

  - Fix a bug which caused unjustified errors when chained booleans
    were used in postconditions:
    [#1685](https://github.com/tokiwa-software/fuzion/pull/1685).

  - The parser and frontend now keep more accurate position
    information for names, in particular in feature declarations:
    [#1735](https://github.com/tokiwa-software/fuzion/pull/1735).

    This improves confusing error messages when multiple feature
    names are given in a declaration. Furthermore, source ranges are
    now supported such that the entire name is now marked in error
    messages.

  - Improve some error messages:
    [#1693](https://github.com/tokiwa-software/fuzion/pull/1693),
    [#1753](https://github.com/tokiwa-software/fuzion/pull/1753).

  - fix check failure in case `x` is not found in `x.this.type`
    [#1718](https://github.com/tokiwa-software/fuzion/pull/1718).

  - permit all calls with `void` as the target type
    [#1725](https://github.com/tokiwa-software/fuzion/pull/1725).

  - fix an issue where in some cases an unjustified "Choice feature
    must not contain any code" error would appear:
    [#1740](https://github.com/tokiwa-software/fuzion/pull/1740).

  - fix contract violations of lineStartPos, for files with errors on
    last line:
    [#1743](https://github.com/tokiwa-software/fuzion/pull/1743).

  - fix NullPointerException when building a bad `base.fum`:
    [#1767](https://github.com/tokiwa-software/fuzion/pull/1767).

  - harmonize indentation handling of `is`, `=>`, `:=`, and `.`:
    [#1768](https://github.com/tokiwa-software/fuzion/pull/1768).

  - flag error when assigning choice element to this type of
    type feature
    [#1793](https://github.com/tokiwa-software/fuzion/pull/1793).

  - ast: handle boxing of erroneous and empty values gracefully
    [#1795](https://github.com/tokiwa-software/fuzion/pull/1795).

  - parser: allow closing brace of formal args list at min indent:
    [#1803](https://github.com/tokiwa-software/fuzion/pull/1803).

  - check that primitives do not contain fields:
    [#1808](https://github.com/tokiwa-software/fuzion/pull/1808).

  - ast: use `Expr` instead of `Stmnt`:
    [#1812](https://github.com/tokiwa-software/fuzion/pull/1812).

  - improve backward type propagation for arrays:
    [#1814](https://github.com/tokiwa-software/fuzion/pull/1814).

    This means that the empty array can now be assigned to fields
    of explicit type `array T`, and its type will be determined
    correctly.

- back end

  - Add intrinsics to get a network socket\'s peer\'s address and
    port information:
    [#1712](https://github.com/tokiwa-software/fuzion/pull/1712).

    This is useful when writing server applications using Fuzion,
    for example to implement IP based access control.

- C back end

  - If the environment variable `FUZION_DEBUG_TAIL_CALL` is set to
    `true`, `fz` will print debug information about tail call
    optimization:
    [#1687](https://github.com/tokiwa-software/fuzion/pull/1687).

  - In the intrinsics for atomic values, use atomic compare and swap
    operations when possible, instead of emulating this using a
    global lock:
    [#1689](https://github.com/tokiwa-software/fuzion/pull/1689).

  - C FFI: `native` features have been implemented, which in the C
    backend, allow C functions to be called:
    [#1772](https://github.com/tokiwa-software/fuzion/pull/1772).

    To work with this, the C functions need to be reasonable simple,
    that is their arguments and return value must be integers,
    floating point numbers, or Strings. Additionally, Fuzion will
    not automatically take care of including the right headers and
    passing the proper arguments to the compiler and linker.

    `native` features are not supported in the interpreter.

- base library

  - The features `equatable`, `orderable`, `partially_orderable`
    have been renamed and moved into the grouping feature
    `property`:
    [#1466](https://github.com/tokiwa-software/fuzion/pull/1466).

  - The `CTrie` data structure now uses atomic compare and swap
    operations, in an attempt at making it actually thread-safe and
    lock-free:
    [#1598](https://github.com/tokiwa-software/fuzion/pull/1598).
    There are however still remaining issues related to taking
    snapshots in a multi-threaded environment.

  - Fuzion now supports IEEE floating point comparisons:
    [#1644](https://github.com/tokiwa-software/fuzion/pull/1644).
    In particular, comparing against `NaN` always results in
    `false`. IEEE semantics for floating point comparison are used
    for infix operations `=` or `<=`, etc.

    In contrast, `type.equality` and `type.lteq` for floats define
    an equality relation and a total order in a mathematical sense.
    These will be used in type parametric code requiring `equatable`
    or `orderable` and they can be used directly via
    `equals f64 a b` or `lteq f64 a b` defined in the base library.

  - Add a `join` operation to the `concur.threads` effect:
    [#1651](https://github.com/tokiwa-software/fuzion/pull/1651).

    This allows waiting for the end of threads in another thread.

  - Parameterize the `try` effect
    [#1696](https://github.com/tokiwa-software/fuzion/pull/1696).

    This makes it possible to use multiple different instances of
    the `try` effect at the same time.

  - `plus`, `minus`, `sign` moved from the universe to the `num`
    hierarchy:
    [#1702](https://github.com/tokiwa-software/fuzion/pull/1702).

  - `wrapping_integer` is now `num.wrap_around`:
    [#1719](https://github.com/tokiwa-software/fuzion/pull/1719).

  - Rename effect handlers in a consistent manner:
    [#1729](https://github.com/tokiwa-software/fuzion/pull/1729).

  - Move some features to the type features of `ps_map`:
    [#1756](https://github.com/tokiwa-software/fuzion/pull/1756).

  - Use the Ryū algorithm, which is implemented in pure Fuzion, to
    convert floating point numbers to strings:
    [#1758](https://github.com/tokiwa-software/fuzion/pull/1758).

  - Fix issues which caused the `fuzion.sys.misc.unique_id`
    intrinsic (used by the `mutate` effect) and `say` to not be
    thread-safe:
    [#1762](https://github.com/tokiwa-software/fuzion/pull/1762),
    [#1764](https://github.com/tokiwa-software/fuzion/pull/1764).

  - implement `float.type.atan2` in Fuzion, to fix an inconsistency
    between the implementations of `glibc`, `musl`, the OpenBSD `libc`,
    among others:
    [#1791](https://github.com/tokiwa-software/fuzion/pull/1791).

  - move `ps_sets` to `ps_set.type`:
    [#1738](https://github.com/tokiwa-software/fuzion/pull/1738).

  - parameterized `ryu` to also work with `f32` natively:
    [#1802](https://github.com/tokiwa-software/fuzion/pull/1802).

  - rename `quantors` as `quantor`:
    [#1810](https://github.com/tokiwa-software/fuzion/pull/1810).

- fz tool

  - Do not erase internal names from fum files by default:
    [#1623](https://github.com/tokiwa-software/fuzion/pull/1623).
    This allows better debugging of the standard library.

  - fix index out of bounds in `showInSource`
    [#1746](https://github.com/tokiwa-software/fuzion/pull/1746).

- tests

  - The simple C tests are now stricter and fail as well when the
    error they return differs from the expected error:
    [#1710](https://github.com/tokiwa-software/fuzion/pull/1710).

## 2023-07-03: V0.083

- Fuzion language

  - Fix the handling of types, in particular in conjuction with covariance and
    type constraints #1612, #1620, #1627, #1629, #1650. This allowed the removal
    of the type parameter from numeric, see below.

  - Some other bugs in the implementation have been fixed: #1616, #1619, #1648.

  - The redefine keyword has been removed from Fuzion (#1411). In contrast to
    the synonymous redef, this keyword was barely used in the standard library.

  - Fix the handling of calls to boxed values (#1426). When a function is called
    on a boxed value, the target of the call is no longer the ref instance, but
    the value instance that was boxed.

  - This change sounds subtle, but it fixes a number of problems when the
    original value type is used as the type of inner features of the boxed value
    type feature and these types must be value types even after boxing. All the
    details can be found in the the pull request description.

  - Calling type features from type parameters has been fixed (#1471).

  - Fix an IndexOutOfBoundsException in chained booleans (#1511).

  - Allow the redefinition of features with type parameters (#1515).

  - Fix a NullPointerException when inheriting from a feature that does not
    exist (#1509).

  - Fix the propagation of types in covariant features (#1523).

- base library

  -  Add the array.type.new type feature as an alternative to the array
     constructor, but also add a array-constructor-like feature marray as an
     alternative to marray.type.new #1566.

   - Remove the use of the stream feature in some features, and if possible,
     return list instead of Sequence #1569.

   - Remove the Sequences feature #1579.

   - The new concur.atomic feature allows atomic accesses to a value #1580,
     #1606.

   - String.type.from_array has been renamed as String.type.from_marray #1581.

   - The unicode feature has been moved into the character_encodings feature
     #1584.

   - The stdout feature has been removed, use say or yak instead #1585.

   - The some feature has been removed, if you need a wrapper type for choice or
     similar, define your own local wrapper type #1589.

   - The ryu feature is now grouped in the num feature #1600.

   - The type parameter has been removed from numeric and its heirs
    #1622. this.type-covariance is now used instead.  fz tool

   - The -XjavaProf option has been added, which can create a flame graph for
     profiling purposes #1555, #1557.

  - More features, including public-facing ones have been renamed to match the
    Fuzion naming convention (#1412, #1367, #1439).

  - Basic support for networking with TCP and UDP sockets landed (#1223). A
    basic demo webserver written in Fuzion has been added (#1456).

  - Ryu, a float to string algorithm has been implemented in Fuzion
    (#986). Currently, this exists besides the f32.as_string and f64.as_string
    features, which use the float to string operation of the underlying
    backend. Since the output of this varies depending on whether the
    interpreter or the C backend is used, the long-term goal is to replace the
    implementation of as_string by Ryu.

  - The effects io.file.use and io.file.open have been added (#1428), which
    simplify working with files from Fuzion code.

  - In an effort to reduce clutter in the base library, several features have
    been grouped in common outer features, such as complex, fraction, matrix ,
    which are now grouped in the num feature (#1440), or Map, Set, and friends,
    which are in a feature container now (#1465).

  - More features have been moved to type features (#1469, #1482, #1484, #1483,
    #1487, #1488). In particular numeric and heirs use type features now
    (#1506).

  - String.is_ascii_white_space is now u8.is_ascii_white_space (#1494).

  - Remove the Functions feature (#1510). Function composition is now
    implemented for Unary features.

  - Implement the String.upper_case and String.lower_case features (#355).

  - Add memoize feature, which remembers the result of a call to a given feature
    with a given value after the first computation (#1522).

  - Return an error if io.stdin.read_line is called at the end of a file
    (#1531).

  - mutable_tree_map is a heir of Map now (#1534).

  - time.date_time inherits from has_total_order now (#1539). This means that
    date_times can be compared using the standard infix operators now.

- C backend

  - Fix a crash in the garbage collector when using threads (#1397).

  - Change the name of the binary that is created when the main feature is
    omitted from #universe to universe (#1407).

  - Fix compilation of C code generated with non-glibc standard libraries, such
    as musl (#1417).

- fz tool

  - An option -no-backend has been added (#1429), which does not run any backend
    operations. This is useful for checking a Fuzion program for syntax and type
    correctness.

  - Optimized execution time of the HelloWorld example by adding caching to the
    compiler (#1526).

## 2023-05-16: V0.082

- Fuzion language

  - semantics of boxed values have been revised: When using a value type that is
    boxed into a corresponding `ref` type (e.g. an `i32` assigned to `Any`),
    calls to function features will now be performed on the value type (`i32`)
    within the boxed instance (`ref i32`). Only constructors will use the boxed
    ref type as their outer type.  This fixed #1313 and #1296.

  - dynamic binding is now permitted for features with type parameters

  - An attempt to redefine a choice feature now results in an error (#1304).

  - Fixed handling of the choice of syntax (#1289):

        # no declaration of the apple, pear, or banana features here!
        fruit : choice of apple, pear, banana.

    The code in the example above used to work, but this broke and went unnoticed for a while.

   - \' is no longer a valid escape in string constants. This is because ' is a
     valid character in strings without an escape as well (#1315).

   - The multi-line strings presented in the last Fuzion Update have been
     extended to allow the dismissal of newlines. This allows wrapping long
     strings in Fuzion code that is not supposed to contain line breaks (#1299).

        s := """
          hello \
          world"""

   - The `fun` keyword has been removed from Fuzion (#1321, #1325). Lambdas
     should be used instead.

   - the `redefine` keyword has been removed, `redef` should be used instead.

- base library

   - grouped complex, fraction and matrix feature in num outer feature

   - renames according to naming conventions

   - new effects io.file.use and io.file.open

   - searchable_list has been merged into searchable_sequence (#1333).

   - More features, including public-facing ones have been renamed to match the
     Fuzion naming convention (#1337, #1338, #1339, #1340, #1341, #1345, #1356,
     #1366, #1368).

   - The spit feature has been removed (#1343) use the equivalent yak feature to
     print text without a new line..

   - Extended the exit effect to allow setting an exit code which is used later
     when calling exit without arguments (#1346). This is useful in tests, for
     instance.

   - Many effects in the standard library now inherit from simpleEffect (#1370,
     #1371, #1372, #1373, #1374, #1375). This decreases code complexity
     significantly. interpreter backend

   - The intrinsics for setting and clearing environment variables have been
     implemented to always return failure. This is because Java does not support
     modifying environment variables at runtime, but avoids compiler errors when
     trying to use these features from the interpreter backend (#1336).

- fz tool

   - Allow specifying -1 as the maximum warning or error count. In this case, an
     unlimited amount of warnings respectively errors is shown (#1332).

   - Compatibility with different versions of the Clang compiler has been
     improved when compiling code from the C backend (#1384).  tests

   - Tests for nested option have been added (#1316). This will ensure nested
     options continue to work as they do right now even though changes to their
     internals are planned.


## 2023-04-05: V0.081

- Fuzion language

  - Introduced syntax sugar for lazy evaluation.

  - The code for handling of outer types has been rewritten entirely.

  - Parser has been improved to distinguish infix : from : used in inherits clause.

  - Support for Multi-line strings literals

  - Improved type inference of type parameters, e.g., `3 = f` now works for `f`
    being of any numeric type, not only for `i32`.

  - Using `universe.this.x` it is now possible to access a feature named `x`.

  - type features can now access the type parameters of the underlying feature, e.g.,

      Sequence (T type) is
        ...
        type.empty Sequence T is
          lists.empty T

   - added syntax for effects in feature declarations.

      HelloWorls ! io.out is
        say "HelloWorld!"

- base library

  - added Mutable_Linked_List and mutable_tree_map

  - renamed has_equality as equatable

  - lazy variants of some features where removed, the main variants are now lazy

  - `Unary` function type has been introduced.

  - `Monoid` no longer defines its own infix ==, but uses equatable

  - `time.date_time` and `time.now` were added

  - `mutate` now supports local mutation

  - `comparable_sequence` was merged into `searchable_sequence`

  - `CTrie` can now be created using a sequence of key-value pairs (#1073)

  - uses of `stream` removed for planned removal of `stream` feature

  - `String` now supports `split_n`, `split_after`, and `split_after_n`

  - `list.init` was added.

  - clean up in `fuzion.sys.fileio`

  - on Windows, `stdout` and `stderr` is now opened in binary mode.

  - documentation has been improved for many standard library features.

  - more consistent naming: `string` -> `String`, `Object` -> `Any`, or `mapOf`
    -> `map_of`

  - equality testing now done using `type.equality`

  - Haskell-style `infix :` operator for lazy lists was added

  - added `Sequence.infix []` with no argument, returns a function that takes
    an index, and returns the element of the sequence at the given index.

  - Replaced `hasHash`, `partially_ordered`, and `ordered`by `has_hash`,
    `has_partial_order`, and `has_total_order`.

- fz tool

  - quadratic compilation time was improved

  - formatting of code in error messages more readable now

  - on a call with wrong arg count, error message now proposes solution

  - some error messages have been improved.

  - output of `-XdumpFUIR`option improved for better debugging (#1110)

  - fixed many bugs relating to type features

- interpreter back-end

  - clean-up in handling of open resources like files

- C back-end

  - windows support for fileio and env vars has been improved (#1087)


- fzjava tool

  - improved performance by lazily accessing data from dependent `.fum` files.

- fzdocs tool

   - now creates links to redefined features

   - removed emojis in the page titles, 🎆 (effects) and 🌌 (universe)

   - private features are now hidden from the documentation by default.

## 2023-01-12: V0.080

- Fuzion language

  - type features can now access the type parameters of the underlying feature.

  - Support for covariant feature redefinition:

    `a.this.type` can now be used to refer to the type of an outer feature
    `a`. This can be used, e.g., to ensure that an argument or result of a
    feature has the same type as the target. E.g., `numeric.infix +` can require
    the argument and result to be of type `numeric.this.type` such that in a
    redefinition `i32.infix +` requires an argument of pf type `i32` and
    produces a result of the same type.

  - Modifiers `synchronized`, `const` and `leaf` or no longer supported (but are
    still reserved keywords).

  - Added modifier `fixed` for features that should not be inherited by children
    of the outer feature.

  - A type parameter `T` with constraint `c` is now declared using `T type : c`
    which is in sync with the syntax for feature inheritance `x : c is ...`.


- base library

  - moved many features from plural-form unit type features to type features,
    e.g. `Sequences.empty` is now `Sequence.type.empty`.

  - lots of renaming from camelCase to snake_case as in ` mapOf` -> `map_of`.

  - renamed `Object` as `Any`.

  - renamed `string` as `String` (`ref` features should start with a capital).

  - added `type.equality` to several features.

  - `infix ∪` and `infix ∩` are now used for union and intersection instead of
    `⋃` and `⋂`.

  - `unit.type.monoid` was added.

  - `file.io` now supports `seek` and `file_position`. `exists` was replaced
    by `stats`/`lstats`.

  - `String` now supports `find_last`, `to_valid_utf8`, `fields_func`, `cut`.

  - Indices in strings are now usually byte indices in the uft8-encoding, e.g.,
    `String.substring` and `String.split` now use utf8-byte indices as
    arguments.  Features working on codepoints were renamed for clarity:
    `pad_start` as `pad_codepoint_start` and `substring_codepoint`.

   - `list` now has features `prepend_to_all` and `intersperse`, no longer
     supports `forceHead`.

   - `outcome` now is a monad such that verbose match-statements can
     be replaced by concise calls to `bind`.

- fz tool

  - back-end now uses `-Wall -Werror` by default.</li>

- fzjava tool

  - improved performance by lazily accessing data from dependent .fum files.



## 2022-12-08: V0.079

- Fuzion language

  - An implicit (empty) else-branch in an if-statement now results in 'unit'.

  - Inheritance for type features:

    Abstract type features using arguments or results of the corresponding type
    can now be redefined using the actual type. For now (until better syntax is
    supported) the implicit generic type 'THIS_TYPE' is used in the abstract
    feature.

  - conflicting argument names as in

      f(i, i i32) is

    now result in an error.

  - prefix, postfix and infix operators can now be declared with type parameters
    and one (prefix, postfix) or two (infix) value arguments:

      prefix $$(X type, a X) => "type:{X.name} val:$a"

    permits a call '$$x1' if the operator is declared in the current (or outer)
    feature.  Type parameters in this case are inferred from the actual
    arguments.

  - A 'match' statement now may have an empty list of cases

  - Syntax improvements in '.type' and '.env' expressions.

  - Updated to support Unicode 15.

  - Disallow declaration of uninitialized fields as in 'f i32 := ?'.

  - tuple types now can use '(A,B,C)' syntax, e.g.,

      triple(T type, v T) (T,T,T) is
        (v,v,v)

    is equivalent to

      triple(T type, v T) tuple T T T is
        (v,v,v)

  - function types and lambda expressions can no longer be declared using the
    'fun' keyword. Instead, syntax like '(i32, bool) -> string' or '(x,y) -> x +
    y*3' has to be used.

  - Fuzion grammar cleanup: new rule 'actual' for actual arguments, which could
    be an expression for a value argument or a type for a type argument

  - cleanup and simplification in indentation rules for actual arguments and
    cases in a match-expression.

  - ASCII control codes 'HT', 'VT', 'FF' and stray 'CR' are now rejected in the
    source code.

- base library

  - added effect to new feature 'io.file': 'exists', 'delete', 'move',
    'create_dir', 'stat.exists', etc.

  - fixed spelling errors, updated syntax for type parameters (comments still used '<'/'>')

  - removed 'java' feature and all inner features 'java...', these were unused.

  - Fuzion modules now exist for most standard Java modules:

      'java.base' 'java.compiler' 'java.datatransfer' 'java.desktop'
      'java.instrument' 'java.logging' 'java.management' 'java.management.rmi'
      'java.naming' 'java.net.http' 'java.prefs' 'java.rmi' 'java.scripting'
      'java.security.jgss' 'java.security.sasl' 'java.se' 'java.smartcardio'
      'java.sql' 'java.sql.rowset' 'java.transaction.xa' 'java.xml.crypto'
      'java.xml' 'jdk.accessibility' 'jdk.attach' 'jdk.charsets' 'jdk.compiler'
      'jdk.crypto.cryptoki' 'jdk.crypto.ec' 'jdk.dynalink' 'jdk.editpad'
      'jdk.httpserver' 'jdk.jartool' 'jdk.javadoc' 'jdk.jconsole' 'jdk.jdeps'
      'jdk.jdi' 'jdk.jdwp.agent' 'jdk.jfr' 'jdk.jlink' 'jdk.jpackage'
      'jdk.jshell' 'jdk.jsobject' 'jdk.jstatd' 'jdk.localedata'
      'jdk.management.agent' 'jdk.management' 'jdk.management.jfr'
      'jdk.naming.dns' 'jdk.naming.rmi' 'jdk.net' 'jdk.nio.mapmode' 'jdk.sctp'
      'jdk.security.auth' 'jdk.security.jgss' 'jdk.xml.dom' 'jdk.zipfs'

  - renamed several features from 'camelCase' to 'snake_case' or
    'Capitalized_snake_case' for 'ref' types.

  - abstract equality (see https://flang.dev/design/equality") as explained by
    Noble et al in The Left Hand of Equals
    (http://web.cecs.pdx.edu/~black/publications/egal.pdf) is now supported:

    base library feature 'has_equality' defines an abstract feature
    'has_equality.type.equality' that can be redefined for heir features such as
    'string'.  Note that the equality operation is bound to the type, so
    different types along an inheritance hierarchy may define different equality
    operations.  This is in strong contrast to object-oriented approaches like
    Java that inherit 'Object.equals'.

    For now, features 'equals' and 'infix ≟' can be used to compare
    according to abstract equality as defined by the operand's type. Eventually,
    'infix =' will be used for this.

    'type.equality' was defined for base library features without type
    parameters (type features are not yet supported for features with type
    parameters)

  - Added features to set env variables.

  - In some library features, 'forAll' was renamed as 'for_each' to avoid
    confusion with 'infix ∀'.

  - Improved documentation of many features

  - added bit-wise-not operation 'prefix ~' to 'wrappingInteger'.

  - support for big integers via Fuzion features 'int' and 'uint'.

  - 'numericSequence' now inherits from 'hasEquals'

  - removed uses of 'stream' from 'string' in favor of 'list'.

  - added new module 'terminal.fum' providing ANSI escape codes. The main
    purpose of this module at this time is to provide a simple test for modules.

  - added 'ctrie' hash tries.

  - added 'ascii' for ASCII control codes.

  - generally replaced generics using '<'/'>' by type parameters.

  - improved syntax of type-expressions: Now using '(list i32).type' instead of
    the awkward 'list i32 .type'. Same for '.env'.

  - added 'cache' effect to allow a simple caching of results.

- fz tool

  - C back-end now provides options '-CC=' and '-CFlags=' to specify C compiler
    and options to be used.

  - arguments following main feature are now passed to Fuzion code via the
    'envir.args' effect.

  - new option '-moduleDir' to specify where to load modules from.

  - added option '-sourceDirs={<path>,..}' to specify where to search for sources. If this option is not provided, the current
    directory is used to search for source files.  Otherwise, the (possibly empty) list of paths provided via this option is used.

  - Added option '-saveLib=<path>' to create a module file.

  - Removed option '-XsaveBaseLib' and added '-XloadBaseLib=(on|off)' to disable
    loading of 'base.fum' module which is needed when creating 'base.fum'.

  - new option '-XdumpModules={<name>,..}' to print the contents of a loaded
    module as a colored hex dump with comments.

  - Support for several module files.  Except for the base module 'base.fum'
    that does not depend on another module, module support is still incomplete,
    e.g., modules may not use type features with types from other modules.

- fzjava tool

  - Now accepts '-modules' and '-moduleDirs' arguments to specify Fuzion modules
    already generated that a Java module depends on.  This avoids repeated
    declaration of unit-value features for Java packages.  </ul>

- fzdocs tool

  - has been added to the main Fuzion repository.

- C back-end

  - Fixed use of thread locals on Windows

- tests

  - added 'tests/indentation/indentation' and
    'tests/indentation_negative/indentation_negative' to illustrate and check
    Fuzion's indentation rules for code blocks and arguments.

  - added several regression tests for bug fixes

- Build infrastructure

  - Some changes to allow building on NixOS


## 2022-08-15: V0.078

- parser

  - unified handling of indentation for blocks of statements, actual arguments,
    match and .. ? .. | .. expressions, etc.

  - actual arguments may now be indented and broken into several lines as
    follows

      call_with_four_args arg1 arg2 arg3 arg4

      call_with_four_args arg1 arg2
                          arg3 arg4

      call_with_four_args arg1
                          arg2
                          arg3
                          arg4

      call_with_four_args
        arg1 arg2 arg3 arg4

      call_with_four_args
        arg1 arg2
        arg3 arg4

      call_with_four_args
        arg1
        arg2
        arg3
        arg4

  - fixed several corner cases related to indentation

  - Exceptions to single-line expression as in

      if expr ? a => true
              | b => false
        say "true"

    have been removed, now requires parentheses

      if (expr ? a => true
               | b => false)
        say "true"

  - 't.env' and 't.type' expression now permit the type 't' to be in parentheses
    '(t).env' and '(t).type' such that type parameters can be provided '(list
    i32).type' or '(cache myType).env'.

  - remove support for function types using 'fun' keyword, must use lambda
    notation such as '(i32, bool) -> string' instead.

- base lib

  - started adding support for file I/O

  - new feature 'ascii' defining ASCII control codes

  - removed use of '<'/'>' for generics in favor of new type parameter syntax.

  - added 'cache' effect to allow a simple caching of results.

- tests

  - added positive and negative tests for indentation: 'indentation' and
    'indentation_negative', contain many examples of good and bad
    indentation.


## 2022-08-03: V0.077

- Fuzion language

  - added syntax sugar for tuple types like '(i32, list bool)'.

  - allowed types to be put in parentheses, i.e., '(stack i32)' is the same as
    'stack i32'.  Syntax of '.env' and '.type' will require parentheses, i.e.,
    instead of 'stack i32 .type' one will have to write '(stack i32).type' and
    similarly for '.env'.

  - changed parser to allow actual arguments passed to type parameters to be any
    type, including function types '(i32)->bool' or tuples '(i32, string)'.

  - removed support for lambdas using 'fun' keyword, i.e., instead of 'fun (x
    i32) -> x+x', you have to write 'x -> x+x'.  Type inference from a lambda is
    not possible, though.

  - features with empty argument list and a result type that is put in
    parentheses (usually a tuple) now require an empty argument list '()' since
    the result type would otherwise be parsed as an argument list.

- C backend

  - use DFA to remove fields and calls to read (removed) unit type fields

  - do not create code for intrinsics that are found to be unreachable during
    DFA.

- DFA

  - cleanup and minor enhancements


## 2022-07-27: V0.076

- C backend

  - GC support using the Boehm–Demers–Weiser garbage collector. Use '-useGC'
    option for the 'fz' command.

  - result of application-wide data-flow analysis is now used to control code
    generation resulting in smaller binaries and (usually) faster build
    time. This can be controlled using 'fz' with option '-Xdfa=(on|off)'.

- FUIR

  - Added generic abstract interpreter that provides the basic infrastructure
    for abstract interpretation.  This abstract interpreter is used for the C
    backend and will be used for other backend and static analysis such as
    data-flow analysis.

  - added application-wide data-flow analysis

  - 'fz' command has new option '-dfa' that runs DFA analysis as backend. Should
    be used with '-verbose=<n>' for 'n>0' to get ouput other than just errors.

- base lib

  - started adding support for file I/O.

  - 'mapOf' now can be used with an array of '(key, value)' tuples

  - 'asString' on mutable value now calls asString on the value.

## 2022-07-04: V0.075

- C backend

  - tail recursive calls are now optimized using a goto to the beginning of the
    feature's code.

- FUIR

  - added analysis to detect tail calls and escape analysis for 'this' instance.
    The analysis results are used for tail recursion optimization in the C
    backend.

- fzjava

  - fixed passing of arrays of references when calling Java code from Fuzion
    features.

- throughout

  - many bug fixes


## 2022-05-31: V0.074

- Fuzion language

  - Overloading with type parameters now works as follows: A feature f with
    m type parameters and n value parameters can be called with m+n actual
    arguments (m types and n values) or, if the types can be inferred from the
    value parameters, with just n actual value arguments.

    If an overloaded f with n formal arguments (type or value) exists, a call
    with n actual arguments will always call this f with n formal arguments.

- fz command

  - bug fixes for #113, #297, #300

- base lib

  - some changes towards using type parameter arguments instead of generics
    using '<' / '>'

## 2022-05-18: V0.073

- Fuzion language

  - add support for calling type parameters, i.e., in a feature `f(X type)`, it
    is now possible to call `X` as in `say X`.  The result is an instance of
    feature `Type`.

  - add support to declare inner feature in type feature, e.g.
    ```
      i32.type.blabla is say "this is blabla in i32.type"
    ```
  - type features now inherit from the type features corresponding to the
    plain features their corresponding plain feature inherits from.

- stdlib

  - added `fract`, `floor`, `ceil` to `float`.

  - fixed `stream.asList` to work if called repeatedly.

  - fixed `print` and `println` to stdout/stderr to print the whole string
    atomically at once, i.e., no longer split it up into single characters.

  - added `io.stdin`.

  - added `Functions.compose`.

  - added effect `mutate`. A mutable field `f` with initial value `v` can now be
    created using `f := mut v`

- fum/fuir:

  - add support for type parameters in .fum file

## 2022-04-23: V0.072

- Front End

  - improved type inference for results of lambdas: Code like
    ```
      l.map<T> (x -> f x)
    ```
    no longer need '<T>', i.e.,
    ```
      l.map (x -> f x)
    ```
    suffices.

- Fuzion language

  - Added new expression `xyz.type` to get access to a unit type value corresponding to
    type `xyz`. This is planned to work for type parameters allowing features to be defined
    for types that can be used in generic code without to have an instance of that type (e.g.,
    to call a constructor for a value).

  - type parameters can now be declared with the normal parameters, i.e., instead of
    ```
      f<A : xyz, B>(v A, w B) is ...
    ```
    one can write
    ```
      f(A xyz.type, B type, v A, w B) is ...
    ```
    also, calls of the form `f<T1,T2> a b` can now be written `f T1 T2 a b`.

    Type of the form
    ```
      list<map<string, i32>>
    ```
    can now be written as
    ```
      list(map string i32)
    ```
    The old syntax will eventually be removed.

  - match statement now supports matching `*`, which creates a default branch.

  - calls of the form `f a,b,c` are no longer supported, has be be either `f a b
    c` or `f(a,b,c)`.

  - full stop can now be used for empty constructors, e.g.
    ```
      red is
      green is
      blue is
    ```
    can now be written as
    ```
      red.
      green.
      blue.
    ```
    or even
    ```
      red, green, blue.
    ```
  - syntax sugar for choice: a declaration of a choice had the form
    ```
      red is
      green is
      blue is
      point(x,y i32) is

      colorOrPoint : choice<red, green, blue, point> is
    ```
    Now, this can be done using `of` as follows
    ```
      colorOrPoint : choice of
        red is
        green is
        blue is
        point(x,y i32) is
    ```
    or even
    ```
      colorOrPoint : choice of
        red, green, blue.
        point(x,y i32).
    ```

- stdlib

  - result of `list T h t`is now `list<T>` which is convenient in declaring lazy
    lists as in
    ```
      ones => list 1 ()->ones
    ```
    for an endless list of `1`s.

  - added `numericSequence` and `floatSequence` with operations like `average`,
    `std_dev`, etc.

  - added `float.round`

  - added `ctrie` data structure

  - added `Type` as parent feature for types.

  - added `list.flatMap` and `Sequence.flatMapSequence`

  - added `Sequence.first` with default value argument, `Sequence.nth` to get
    n-th element. Sequence is not used more often for iteration, replaces
    'stream'.

  - added `string.trimStart` and `string.trimEnd`

  - default random handler can now be seeded with an u64 given in env var
    `FUZION_RANDOM_SEED`.

  - added effects

    - `panic`
    - `exit`
    - `envi.vars` to access environment variables.
    - `envi.args` to access command line arguments.
    - `concur.thread` to spawn threads

  - joined floats/bitsets/codepoints/matrices.fz into
    float/bitset/codepoint/matrix.fz. These will eventually be defined in
    float/bitset/codepoint/matrix.type.

  - move `sys` to `fuzion/sys`, this is the location for low-level intrinsics

  - removed InitArray, no longer needed since we have array syntax sugar
    `[1,2,3]`.

  - rename `searchableList` as `searchableSequence` since it is a `Sequence`.

  - added `time.nano` for short delays and high-res timer, `time.duration` for
    time spans

- fum/fuir:

  - generics are no longer part of the Fuzion module file or the Fuzion
    intermediate representation. Instead, these are argument features.


## 2022-04-01: V0.071

- Social media

  - new Twitter channel @FuzionLang, please follow

- Fuzion language

  - added support for effects: New expression '<type>.env' permits access to
    current instance of an effect

  - unicode punctuations are now allowed as codepoints within operators

- fz

   - 'fz -effects main.fz' now performs static analysis on 'main.fz' and prints
     effects required by this feature.

- stdlib

  - new effects: io.out, io.err, random, time.nano, state<T>, envir.args, try/raise

  - f32/f63 now offer trigonometric functions, exp, log, and squareRoot, constants ℇ, π

  - intersection operator added to psSet: infix ⋂

- C backend

  - support for f32 and f64

- flang.dev

- tests

  - tests on windows now automated using github

## 2022-02-25: V0.070

- fzjava
  - fixed name conflicts between Java's `String.isBlank`/`String.split` and
    Fuzion's `string.isBlank`/`String.split`.

## 2022-02-25: V0.069

- flang.dev
  - design
    - added example for [Automatic Monadic
      Lifting](https://flang.dev/design/monadic_lifting) using Knuth's
      man-or-boy example and a new feature _handles_ that provides a state monad
      similar to Haskell's _IORef_.

- C backend
  - heap allocate value instances that are kept alive through inner instances,
    fixes segfault in #168.

- IR
  - added new category of clazz: dynamic outer ref. A value clazz _c_ is a
    dynamic outer ref if it is referenced from inner clazzes _i_ and there
    exists heirs of _c_ that may redefine features such that the accesses from
    _i_ require dynamic binding.

- Fuzion language
  - added keyword *intrinsic_constructor* to mark intrinsics that create an
    instance of their result type.  This simplifies static analysis for
    frequence cases such as *fuzion.java.getField0*.
  - inline arrays now may end with a comma as in
    ```
      a := [ 1,
             2,
             3,
           ]
    ```

- stdlib
  - added *Sequence.reduce*, *string.split*, *string.isBlank*, *handles*, ...

- fuzion.ebnf
  - several fixes, cleanup

- fz, fzjava
  - minor fixes in scripts for issues reported by _shellcheck_.

## 2022-02-04: V0.068

- fzjava

  - fixed generated code to use 'Sequence' instead of 'List', which was renamed
    a while ago.

- stdlib

  - lib: Minor improvements used in tutoral at flang.dev:

    - added 'list head tail' as a counterpart to Haskell's 'head : tail' for
      list creation.

    - added u128.name

    - added strings.fromCodepoints

## 2022-01-30: V0.067

- front end

  - speed up by

    - caching results for AbstractType.actualType

    - replaced string comparison in FeatureName.compareTo by int comparison.

    - removed usage of strings in AbstractFeature.isOuterRef

    - removed feature names for internally generated features from .fum file

    - caching for LibraryFeature.innerFeatures()

    - disabled check()s unless env var CHECKS=true

    - removed outer ref field from choice features and from any feature whose
      outer feature is the universe.

- stdlib

  - added 'elementOf'/'infix ∈' to 'string'

  - added 'add' to 'Set'

  - added explanation of the origin of the term 'yak' to the same named feature.


## 2022-01-24: V0.066

- front end:

  - speeup up by

    - creating source positions for code loaded from .fum file on demand only.

    - caching of code, result, outerRef withn LibraryFeature

    - using StatementVisitor instead of FeatureVisitor. The former does not
      support code modification, so it might be faster.


## 2022-01-21: V0.065

- flang.dev

    - added .fum file documentation to https://flang.dev/design/fum_file

    - added browsable fuzion API documentation to https://flang.dev/docs/index

- parser

    - single-line operator expressions may now continue after a multi-line
      klammer-expression, e.g.,
      ```
        a := 1 * (2
                  + 3
                  + 4) - 5

      ```
      is allowed now.  The same holds for expressions using [] or {}:
      ```
        b := 2 * { say "hi"
                   + 4
                 } - 1

        c := 3 * [ "A",
                   "B",
                   "C" ].fold strings.concat
                        .byteLength - 5
      ```
    - improve handling of '.'-chained calls over several lines. It is now
      possible to write
      ```
        s := myseq.drop n
                  .take m
                  .asString
      ```
      before, '.take' was applied to 'n' instead of the result of '.drop'.  Now,
      a space separated argument list is terminated by a new line followed by
      '.', while a call in a line is permitted to continue in the next line if
      followed by an indented '.'.

- front end

  - suppoert for qualified features, even to add inner features to library code
    such as
    ```
      i32.factorial => if val <= 1 then 1 else val * (val-1).factorial
    ```
    or even

    ```
      i32.postfix ! => if val <= 1 then 1 else val * (val-1).factorial
    ```
    such that you can write
    ```
      say 6.factorial
      say 4!
    ```
  - parser now uses the same rule when parsing a .fz file read form a source
    directory as when reading stdin or an explicit file given on the command
    line.  Before, .fz files read from a source directory were not permitted to
    contain more than one feature declaration.

  - cleanup in module creation and loading code

- stdlib

  - renamed 'List' as 'Sequence'. A 'Sequence' is a finite or infinite data
    structure containing elements of one type that can be iterated as a
    (Lisp-style) 'list' or a (Java-style) 'stream'

  - cleanup: joined related source files, e.g. i32.fz now contains the code of
    i32s.fz and i32_.fz as well.  This is possible since .fz files read from a
    source directory now may contain several feature declarations.

## 2022-01-06: V0.064

- front end:

  - several optimizations like caching to improve performance of using module
    file.

  - save source code positions of feature declarations and statements to module
    file for more detailed error messages.


## 2022-01-03: V0.063

- front end:

  - support precompilation of base library code into a module file
    build/modules/base.fum.

    This file is mapped into memory instead of parsing the source files in
    build/lib resulting in faster startup up.

    For the front end and the interpreter, the AST is re-created from this file
    as needed.

    Currently, the AST is also re-created to produce the FUIR representation
    used by the C backend, but this should eventually not be needed any longer.

## 2021-10-29: V0.062

- flang.dev website

  - added more idioms, e.g. #182 (quine), 242..258, etc.

- IR

  - major code restructuring and cleanup moving logic away from the AST and into
    the Front End, Middle End, Application IR, etc.  The goal is to be able to
    create "module IR" files as a faster replacement of source code.


  - added very basic data-flow-analysis phase that finds some very obvious cases
    of uses of uninitialized fields.


## 2021-10-15: V0.061

- flang.dev website

  - added many idioms, updated syntax of existing idioms

- library

  - added matrix, matrices

  - lot's of minor improvements

- Frontend

  - improve type inference for type parameters

- general

  - switched to OpenJDK 17


## 2021-09-30: V0.060

- flang.dev website

  - new design for code input / execution output text areas

  - tuturial section on string literals.

  - examples and idioms updated for new syntax of lambda expressions and
    function types.

  - new idioms 141, 142, 150

- fuzion.ebnf

  - grammar is now checked using antlr, bugs and inconsitencies have been fixed.

- Frontend/Parser:

  - new syntax for function types: '(i32, string) -> bool' or 'u8 -> string'

  - new syntax and type inference for lambdas: 'x -> 2*x', 'x,y -> x+y',
    '(a,b,c) -> a < b < c', '() -> 42', etc.

  - last expression in a constructor now must result in type 'unit'. This is to find
    problems earlier when constructors are used instead of routines.

- IR

  - removed callbacks from IR to the backend to have a clearer separation of phases.

- FUIR

  - Moved code to set outer references from backend to FUIR to simplify backend.

- C backend

  - fix wrap-around overflow handling in created code for signed integer types.

  - several code generation fixes

  - code cleanup

- tests

  - analyzed root cause of failing tests, added issues to github for tests that
    could not be fixed, added mechanism to skip these tests, such that a normal
    build does not report any errors for known problems.

- fz

  - limit number of errors and warnings printed, new options '-XmaxErrors=<n>'
    and '-XmaxWarnings=<n>'.

  - many bug fixes


## 2021-09-02: V0.059

- FrontEnd / lib / backends

  - support for types i8, i16, u8, u16, f32, f64.

- flang.dev website

  - added sections on integer and float constants to tutorial.

- Java interface:

  - added java.desktop module that contains java.awt graphics

  - support for primitive types and Java arrays

- examples

  - added example javaGraphics that uses java.desktop module to draw into a
    window.


## 2021-08-23: V0.058

- FrontEnd

  - fix running examples such as tutorial/overflow* on flang.dev (see git commit
    for details).

## 2021-08-20: V0.057

- Java interface

  - new tool fzjava to create Fuzion wrappers for Java code

  - 'fz -modules=java.base <x>' will run '<x>' with JDK's java.base module
    accessible, e.g., via

      serversocket := Java.java.net.ServerSocket.new 8080

- examples

  - added example 'callingJava' to show how to call Java code from Fuzion and
    'webserver' that shows how to use Java APIs to write a minimalistic web
    server in Fuzion.

- fz

  - now supports modules via '-modules' options. Currently, these are just
    additional source code directories in 'build/modules', but these should be
    packed into fuzion module files eventualls.

- Parser

  - precedence of fraction bar ⁄ is higher than basic arithmetic operations.

- library

  - support for types i8, i16, u8, u16

  - string.utf8 now returns an List<u8>.

- flang.dev website

  - now supportes ACE editor for source code

  - use server-side events to fix many issues in the communication.

  - several new idioms implemented and old ones improved

- General

  - Fuzion logo is now generated


## 2021-07-30: V0.056

- Parser

  - Changed parsing of expressions using []: 'a[i]' is an call to 'a.index
    [](i)' as before, but 'a [i]' now is a call to 'a' with an array as
    argument, i.e., 'a([i])'.  This avoids extra parentheses when passing an
    array as an argument.

- tests

  - changed syntax in tests to not use { }, ( ), commas, semicolons, when
    possible

- fz

  - now accepts '.fuzion' as extension for source file given as command line
    argument: 'fz ./helloworld.fuzion' now works instead of printing a confusing
    message.

  - error messages now enclose code snippets in '' and highlight feature names, types
    and expressions in different colors.

## 2021-07-21: V0.055

- C backend

  - several bugs fixed: bugs related to (normlized) outer refs, calls to
    not-instantiated clazzes, code after a statement that produced a void
    result, array of unit type, etc.

- IR

  - several fixes in normlization of outer refs, i.e., in the way clazzes
    instantiated with different outer contexts are distinguished.  This fixed
    several tests that failed when using the C backend.


## 2021-07-08: V0.054

- flang.dev

  - changed path to load 'main.js' to be absolute '/main.js'.  Before, main.js
    could not be loaded if the first page access was in a sub directory such as
    'flang.dev/tutorial/index' and anything requiring java script, like
    executing examples, did not work.

- Front End

  - fixed issue#8: returing 'false' as 'option<V>' n logner allowed


## 2021-07-06: V0.053

- Parser

  - More haskell-style call syntax
    ```
      f(a,b)   calls f with arguments 'a', 'b'
      f (a,b)  calls f with argument '(a,b)', a tuple

      f fun () => x    no longer works
      f (fun () => x)  must be used instead
    ```

- Front End

  - Now enforce feature with 'unit' result to result in unit type value.

- lib

  - faction now uses unicode fraction slash '⁄' to create fraction, e.g., '1⁄2'

## 2021-06-30: V0.052

- Parser

  - Haskell-style call syntax with space separated arguments and left binding,
    so the call
    ```
      f a b (g c d)
    ```
    is equivalent to
    ```
      f(a,b,g(c,d))
    ```
    Additionally, infix, prefix and postfix operators now bind stronger than a call
    if there is no white space (or comment) between the operator and its operand,
    and weaker than a call if there is white space.  This means
    ```
      f x+1
    ```
    is equivalent to
    ```
      f(x+1)
    ```
    while
    ```
      f x + 1
    ```
    is equivalent to
    ```
      f(x)+1
    ```
    This makes the semantics depend on white space in a way that might be
    surprising.  This change is therefore considered for experiments only, if this
    turns out to be too confusing, the grammar should go back to not make operator
    precedence depend on spaces around operators.

- lib, tests

  - libs and tests were changed to support new call syntax, in particular the
    left binding of call and the weaker precedence of operators that are
    separated by white space.


## 2021-06-29: V0.051

- flang.dev

  - design: added flang.dev/design/calls.html for thoughts on Fuzion's call
    syntax.

  - added idioms 134, 135, 136

- front end

  - allow chained boolean expressions with >3 terms, e.g., 'a < b < c < d'

  - support for '? |' instead of match, allow '|' as case separator
    ```
      a ? x X => x.foo
        | y Y => y.bar
    ```
    as short-hand for
    ```
     match a
       x X => x.foo
       y Y => y.bar
    ```
    also allowed is
    ```
     match a
       | x X => x.foo
       | y Y => y.bar
    ```
  - A loop's 'until' clause now supports 'then' to separate the condition from
    the code executed for successful loop termination.  The code is now
    summetric to 'if cond then'.

- lib

  - 'o??' and 'o!!' are new postfix operator synonymes for 'exists' and 'isNil'
    in 'option', 'numOption' and 'outcome'.

- fz

  - several bug fixes in FE, IR, FUIR; interpreter and C backend.


## 2021-06-23: V0.050

- Fuzion front-end/middle-end

  - Fixed major performance bottleneck, performance improved by about 40-60%.

- fz tool

  - new option -XjavaProf (for profiling fz's own Java code) and -X/--xhelp).

- flang.dev

  - added idiom 76

## 2021-06-22: V0.049

- lib: added

  - bitsets
  - sum
  - List.tails, takeWhile, dropWhile
  - searchableList.countMatches, countMatchesOverlapping
  - string.count, contains

- FUIR

  - suppress code generation for pre- and post-conditions that are constant and
    'true'.  Reduces binary size when using C backend on HelloWorld with
    '-debug=0 -safety=off' by 3.5%.

- flang.dev

  - added idioms 39, 40, 49, 68, 76, 82, 116

## 2021-06-18: V0.048

- IR: Added mechanism to 'normalize' clazzes to reduce the explosion in the total
  number of clazzes generated: Clazzes that only differ in their outer clazzes
  are now fused if the outer clazzes are references.

- lib

  - replaced 'streamable' by 'List', i.e., the preferred way to iterate is by
    using lisp-syle lists consisting of a head and a cons-cell.

  - added u128 for unsigned 128-bit integers

- flang.dev

  - added idioms 62, 63

## 2021-05-31: V0.047

- tools:

  - fz tool now prints execution time for phases prep, front end, middle end,
    ir, and back end.

- front end:

  - improved performance by caching result of Type.outer()

- lib

  - fix exponential performance when printing string built from s+(s+(s+(...)))


## 2021-05-30: V0.046

- lib

  - string: added startsWith, endsWith


- flang.dev

  - added idioms 84, 85, 86, 87, 88, 89, 90, 93, 96, 97, 100, 108, 110, 112,
    113, 114, 117, 118, 119, 122, 124, 127, 227, 231


## 2021-05-24: V0.045

- lib:

  - integer.bin/cot/hex to create binary, octal and     hex strings

  - fix quadratic runtime of printing string consisting of many sub-strings
    concatenated using 'infix +'.

  - i32/u32/i64/u64: added ones_count (population count)

  - stream/streamable: added asList, planning to work more with (lazy,
    immutable) lists than with streams that are inherently mutable. Also added
    'take', 'drop', 'infix ++' and 'asArray' to stream/streamable.

  - added feature 'some' as standard wrapper. This can be used, e.g., to make an
    'option<some<nil>>' without getting complaints about overlapping values, the
    possible values of typ 'option<some<nil>>' are 'nil' and 'some nil'


- flang.dev

  - added idioms # 38, 44, 46, 47, 48, 53, 54, 55, 57

## 2021-05-24: V0.044

- lib

  - new unit types strings, i32s, i64s, u32s, u64s that contain monoids and
    other features related to string, i32, i64, u32, u64 but not requiring an
    instance.  Also added new routines i32, i64, u32, u64, all without arguments
    to distinguish them from the integer types that have one argument, that
    result in the corresponding unit type i32s, i64s, u32s, and u64s,
    respectively.

    Now, we can write, e.g., '[1,2,3].fold i32.sum' to sum the elements of an
    array.

  - add new feature 'Set' as abstract parent for sets, and operations such as
    'infix ∈', so we can write '2 ∈ [1,2,3]' or '7 ∉ 10..300' (both result in
    bool value true).

- flang.dev

  - added idioms # 51, 52

## 2021-05-21: V0.043

- lib

  - added codepoint.fz and string.codepoints/codepointsArray to create stream
    and array of codepoints from a string.

  - added 'infix **' for integer exponentiation.

- parser/lexer:

  - support for binary, octal, and hex numbers using prefix 0b, 0o, and 0x.
    Support for grouping of digits using '_' as in 'ichiOku := 1_0000_0000',
    groups must be equal in size and at least two digits long.

- flang.dev

  - added idioms # 32, 41

  - added design page on integer literals / constants.

## 2021-05-20: V0.042

- lib

  - add string.parseI32*, parseU32*, etc to parse integers from decimal,
    binary, octal or hex numbers.  Very nice generic implementation for
    all integers in one feature!

  - added error.fz for an error condition

  - added outcome.fz similar to Rust's result: a choice between a value and an
    error.

- flang.dev

  - added idioms # 18, 22, 26, 27, 34, 42

## 2021-05-19: V0.041

- flang.dev

  - added idioms # 8, 9, 13, 16, 19

- lib

  - added array.reverse, list.reverse

  - added fuzion.std.panic

  - added map as parent of hashMap and orderedMap, defines keys, values, items

  - added Option/array/list.asString

- front end

  - fix#9: AdrToValue.type() was not intern()ed.

## 2021-05-18: V0.040

-lib

  - added features partiallyOrdered and ordered and implemented ordered by
    numeric and string.

  - added feature hasHash and implemented it for numeric and string.

  - added hashmap and orderedMap.

  - added psMap and psSet to have well behaved persistent sets and maps for
    ordered values.

  - added highestOneBit and trailingZeros to i32/i64/u32/u64

- C backend

  - add support for indentation in generated code.

## 2021-04-20: V0.039

- C backend

  - now works with array initialization using '[a, b, c]'.

- flang.dev

  - updated examples to use array initialization instead of InitArray.fz

  - new design of main page using CSS magic.


## 2021-04-20: V0.038

- Fuzion language

  - Support for array initialization using '[a, b, c]' or '[e; f; g]' where the
    array elements are expressions.  The array type is either inferred from the
    union of the types of the element expressions or propagated back from the
    target the array is assigned to.  Boxing and Tagging for array elements is
    automatic.  Support in FUIR/C backend missing, only interpreter for now.


## 2021-04-14: V0.037

- Fuzion language

  - match statement:

   - now infers actual generics if this does not lead to ambiguity. So one can,
     e.g., match a 'list<string>' against 'Cons' instead of 'Cons<string,
     list<string>>'.

   - Errors are created if a case does not match anything, matches several types
     or if some cases are missing

- lib

  - bitset.fz provides persistent bitsets

  - array.fz is a persistent array now, i.e., array.put(index, value) creates a
    new array.

  - stream.map, stream.fold added

  - numeric.min, numeric.max added


## 2021-04-08: V0.036

- lib

  - array.fz is immutable now, new feature marray.fz provides mutable arrays.

- Fuzion Language:

  - Field initialization 'f type := value', instance decomposition
    '(a i32, b bool) := obj' and array writes 'a[i] := v' now use ':='
    instead of '='.

## 2021-04-07: V0.035

- Fuzion Language:

  - Assignments are no longer accepted in the format 'a = b'. Instead, an assignment
    must be of the form

      set a := b

    to make sure that mutations are clearly visible in the source code.

## 2021-04-06: V0.034

- Fuzion Language

  - identifiers now may consist of non-ASCII code points of Unicode categories
    LC, Ll, Lm, Lo, Lt, Lu, Nd, Nl, and No, while the first character may not be
    of one of the numeric types No, Nl, No.

  - operartors now may consist of non-ASCII code points of Unicode categories
    Sc, Sk, Sm, So.

- tools:

  - fz tool now supports command line options -verbose, -debug, -safety,
    -unsafeIntrinsics

  - 'fz' now can be used giving a source file name as in 'fz Hello.fz'.

  - 'fz -latex' creates a LaTeX style for Fuzion source code.

## 2021-03-29: V0.033

- lib

  - added list.fold, list.take, added predefined monoids to numeric ands string.

  - renamed FALSE.fz and TRUE.fz to avoid name clashes on case-insensitive file
    systems.

## 2021-03-25: V0.032

- Fuzion Language:

  - Constant string now allow embedded identifiers using $id and embedded
    expressions using {expr}.

  - Constant strings now support escape sequences:
    | Esc sequence |  result | unicode |
    |------|-------|---------|
    | '\b' |  BS   | 0x08    |
    | '\t' |  HT   | 0x09    |
    | '\n' |  LF   | 0x0a    |
    | '\f' |  FF   | 0x0c    |
    | '\r' |  CR   | 0x0d    |
    | '\"' |  "    | 0x22    |
    | '$'  |  $    | 0x24    |
    | '\'' |  '    | 0x27    |
    | '\\' |  \    | 0x5c    |
    | '\{' |  {    | 0x7b    |
    | '\}' |  }    | 0x7d    |

## 2021-03-19: V0.031

- C backend

  - function to compile one whole feature is pure now

- tests

  - Makefiles now run tests using c backend in addition to interpreter

## 2021-03-18: V0.030

- C backend

  - support for postconditions

## 2021-03-17: V0.029

- C backend

  - support for choice types of unit types and one reference type, (e.g.,
    Option<T>). These do not require a tag since the unit types can be encoded
    as a special pointer value.

  - support for preconditions

## 2021-03-16: V0.028

- AST/IR/BE:

  - Tagging a value when assigned to a choice type is now done explicitly by an
    IR command Tag.  This no longer happens implicitly as part of an assignment,
    simplifying the IR and backends.

- C backend

  - fix handling of boxed unit

- Parser

  - a field with formal generics or formal arguments is now disallowed as early
    as during the parsing step.

## 2021-03-15: V0.027

- IR

  - now distinguishes instantiated from called clazzes resulting in less code
    generated by C backend

- C backend

  - support for arrays of arbitrary types

  - support for fields declared in universe

## 2021-03-11: V0.026

- C backend:

  - loads of clean-up and simplifications

  - bug fixes for dynamic calls and write accesses to outer fields

## 2021-03-10: V0.025

- C backend:

  - implemented match for non-ref values (i.e, values that distinguished by tag
    and not by a type check).

- Benchmarks:

  - added c_man_or_boy, a benchmark that compiles a the man_or_boy example to C

## 2021-03-09: V0.024

- Desgn:

  - Added section "Automatic global data" in the file
    design/monadic_lifting.html to propose monadic parameters together with
    automatic monadic lifting of callers of features with these monadic
    parameters as a solution for global state (and much more).

- C backend:

  - Choice types make progress: C structs defined, assignment to choice type is
    implemented, match statement is still missing.

  - fixed dynamic calls that did not work to call inherited feature.

## 2021-03-05: V0.023

- Design

  - added 'Feature Kinds' section with very detailed comparison of the
    capabilities of constructors, routines, fields, intrinsics, abstracts and
    choices.  Includes example code for uses of each feature kind in different
    scenarios.

- C backend:

  - several bug fixes and improvements.

## 2021-03-02: V0.022

- C backend

  - Compiles and runs HelloWorld without any warnings during Fuzion to C
    compilation and during C to machine code compilation.

  - added intrinsics for i32, i64, u32, u64.

- IR/FUIR/C backend:

  - code cleanup


## 2021-02-24: V0.021

- IR:

  - no longer creates 'impossible' clazzes such as integer<i32>.infix + when there is no
    instance of integer<i32> created anywhere. So C backend does not need to filter these
    out.

  - some normalization of clazzes to reduce total number of clazzes and amount of code.

- lib:

  - monad.fz added for experiments.

## 2021-02-22: V0.020

- lib:

  - choice.fz now comes with detailed explanation of sum types

  - Tuple.fz now comes with a detailed explanation of product types.

  - new list.fz and Cons.fz provide abstract list framework

- ir:

  - removed several ways that clazzes that cannot exists at runtime such as
    could be created, e.g., 'integer<i32>.ref decimalStr', which should be
    'i32.ref deciamStr'.

## 2021-02-18: V0.019

- lib:

  - added unit.fz as a standard unit type and changed void.fz into a 'real' void
    type with no instances.

  - added monoid.fz and quantors.fz

  - added monadic 'bind' operators to Option and numOption, re-implemented numOption
    using monads.

- front end:

  - added boxing of values of generic type and for implicit assignments to function result
    field.

  - internal cleanup with respect to types, removed internally used type t_ANY, replaced it
    by void.

## 2021-02-12: V0.018

- C backend:

  - The C backend successfully compiles a "HelloWorld" example now using the
    call

      fz -c HelloWorld

    which generates a HelloWorld.c file and then invokes clang -O3 to create a
    HelloWorld binary.

Benchmarks:

  - added c_hello, a benchmark that compiles a HelloWorld example to C


## 2021-02-07: V0.017

- Frotend:

  - Inspired by FOSDEM talks on Raku, I have decided to experiment with making
    the parentheses on calls optional. This means that instead of

      f(a, g(h(-b, c + d)))

    you can now write

      f a, g h -b, c + d

    To avoid ambiguity, a new keyword 'then' separates the condition in a
    single-line 'if'-statement from the following block and uninitialized fields
    can no longer be declared as

       f type

    but usng

       f type = ?

    An operator '<op>' in an expression like 'x <op> y' is now parsed as a
    prefix operator 'x(<op>y)' if there is white space or a comment between 'x'
    and '<op>' and no white space nor a comment between '<op>' and 'y', i.e,
    'a-b', 'a- b' and 'a - b' are all calling an 'infix -' on 'a' with argument
    'b', while 'a -b' calls 'prefix -' on 'b' and passes the result as first
    argument to 'a'.

- stdlib: new features

    'say' as shorthand for 'stdout.println'

    'integer.infix %%' to check if an integer is divisibly by another integer

- Tools

  - added simple syntax highlighting tool via 'fz -pretty'

- FUIR and C backend

  - lots of minor improvements


## 2021-02-01: V0.016

- Frontend:

  - all loops are now implemented using tail recursive features.  IR and backend
    support for loops has been removed.

  - fixed several problems with field visibility and masking in nested scopes.

- Interpreter

  - stack trace printing now compresses simple recursion.

- C backend

  - can compile simple tests including loops now.  Main missing features is
    references and dynamic binding

  - made code more readable by using identifiers closer to the original Fuzion
    feature names.

- General

  - error printing now uses ANSI escapes to produce colourful output.  Can be
    disabled via env var FUZION_DISABLE_ANSI_ESCAPES=true.

- Design

  - added page on static vs. dynamic typing


## 2021-01-12: V0.015

- Fuzion IR

  - extracted dynamic binding related code from Clazz.java to
    DynamicBinging.java.

- flang.dev

  - Removed access restrictions, made website and tutorial accessible without
    login.

  - Replaced Fusion by Fuzion at most locations.

- Design

  - Updated module dependencies with explicit backends, added dependency from
    optimizer to interpreter backend since the optimizer will need an engine to
    evaluate compile time constants and the interpreter should do a perfect job
    here.

- Fuzion Front End

  - Removed Loop from AST, a loop is now directly replaced by a tail recurive
    call.

  - Source file name extension is .fz now.

  - one line comments introduced with '#' can start in any column now.  Replaced
    '//' by '#' in the standard lib and examples.

- C backend

  - Compiles and runs first micro-HelloWorld, still many limitations.

      hw is
        fusion.std.out.write(72)
        fusion.std.out.write(87)
        fusion.std.out.write(10)

- Fusion tools

  - added proper command line handling to fusion command line tool, in
    particular -interpreter, -c, -llvm, etc. to chose backend.

## 2020-11-22: V0.014

- Fusion Middle End

  - improved smart linking: Do not include features that could be called
    dynamically but there is no corresponding dynamic call.

- Fusion Front End

  - replaced boolean prefix !, infix &&, infix || and infix : by corresponding
    if-statements to support lazy evaluation.

  - implemented simple constant propagation for bool constants.

  - Expressions of the form 'a <op1> b <op2> c' where 'a <op1> b' yields a bool
    result and '<op2>' is not defined as an infix operator on bool are now
    automatically converted to '(a <op1> { tmp := b; tmp }) && (tmp <op2> c'.
    This means that expressions such as '0 <= index < length' are now possible.

  - Renamed bool operator '==' as '<=>' to avoid confusion when comparing 3 bool
    variables using 'a == b == c' (which holds, e.g., for 'true == false ==
    false').  Maybe the front end should require parentheses as in '(a <=> b)
    <=> c' or '(a == b) == c' when 'a' is boolean to avoid confusion.  How is
    this done in other languages?

- Fusion tools

  - changed fusion.verbose property from boolean to integer, 0 is non-verbose,
    levels 1..10 show different levels of detail.

  - new properties fusion.debugLevel=<int> and fusion.safety=<bool> can be used
    to set the default values for debugLevel and safety (to enable or disable
    pre- and postcondition checks).

- tests

  - added test case redef_args to redefine argument fields.  Not working yet.

## 2020-11-16: V0.013

- Fusion Interpreter: No longer uses virtual call for a dynamic feature called
  on a value instance.

- middle end: Split up finding runtime clazzes and building virtual call tables
  into two phases.  No longer builds virtual call tables for value clazzes.

- Design

  - added page "Matches in Expressions" describing possible syntax of
    expressions using '?' to match the type of a value of choice type.

- removed "throws" keyword and its uses in feature declarations and
  pre/postconditions.

## 2020-11-13: V0.012

- Fusion Interpreter

  - fixed boxing of choice types (only the tag was copied, so values remained
    uninitialized).

- standard lib

  - added support for 2- and 3-dimensional arrays through features

          array<T>>(l1, l2,     fun (i32, i32, i32) T)
          array<T>>(l1, l2, l3, fun (i32, i32, i32) T)

    these inherit from the 1-dimensional array feature, so it maps the
    multi-dimensional array to a flat unidimensional array.

  - added feature numOption<T> as a pseudo-numeric result type of numeric's +?,
    -? and *? operations to allow expressions such as 'a *? b +? c'

  - moved code to create interval from i32/i64/u32/u64 into separate generic
    feature hasInterval to avoid code duplication.

- Fusion middle end: Major cleanup and some bugfixes in handling of outer
  features that showed up when writing hasInterval.

## 2020-11-10: V0.011

- website

  - added tutorial pages on integer type, overflows, fractions.

- Fusion Interpreter

  - now catches StackOverflowError and shows fusion stack trace instead of Java
    stack trace

- Added prefix $ as an alternative to .asString.  Now, you can write '$length +
  "cm"' to create a string like "23cm".

- added overflowing, optional, saturating and wrapping basic operations to
  integer types:

   +  , -  , *   cause runtime error (if debug enabled) on overflow / underflow
   +? , -? , *?  produce an Option that is nil in case of overflow / underflow
   +^ , -^ , *^  are saturating, result is max / min on overflow / underflow
   +° , -° , *°  are wrapping, like in Java

- Nice exercise in generic programming: Added asString feature to
  integer to replace specific implementation in heirs i32, u32, i64 and u64.

- operator precedence: Now, prefix operators always take precedence over infix
  operators, i.e., 'a + + b' is parsed as 'a + (+ b)'.  Precedence is taken into
  account, i.e. 'a * + * b' is parsed as '(a *) + (* b)', while 'a + * + b' is
  parsed as 'a + (* (+ b))'.  Infix operators are parsed left-to-right except for
  operators with right associativity (currently only '^').  Postfix operators
  have precedence over prefix operators with equal precedence value, i.e, '+a-'
  is parsed as '+(a-)'.

  The precedence of multi-character operators such as '|-*-|' is determined by
  the first character, '|' in this case.  Precedence levels currently are

   15: @
   14: ^
   13: !$ (only prefix and postfix)
   12: ~
   11: */%⊛⊗⊘⦸⊝⊚⊙⦾⦿⦸⨸⨁⨂⨷
   10: +-⊕⊖
    9: .
    8: #
    7: $ (only infix)
    6:
    5: <>=⧁⧀⊜⩹⩺⩹⩺⩻⩼⩽⩾⩿⪀⪁⪂⪃⪄⪅⪆⪇⪈⪉⪊⪋⪌⪍⪎⪏⪐⪑⪒⪓⪔⪕⪖⪗⪘⪙⪚⪛⪜⪝⪞⪟⪠⪡⪢⪤⪥⪦⪧⪨⪩⪪⪫⪬⪭⪮⪯⪰⪱⪲⪴⪵⪶⪷⪸⪹⪺⪻⪼⫷⫸⫹⫺
       ! (only infix)
    4: &
    3: |⦶⦷
    2: ∀
    1: ∃
    0: all other operators
   -1: :

  this list is a little arbitrary, is there some mathematical precedence
  definition related to the mathematical unicode chars?

- added new keyword "redef" as alternative to "redefine" (will eventually dump
  'redefine'.

- Fusion std library: Added abstract features numeric and integer as parents for
  integer types. For integer types i32, u32, i64, u64 added preconditions to
  catch overflows.  Added fraction type: 'a /-/ b' for a, b of any (but the
  same) integer type defines a fraction that can be used with all the standard
  operations defined for numeric types.

- Enabled support for generic constraints. A generic feature declared as "name<T
  : c>(args ..)" puts the constraint c on the generic argument T. NYI: Still
  need to check that the actual generic arg is assignable to the constraint.

- '°' is now a legal character in an operator. New operators +°, -° and *°
  implement wrap-around operations, while +, - and * have preconditions that
  ensure there is no overflow.

- Created Slack channel #fusion-language:
  https://join.slack.com/t/fusion-zentrale/shared_invite/zt-j9ab7feo-3fl2oZLBfnKdyfOaDgvnjg

- Added types i64, u32, u64 and numeric, made i32, i64, u32 and u64 inherit
  from numeric.

- Removed "throws" clause from the syntax of feature and function declaration, I
  do not intend to support exception: An exception must either be part of the
  function result, so it should go there, or it is a fatal error that kills (at
  least) the current thread.

- Fusion Interpreter

  - added specialization for reading fields in value type to improve performance

## 2020-11-06: V0.010

- benchmarks: Added first simple performance benchmark that runs the man_or_boy
  example repeatedly.

- replaced abstract and native modifiers by specific routine bodies "is
  abstract" and "is intrinsic". This avoids the problem of marking a field
  abstract or intrinsic.

- website

  - update tools module design (dependency graph)

- Fusion Interpreter

  - split code into two packages dev.flang.ast and dev.flang.be.interpreter.
    Removed dependencies from ast to be.interpreter, the dependencies from
    be.interpreter to ast will have to be changed to refer to fuir (once it
    exists.

## 2020-11-03: V0.009

- website

  - added Fusion grammer fusion.ebnf linked from the main page.

  - Fusion Tutorial

    - added sections on Design by Contract, developing with pre- and
      postconditions, predefined pre- and postcondition qualifiers.

- pre- and postconditions for single features are supported now.  A failing
  condition causes termination of the Fusion interpreter with an error message
  and a (Fusion!) call stack.

- Condition qualifiers have been added to control execution of pre- and
  postconditions: safety, debug, debug(i32), pedantic, analysis.

- new boolean operator "infix :", which implements "implies" ((a : b) <==> !a ||
  b). ':' has lowest precedence now, such that preconditions of the form

    pre
      safety: index < length

  are possible now.

- new keywords "pre", "post", and "inv" as alternatives for "require", "ensure",
  and "invariant". The latter might get retired soon.

- i32.infix / and i32.infix % now check that other != 0 via a pre-condition
  qualified with safety.

- new fields i32.max and i32.min to get the max/min value an i32 can hold.  A
  bit strange: Since i32 is a value type, we need an i32 to get the constant
  maximum value, e.g., 0.max == i32(-123).max == array.length.max.

- inline functions (lambdas declared with "fun (args) ...") now use the same
  syntax for their implementation as routine definititions: "is" block, "=>"
  block or a block enclosed in { }.

## 2020-11-01: V0.008

- website

  - Added "How to Support Fusion" page.

  - Added Rosetta Code Fibonacci example, updated other Rosetta Code examples to
    use indentation based blocks.

  - updated the idioms to use indentation instead of { }.

- Fusion language

  - ifstmnt and loop are expr now, not stmnt. This means they can be used
    directly as expressions, it is no longer needed to put them into { } to use
    them as a value.

  - added else and until as block ending tokens such that single line blocks
    that end with else or until no longer need to be enclosed in { }.

- Fusion Front End

  - Removed redundent directory listing in source dirs to improve speed.

## 2020-10-29: V0.007

- scopes for match cases: features declared in match cases are now visible only
  in the match case they were declared in.  In particular, the same variable
  name can be reused for the value we are matching.

- Fusion Tutorial

  - updated the examples in the tutorial to use indentation instead of { }
    whenever possible.  Added a copy of the tutorial with the original examples
    as "Fusion Tutorial using { }", linked from the main page.

- blocks no longer need to be enclosed by { }.  Routine declarations without { }
  require the new keyword 'is' before their code block.

- match statement no longer needs to be enclosed by { }. The right side of a
  case in a match statement is no longer an expr, but a block.  Cases are no
  longer separated by comma, but by semicolons or flat line breaks. This means
  that { } are no longer needed if line breaks and proper indentation is used.
  Single-line match clauses are a bit awkward, though, requiring { } and ';':

    v := match x a => { p; q }; b => { r; s }

  is equivalent to

    v := match x a => p; q
                 b => r; s

  is equivalent to

    v := match x a =>
                   p
                   q
                 b =>
                   r
                   s

- expressions

  - expressions are now restricted to a single line with the following
    exceptions:

    - an expression within parentheses ( ) or crochets [ ] may extend over
      several lines

    - a statement sequence within braces { } used as an expression may extend
      over several lines

    - a dot expression abc.def can have a line break before the dot.

- semicolons

  - semicolons between statements are now required for subsequent statements in
    the same block if they are in the same source line, semicolons are optional
    if statements are separated by a flat line break.

- Fusion design pages

  - Added much more detail to Blocks and Indentation page

  - Added page to Fusion toolchain modules

- Fusion Interpreter

  - improved performance by

    - caching interned types

    - checking and caching which types do not depend on generics,
      such that their actual type is always the same.

    - disabling pre- and postconditions in production (enabled by setting env
      variables PRECONDTIONS=true and POSCONDITIONS=true)

## 2020-10-22: V0.006

- feature declarations and visibility

  - field declarations using := can now mask previously declared fields with the
    same name.

  - features in unqualified accesses are now searched taking the scope
    visibility into account.

- a.b.this expression now produces a proper error message if a.b is not found.

- Fusion Interpreter

  - When processing input from stdin (which is used when clicking "run" on the
    website examplex), the interpreter now parses stmnts and not feature.  If
    input is a single statement that is a feature declaration, that feature will
    be executed as before. Otherwise, these statements will be added to the
    internal feature --universe-- and this will be executed.  This has the
    effect that many small examples no longer need a surrounding feature, e.g.,
    'stdout.println("Hello, World!")' can be executed directly now and Fusion
    scripts with shebang are possible.

  - uninitialized non-ref values are not initialzed with -555555555 to be more
    obvious when used.  DFA to detect possible uninitialized accesses is still
    not supported.

- Fusion design pages

  - Added page on visibility.

  - Extended page on strings with section on text blocks and converted it from
    wiki to html.

  - added sections on coroutines, light-weight threading, SIMD and fuom, the
    Fusion Optimizer.

- Loops

  Slight change in semantics: 'for i := <expr> do .. ' is now interpreted as
  "for i := <expr>, <expr> do .. ' and it is not allowed to assign a value to i
  anywhere else. This allows the following pattern

    for data := read()
    while data >= 0
      {
        process(data)
      }

- comments

  - New type of comments enabled: '#' as first codePoint in a line starts a
    comment that extends to the end of this line.  Now we can run fusion codes
    like scripts by starting the file with shebang, e.g.,

       #!/bin/fusion.sh

       stdout.println("Hello, World!");

    if fusion.sh starts the fusion interpreter.

  - Fixed bug in Lexer that disallowed '/' in operators. Now, operators such as
    infix -/*^-^*/- are allowed, this does not contain a comment.

- Errors

  - In case of compilation errors, suppress certain subsequent errors:

     - wrong type if if/while/until expression if type is t_ERROR,

     - missing result type in field declaration if field name is
       Lexer.ERROR_STRING (indicating a parsing error),

     - expected EOF in case of previous errors

## 2020-10-14: V0.005

- Benchmarks

  - added simple infrastructure for daily run benchmarks, accessible through the
    website.  There is currently no dedicated server to run the benchmarks, so
    there will be jitter, but this should do for now.

- Fusion Interpreter

  - Added checks that the main feature is not a field, is not abstract, not
    native and not generic such that this produces a proper error message
    instead of a Java exception.

- Fusion frontend

  - overloading for features:

    A feature may now be overloaded in the number (not the type!) of its
    arguments.  In particular, there are two features stdout.println now, one
    with no argument and one that expects a ref Object argument.

    This change also added infrastructure that will be needed for Eiffel-style
    renaming of inherited features.

  - initial assignments to fields are no longer allowed unless the field is
    declared within the code of an outer routine.  In particular, x := <expr>
    does not work. This code was never executed anyway and I do not want to
    leave the execution order as a arbitray decision of the implementation.

- Fusion library

  - renamed 'fusion.std.out.printline' as 'println', overloading the existing
    'println(ref Object)'.

  - In 'i32.infix..': Added feature 'lower' and renamed 'other' as 'upper' for
    convenience.  Extended 'infix :' to support negative steps to iterate from
    'lower' down to 'upper' (i.e, it requires 'lower >= upper'), e.g.,
    '10..0 : -1' counts from 10 down to 0.

  - added 'string.infix *' to repeat a string a given number of times.

- Fusion design pages

  - added page on blocks using braces vs. indentation

  - added page on semicolon and how and when it could be made optional

  - changed overloading page from wiki markup to html and added section on
    argument count overloading.

  - changed inheritance page from wiki markup to html and added section on
    multiple inheritance, conflicts during inheritance and possible solutions to
    resolve these conflicts.

  - added page on assignment syntax

  - added page on file name extensions

- webserver

  - improved logging

## 2020-10-05: V0.004

- lexer

  - fixed crash when comment following >>//<< ends with end-of-file instead of
    new line.

- webserver

  - added more examples to idioms 1, 12, 17, 20, 21, changed getRed into just red
    in the tutorial's match examples (Java's getter/setter frenzy apparently
    found its way deep into my unconsciousness).

  - removed user ids for logged in users, they are not needed.

- lib

  - removed Null.fu

## 2020-10-02: V0.003

- webserver

  - added pages to implement the idioms from programming-idioms.org

  - index.html template: Added 3sec timeout to reconnect EventSource in case no
    server response was encountered.  This seamms to work better than the
    previous solution of reconnecting if more than 3 requests were left without
    reply, but I am still unhappy about this manual reconnect.

- loops

  - if a loop that may succeed or fail has a VOID result type is used as an
    expression and type propagation asks it to be of type boolean, then the loop
    will result in true on successful termination (until condition is true) or
    false (otherwise: iteration was exhaustive or while condition is false).

  - index Vars now may be updated in the loop body if their declaration in the
    for-clause does not define a value for the next iteration.

  - added compiler checks that while- and until-conditions are actually boolean,
    so we now get a compile-time error instead of a runtime crash

  - added type propagation: The while- and until-conditions are expected to be
    of type bool.

- if statement

  - added compiler checks that if-conditions are actually boolean, so we now get
    a compile-time error instead of a runtime crash

  - added type propagation: The condition of an if-statement is expected to be
    of type bool.

- compile time errors

  - the front end no longer stops after a phase has shown errors but tries to
    continue until it would execute the application.  This might cause
    subsequent errors or even crashes, but it will help to make the front end
    more robust.

- abstract features

  - added runtime error that checks that with one or several abstract inner
    feature are called unless there are no calls to the abstract feature. No
    fancy data-flow analysis is done yet, so the following code

      f {
       x { abstract y }
       z : x { redefine y { } }
       x;
       r ref x = z;
       r.y;
      }

    does not compile even though the only call to y is in an instance of z.

  - added compile-time errors for the case that a feature with an implementation
    is marked as abstract

## 2020-09-30: V0.002

- renamed intrinsic features for reference comparison as >>infix ===<< and
  >>infix !==<< to avoid type errors when redefined in i32 and bool.

- Added checks that redefined features match the argument and result types of
  the original features. No variance for argument types allowed (so far),
  covariance allowed for ref result type.

- removed types int and String and last uses of int in testsuite, i32/string are
  used instead.


## 2020-09-29: V0.001

- First version to be presented to very few selected users via the flang.dev website.
