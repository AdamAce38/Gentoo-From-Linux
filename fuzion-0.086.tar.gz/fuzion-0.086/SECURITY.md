# Security Policy

## Supported Versions

There are no supported versions yet!

| Version  | Supported          |
| -------  | ------------------ |
| 0.081dev | :x:                |

## Reporting a Vulnerability

You can report vulnerabilities via Github or by sending an E-Mail to: info@tokiwa.software
