The documentation for `shard.yml` has moved to [`docs/shard.yml.adoc`](docs/shard.yml.adoc).
