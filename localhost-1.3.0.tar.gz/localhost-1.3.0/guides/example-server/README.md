# Example Server

This guide demonstrates how to use {ruby Localhost::Authority} to implement a simple HTTPS client & server.
