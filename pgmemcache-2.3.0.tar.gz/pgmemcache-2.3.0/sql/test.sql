\i test.sql
