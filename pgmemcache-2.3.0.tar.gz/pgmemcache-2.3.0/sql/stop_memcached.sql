\! kill `cat $HOME/.pgmemcache-memcached.pid`
