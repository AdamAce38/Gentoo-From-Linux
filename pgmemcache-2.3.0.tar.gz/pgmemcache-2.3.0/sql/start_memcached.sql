\! memcached -p 33211 -P $HOME/.pgmemcache-memcached.pid -d
