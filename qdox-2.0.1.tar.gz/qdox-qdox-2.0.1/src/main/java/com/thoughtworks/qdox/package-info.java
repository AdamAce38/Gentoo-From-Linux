/**
 * Provides classes to start constructing a java project
 */
package com.thoughtworks.qdox;