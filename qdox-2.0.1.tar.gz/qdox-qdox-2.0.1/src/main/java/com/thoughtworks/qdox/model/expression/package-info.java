/**
 * Provides classes reflecting the Java expressions.
 */
package com.thoughtworks.qdox.model.expression;