/**
 * Provides the default implementation of the classes which transform the structs from the JavaParser to the Java model elements
 */
package com.thoughtworks.qdox.builder.impl;