/**
 * 
 */
package com.thoughtworks.qdox.tools;