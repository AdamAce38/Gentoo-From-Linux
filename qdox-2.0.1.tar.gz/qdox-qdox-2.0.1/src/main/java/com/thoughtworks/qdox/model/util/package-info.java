/**
 * Provides utility classes supporting the construction of the models
 */
package com.thoughtworks.qdox.model.util;