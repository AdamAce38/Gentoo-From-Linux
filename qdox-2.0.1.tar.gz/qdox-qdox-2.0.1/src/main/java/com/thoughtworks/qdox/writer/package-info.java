/**
 * Provides classes to write Java model elements in any style 
 */
package com.thoughtworks.qdox.writer;