package com.thoughtworks.qdox;

public class EmptyTestClasses {

}
class Spoon {}
class Fork {}
class Knife {}