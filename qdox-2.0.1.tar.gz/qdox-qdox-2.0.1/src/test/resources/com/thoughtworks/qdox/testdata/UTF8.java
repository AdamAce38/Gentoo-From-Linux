package com.thoughtworks.qdox.testdata;

/**
 * TEST-CHARS: ßıΣЯא€
 */
public class UTF8 {
    
    
}