module qdoxtest
{
  exports com.thoughtworks.qdox;
}