package com.thoughtworks.qdox.testdata;

class Unicode {
    String x = "\u0000";
}
