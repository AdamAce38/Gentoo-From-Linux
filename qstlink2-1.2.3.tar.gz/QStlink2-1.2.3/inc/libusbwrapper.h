#ifndef LIBUSBWRAPPER_H
#define LIBUSBWRAPPER_H

#include <QObject>

class libusbwrapper : public QObject
{
public:
    libusbwrapper();
};

#endif // LIBUSBWRAPPER_H
