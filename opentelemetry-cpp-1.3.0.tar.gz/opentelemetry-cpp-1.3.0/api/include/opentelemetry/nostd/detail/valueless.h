#pragma once

#include "opentelemetry/version.h"

OPENTELEMETRY_BEGIN_NAMESPACE
namespace nostd
{
struct valueless_t
{};
}  // namespace nostd
OPENTELEMETRY_END_NAMESPACE
