.. title:: CastXML Documentation

Command-Line Tools
##################

.. toctree::
   :maxdepth: 1

   /manual/castxml.1

.. only:: html

 Index and Search
 ################

 * :ref:`genindex`
 * :ref:`search`
