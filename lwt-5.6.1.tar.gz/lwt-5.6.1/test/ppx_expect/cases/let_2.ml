let _ =
  let%lwt () = Lwt.return () in
  ();;
