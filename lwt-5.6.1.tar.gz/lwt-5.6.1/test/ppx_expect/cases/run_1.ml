(* On one line for error message compatibility with 4.09. *)
let%lwt () = Lwt.return ()
