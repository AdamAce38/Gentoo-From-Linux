# frozen_string_literal: true

require 'forwardable'
require 'faraday/encoders/nested_params_encoder'
require 'faraday/encoders/flat_params_encoder'
