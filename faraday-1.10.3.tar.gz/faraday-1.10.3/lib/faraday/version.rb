# frozen_string_literal: true

module Faraday
  VERSION = '1.10.3'
end
