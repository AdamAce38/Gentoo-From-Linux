export function log(x) {
  console.log(x);
}
