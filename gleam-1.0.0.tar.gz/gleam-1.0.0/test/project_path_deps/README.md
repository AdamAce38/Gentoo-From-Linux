This directory contains four projects used in CI test `test/project_path_deps`.

The dependency graph of these projects is as follows:

```
         _-> project_b -_
        /                v
project_a                project_d
        \                ^
         '-> project_c -'
```

