export function main() {
  console.log("Hello");
}
