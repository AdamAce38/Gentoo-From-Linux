# external_only_javascript

A project that can only be run on JavaScript due to an external function.
