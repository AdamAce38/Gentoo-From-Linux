export function append(a: string, b: string) {
  return a + b;
}
