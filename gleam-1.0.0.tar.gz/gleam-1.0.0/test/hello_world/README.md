hello_world
=====

An OTP library

Build
-----

    $ rebar3 compile
