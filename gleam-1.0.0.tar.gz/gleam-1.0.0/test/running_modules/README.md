# Running Modules

Tests running modules with the `gleam run -m` command on all targets and runtimes.
The `test` directory is required for gleeunit to run in the running a dependency
module tests.
