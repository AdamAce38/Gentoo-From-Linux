# external_only_erlang

A project that can only be run on Erlang due to an external function.
