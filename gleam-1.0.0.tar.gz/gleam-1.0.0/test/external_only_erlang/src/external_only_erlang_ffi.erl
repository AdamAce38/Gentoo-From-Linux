-module(external_only_erlang_ffi).
-export([main/0]).

main() ->
    io:format("Hello!\n", []).
