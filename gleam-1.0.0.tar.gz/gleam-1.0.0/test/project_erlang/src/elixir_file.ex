defmodule ElixirFile do
  def main() do
    "Hello, from the Elixir module!"
  end
end

defmodule ElixirFileAgain do
  def main() do
    "Hello, from another Elixir module!"
  end
end
