defmodule ElixirTestFile do
  def main() do
    "Hello, from the Elixir test module!"
  end
end
