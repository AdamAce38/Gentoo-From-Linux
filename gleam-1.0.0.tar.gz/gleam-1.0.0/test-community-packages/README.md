# test_community_packages

[![Package Version](https://img.shields.io/hexpm/v/test_community_packages)](https://hex.pm/packages/test_community_packages)
[![Hex Docs](https://img.shields.io/badge/hex-docs-ffaff3)](https://hexdocs.pm/test_community_packages/)

```sh
gleam add test_community_packages
```
```gleam
import test_community_packages

pub fn main() {
  // TODO: An example of the project in use
}
```

Further documentation can be found at <https://hexdocs.pm/test_community_packages>.

## Development

```sh
gleam run   # Run the project
gleam test  # Run the tests
gleam shell # Run an Erlang shell
```
