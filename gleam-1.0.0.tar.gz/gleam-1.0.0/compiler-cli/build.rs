fn main() {
    static_vcruntime::metabuild();
}
