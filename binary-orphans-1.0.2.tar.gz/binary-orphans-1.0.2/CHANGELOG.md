# 1.0.2

- Add `Solo` instance

# 1.0.1

- Fix `MonadFail` instances shim
- `NonEmpty` doesn't fail on empty list

# 1

Stripped down the package to only shim `binary` orphans.

For more instances check [binary-instances](https://hackage.haskell.org/package/binary-instances) package.
