#!/usr/bin/sh

find .. -iname *.[hc]pp | sort > l10n_sources.txt
