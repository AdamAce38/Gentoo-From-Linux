/// QasTools: Desktop toolset for the Linux sound system ALSA.
/// \copyright See COPYING file.

#include "main_window_setup.hpp"

Main_Window_Setup::Main_Window_Setup ()
: show_dev_select ( true )
{
}
