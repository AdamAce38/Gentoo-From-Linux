/// QasTools: Desktop toolset for the Linux sound system ALSA.
/// \copyright See COPYING file.

#include "mixer_device_setup.hpp"

namespace MWdg
{

Mixer_Device_Setup::Mixer_Device_Setup () = default;

Mixer_Device_Setup::~Mixer_Device_Setup () = default;

} // namespace MWdg
