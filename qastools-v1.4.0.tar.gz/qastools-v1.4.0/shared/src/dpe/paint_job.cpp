/// QasTools: Desktop toolset for the Linux sound system ALSA.
/// \copyright See COPYING file.

#include "paint_job.hpp"

namespace dpe
{

Paint_Job::Paint_Job () {}

} // namespace dpe
