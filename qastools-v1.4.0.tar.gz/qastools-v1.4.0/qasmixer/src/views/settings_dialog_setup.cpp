/// QasTools: Desktop toolset for the Linux sound system ALSA.
/// \copyright See COPYING file.

#include "settings_dialog_setup.hpp"

namespace Views
{

Settings_Dialog_Setup::Settings_Dialog_Setup () = default;

Settings_Dialog_Setup::~Settings_Dialog_Setup () = default;

} // namespace Views
