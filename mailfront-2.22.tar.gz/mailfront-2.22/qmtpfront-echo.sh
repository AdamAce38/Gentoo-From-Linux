exec "$(dirname $0)"/mailfront qmtp echo "$@"
