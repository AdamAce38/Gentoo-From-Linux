#include "starttls.h"

const response* starttls_init(void)
{
  return 0;
}

int starttls_start(void)
{
  return 0;
}

int starttls_available(void)
{
  return 0;
}

void starttls_disable(void)
{
}
