exec "$(dirname $0)"/mailfront qmqp echo "$@"
