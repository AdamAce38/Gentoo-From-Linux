exec "$(dirname $0)"/mailfront smtp echo "$@"
