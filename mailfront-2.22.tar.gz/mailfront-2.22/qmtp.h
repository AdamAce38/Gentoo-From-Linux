#ifndef MAIL_FRONT__QMTP__H__
#define MAIL_FRONT__QMTP__H__

#include "responses.h"

extern int qmtp_respond_line(unsigned, int, const char*, unsigned long);

#endif
