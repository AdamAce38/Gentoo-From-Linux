
test = { geom_proj = 'latlong', area_proj = 'merc' }

dofile(os.getenv('SRCPATH') .. '/data/test_output_flex_area.lua')

