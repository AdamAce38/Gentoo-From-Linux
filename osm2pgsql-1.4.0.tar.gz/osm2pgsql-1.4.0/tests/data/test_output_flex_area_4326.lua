
test = { geom_proj = 4326, area_proj = 4326 }

dofile(os.getenv('SRCPATH') .. '/data/test_output_flex_area.lua')

