
# osm2pgsql Documentation

This directory contains the [source code for the man page](osm2pgsql.md) and
the [compiled version](osm2pgsql.1) and the files necessary to create it.
Call `make man` to re-build the man page.

The documentation that used to be in this directory has been moved to
the [osm2pgsql manual](https://osm2pgsql.org/doc/manual.html) or to the
[examples](https://osm2pgsql.org/examples) on the website.

