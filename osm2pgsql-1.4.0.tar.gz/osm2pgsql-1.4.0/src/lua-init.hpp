#ifndef OSM2PGSQL_LUA_INIT_HPP
#define OSM2PGSQL_LUA_INIT_HPP

char const *lua_init() noexcept;

#endif // OSM2PGSQL_LUA_INIT_HPP
