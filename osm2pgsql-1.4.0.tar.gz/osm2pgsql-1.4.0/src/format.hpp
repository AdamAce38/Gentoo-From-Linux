#ifndef OSM2PGSQL_FORMAT_HPP
#define OSM2PGSQL_FORMAT_HPP

#define FMT_HEADER_ONLY
#include <fmt/format.h>

using namespace fmt::literals;

#endif // OSM2PGSQL_FORMAT_HPP
