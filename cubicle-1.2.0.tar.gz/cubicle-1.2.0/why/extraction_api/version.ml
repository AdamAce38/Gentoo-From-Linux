let version = "0.5"
let date = "Lun 5 mai 2014 10:01:21 CEST"
let libdir = "/usr/local/lib/cubicle"
