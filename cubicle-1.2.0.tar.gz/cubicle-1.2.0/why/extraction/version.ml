let version = "0.5"
let date = "lundi 26 août 2013, 09:16:20 (UTC+0200)"
let libdir = "/usr/local/lib/cubicle"
