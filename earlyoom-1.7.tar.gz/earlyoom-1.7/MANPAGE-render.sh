#!/bin/bash

make earlyoom.1
man ./earlyoom.1
