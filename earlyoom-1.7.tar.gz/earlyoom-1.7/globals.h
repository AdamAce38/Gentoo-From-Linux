/* SPDX-License-Identifier: MIT */
#ifndef GLOBALS_H
#define GLOBALS_H

extern int enable_debug;

extern char* procdir_path;

#endif
