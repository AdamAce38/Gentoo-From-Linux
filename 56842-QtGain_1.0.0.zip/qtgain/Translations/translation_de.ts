<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="de_DE">
<context>
    <name>CoverDownload</name>
    <message>
        <location filename="../src/coverdownload.cpp" line="186"/>
        <source>&lt;b&gt;Can&apos;t find cover artwork for &apos;%1&apos;&lt;/b&gt;&lt;br&gt;</source>
        <translation>&lt;b&gt;Kein Cover für &apos;%1&apos; gefunden&lt;/b&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../src/coverdownload.cpp" line="225"/>
        <source>Can&apos;t save cover: </source>
        <translation>Kann Cover nicht speichern: </translation>
    </message>
    <message>
        <location filename="../src/coverdownload.cpp" line="230"/>
        <source>Download error: </source>
        <translation>Download-Fehler: </translation>
    </message>
    <message>
        <location filename="../src/coverdownload.cpp" line="335"/>
        <source>Load another Cover</source>
        <translation>Anderes Cover laden</translation>
    </message>
    <message>
        <location filename="../src/coverdownload.cpp" line="339"/>
        <source>Delete Cover</source>
        <translation>Lösche Cover</translation>
    </message>
    <message>
        <location filename="../src/coverdownload.cpp" line="376"/>
        <source>Coverpreview %1/%2</source>
        <translation>Vorschau %1/%2</translation>
    </message>
</context>
<context>
    <name>Preferences</name>
    <message>
        <location filename="../src/Preferences.cpp" line="36"/>
        <source>Please select the MP3Gain binary</source>
        <translation>Bitte MP3Gain auswählen</translation>
    </message>
    <message>
        <location filename="../src/Preferences.cpp" line="38"/>
        <location filename="../src/Preferences.cpp" line="48"/>
        <location filename="../src/Preferences.cpp" line="58"/>
        <location filename="../src/Preferences.cpp" line="68"/>
        <location filename="../src/Preferences.cpp" line="78"/>
        <source>All Files (*)</source>
        <translation>Alle Dateien (*)</translation>
    </message>
    <message>
        <location filename="../src/Preferences.cpp" line="46"/>
        <source>Please select the aacgain binary</source>
        <translation>Bitte aacgain auswählen</translation>
    </message>
    <message>
        <location filename="../src/Preferences.cpp" line="56"/>
        <source>Please select the VorbisGain binary</source>
        <translation>Bitte VorbisGain auswählen</translation>
    </message>
    <message>
        <location filename="../src/Preferences.cpp" line="66"/>
        <source>Please select the Metaflac binary</source>
        <translation>Bitte Metaflac auswählen</translation>
    </message>
    <message>
        <location filename="../src/Preferences.cpp" line="76"/>
        <source>Please select the id3v2 binary</source>
        <translation>Bitte id3v2 auswählen</translation>
    </message>
</context>
<context>
    <name>PreferencesClass</name>
    <message>
        <location filename="../ui/Preferences.ui" line="32"/>
        <source>Settings</source>
        <translation>Einstellungen</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="62"/>
        <source>General</source>
        <translation>Allgemein</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="135"/>
        <source>Replay Gain Mode</source>
        <translation>Replay-Gain-Modus</translation>
    </message>
    <message>
        <source>Target volume</source>
        <translation type="obsolete">Lautstärke</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="100"/>
        <source>dB</source>
        <translation>dB</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="113"/>
        <source>Reset target volume to default value</source>
        <translation>Zurücksetzen der Lautstärke auf Standardwert</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="143"/>
        <source>AlbumGain</source>
        <translation>Album Gain</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="150"/>
        <source>TrackGain</source>
        <translation>Track Gain</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="173"/>
        <source>Quick options</source>
        <translation>Schnelleinstellungen</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="193"/>
        <source>Replay Gain all your media files.</source>
        <translation>Lautstärke bei allen Mediadateien anpassen.</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="196"/>
        <source>Replay Gain files</source>
        <translation>Lautstärke anpassen (Replay Gain)</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="209"/>
        <source>Autorename all media files with the stored ID3 tags within the files, this works only with MP3 files.</source>
        <translation>Alle Mediadateien automatisch umbenennen mittels der in den Dateien gespeicherten ID3Tag.</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="212"/>
        <source>Autorename MP3 files</source>
        <translation>Dateien automatisch umbenennen</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="222"/>
        <source>Autorename all folders with the stored ID3 tags, this works only with MP3 files.</source>
        <translation>Verzeichnisse automatisch umbenennen mittels der ID3Tags in den Mediadateien.</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="225"/>
        <source>Autorename folders which contains the MP3 files</source>
        <translation>Verzeichnisse automatisch umbenennen</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="235"/>
        <source>Download cover arts from the internet.</source>
        <translation>Automatisch Cover aus dem Internet laden, unter Extras kann eine Quelle ausgesucht werden.</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="238"/>
        <source>Download Cover Art</source>
        <translation>Cover automatisch aus dem Internet laden</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="255"/>
        <source>Opens a file dialog at startup where you can select folders.</source>
        <translation>Öffnet beim Start einen Dateidialog.</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="258"/>
        <source>Open a file dialog at startup</source>
        <translation>Dateidialog beim Start anzeigen</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="265"/>
        <source>Turn this on if you want that QtGain shows skipped files and errors in the log window.</source>
        <translation>Übersprungene Dateien in der Logdatei, nachdem alle Mediadateien bearbeitet wurden, anzeigen.</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="268"/>
        <source>Show skipped files in Errorlog</source>
        <translation>Übersprungene Dateien in der Logdatei anzeigen</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="275"/>
        <source>Quit QtGain automatically after finished all opening jobs.</source>
        <translation>QtGain automatisch nach Fertigstellung aller Arbeiten beenden.</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="278"/>
        <source>Quit QtGain after finished gaining</source>
        <translation>QtGain automatisch beenden</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="292"/>
        <source>MP3 Extras</source>
        <translation>MP3 Extras</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="362"/>
        <source>Download Cover Art from:</source>
        <translation>Quelle für Cover:</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="373"/>
        <source>Amazon.com</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="378"/>
        <source>Google Images Search</source>
        <translation>Google Bildersuche</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="298"/>
        <source>Song renaming scheme</source>
        <translation>Schablone zur Umbenennung von MP3-Dateien</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="70"/>
        <source>Target Volume</source>
        <translation>Ziel-Lautstärke</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="310"/>
        <source>%Artist, %Song, %Album, %Year, %Track, %Genre</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="317"/>
        <source>%Artist - %Song</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="327"/>
        <source>Folder renaming scheme</source>
        <translation>Schablone zur Umbenennung von Verzeichnissen</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="339"/>
        <source>%Artist, %Album, %Year, %Genre</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="346"/>
        <source>%Artist - %Album</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="404"/>
        <source>External Tools</source>
        <translation>Extern</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="428"/>
        <source>id3v2</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="451"/>
        <location filename="../ui/Preferences.ui" line="538"/>
        <location filename="../ui/Preferences.ui" line="616"/>
        <location filename="../ui/Preferences.ui" line="678"/>
        <location filename="../ui/Preferences.ui" line="733"/>
        <source>...</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="487"/>
        <source>Replay Gain Tools</source>
        <translation>Replay-Gain-Programme</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="515"/>
        <source>MP3Gain:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="593"/>
        <source>AACGain:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="655"/>
        <source>VorbisGain:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="717"/>
        <source>Metaflac:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="416"/>
        <source>id3v2, needed for Autorenaming/Cover Download</source>
        <translation>id3v2 (für Umbenennung und Cover-Download)</translation>
    </message>
</context>
<context>
    <name>QtGain</name>
    <message>
        <location filename="../src/QtGain.cpp" line="67"/>
        <source>About...</source>
        <translation>Über QtGain...</translation>
    </message>
    <message>
        <location filename="../src/QtGain.cpp" line="70"/>
        <source>&amp;Stop...</source>
        <translation>&amp;Abbrechen...</translation>
    </message>
    <message>
        <location filename="../src/QtGain.cpp" line="71"/>
        <source>Ctrl+S</source>
        <translation>Ctrl+A</translation>
    </message>
    <message>
        <location filename="../src/QtGain.cpp" line="74"/>
        <source>&amp;Configure</source>
        <translation>&amp;Konfiguieren</translation>
    </message>
    <message>
        <location filename="../src/QtGain.cpp" line="75"/>
        <source>Ctrl+C</source>
        <translation>Ctrl+K</translation>
    </message>
    <message>
        <location filename="../src/QtGain.cpp" line="81"/>
        <source>Donate</source>
        <translation>Spenden</translation>
    </message>
    <message>
        <location filename="../src/QtGain.cpp" line="84"/>
        <source>E&amp;xit</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/QtGain.cpp" line="85"/>
        <source>Ctrl+X</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/QtGain.cpp" line="368"/>
        <source>&lt;font color=&apos;red&apos;&gt;Not a valid media file&lt;/font&gt; :: %1&lt;br&gt;</source>
        <translation>&lt;font color=&apos;red&apos;&gt;Defekte Datei&lt;/font&gt; :: %1&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../src/QtGain.cpp" line="374"/>
        <source>&lt;font color=&apos;red&apos;&gt;Cannot read file&lt;/font&gt; :: %1&lt;br&gt;</source>
        <translation>&lt;font color=&apos;red&apos;&gt;Kann Datei nicht lesen&lt;/font&gt; :: %1&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../src/QtGain.cpp" line="380"/>
        <source>&lt;font color=&apos;red&apos;&gt;Cannot write file&lt;/font&gt; :: %1&lt;br&gt;</source>
        <translation>&lt;font color=&apos;red&apos;&gt;Kann Datei nicht speichern&lt;/font&gt; :: %1&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../src/QtGain.cpp" line="390"/>
        <source>&lt;font color=&apos;green&apos;&gt;File already gained -&gt; skipped&lt;/font&gt; :: %1&lt;br&gt;</source>
        <translation>&lt;font color=&apos;green&apos;&gt;Datei übersprungen, bereits angepasst&lt;/font&gt; :: %1&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../src/QtGain.cpp" line="400"/>
        <source>Scanning directories...</source>
        <translation>Lese Verzeichnisse ein...</translation>
    </message>
    <message>
        <location filename="../src/QtGain.cpp" line="480"/>
        <source>Please choose a directory</source>
        <translation>Bitte Verzeichnis wählen</translation>
    </message>
    <message>
        <location filename="../src/QtGain.cpp" line="503"/>
        <source>No media files found...</source>
        <translation>Keine Dateien gefunden...</translation>
    </message>
    <message>
        <location filename="../src/QtGain.cpp" line="597"/>
        <source>%Artist - %Album</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/QtGain.cpp" line="598"/>
        <source>%Artist - %Song</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/QtGain.cpp" line="615"/>
        <source>&lt;font color=red&gt;No replay gain tools found!&lt;/font&gt;</source>
        <translation>&lt;font color=red&gt;Keine externen Tools gefunden!&lt;/font&gt;</translation>
    </message>
    <message>
        <location filename="../src/QtGain.cpp" line="676"/>
        <source>&lt;h2&gt;%1&lt;/h2&gt;Replay Gain frontend for MP3Gain, VorbisGain, AACGain and Metaflac.&lt;br&gt;Uses id3v2 to rename files/folders of MP3 files.&lt;br&gt;Cover Arts Downloader via Amazon or Google Picture Search.&lt;br&gt;&lt;br&gt;(c) 2007-2014, Vegeta&lt;br&gt;&lt;br&gt;&lt;a href=&apos;http://qt-apps.org/content/show.php/QtGain?content=56842&apos;&gt;Website&lt;/a&gt;&lt;br&gt;&lt;br&gt;This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.&lt;br&gt;&lt;h4&gt;Thanks to the following translator(s):&lt;/h4&gt;%5&lt;h4&gt;Statistic:&lt;/h4&gt;QtGain has %2 files processed (%3 files were replay gained) since %4.</source>
        <translation>&lt;h2&gt;%1&lt;/h2&gt;Oberfläche für die Replay-Gain-Tools MP3Gain, VorbisGain, AACGain und Metaflac.&lt;br&gt;Benutzt id3v2 um Dateien und Verzeichnisse umzubennen.&lt;br&gt;Cover können über Amazon oder Google Bildersuche bezogen werden.&lt;br&gt;&lt;br&gt;(c) 2007-2014, Vegeta&lt;br&gt;&lt;a href=&apos;http://qt-apps.org/content/show.php/QtGain?content=56842&apos;&gt;Projektseite&lt;/a&gt;&lt;br&gt;&lt;br&gt;QtGain ist freie Software. Sie können es unter den Bedingungen der GNU General Public License, wie von der Free Software Foundation herausgegeben, weitergeben und/oder modifizieren, entweder unter Version 2 der Lizenz oder (wenn Sie es wünschen) jeder späteren Version.&lt;h4&gt;Dank an folgende Übersetzer&lt;/h4&gt;%5&lt;h4&gt;Statistik:&lt;/h4&gt;QtGain hat %2 Dateien untersucht (%3 Dateien wurden verarbeitet) seit %4.</translation>
    </message>
    <message>
        <source>About</source>
        <translation type="obsolete">Über QtGain...</translation>
    </message>
    <message>
        <source>&lt;h2&gt;%1&lt;/h2&gt;Replay Gain frontend for MP3Gain, VorbisGain, AACGain and Metaflac.&lt;br&gt;Uses id3v2 to rename files/folders of MP3 files.&lt;br&gt;Cover Arts Downloader via Amazon or Google Picture Search.&lt;br&gt;&lt;br&gt;(c) 2007-2014, Vegeta&lt;br&gt;&lt;a href=&apos;http://qt-apps.org/content/show.php/QtGain?content=56842&apos;&gt;Project page&lt;/a&gt;&lt;br&gt;&lt;br&gt;QtGain This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.&lt;br&gt;&lt;h4&gt;Thanks to the following translator(s):&lt;/h4&gt;%5&lt;h4&gt;Statistic:&lt;/h4&gt;QtGain has %2 files processed (%3 files were replay gained) since %4.</source>
        <translation type="obsolete">&lt;h2&gt;%1&lt;/h2&gt;Oberfläche für die Replay-Gain-Tools MP3Gain, VorbisGain, AACGain und Metaflac.&lt;br&gt;Benutzt id3v2 um Dateien und Verzeichnisse umzubennen.&lt;br&gt;Cover können über Amazon oder Google Bildersuche bezogen werden.&lt;br&gt;&lt;br&gt;(c) 2007-2014, Vegeta&lt;br&gt;&lt;a href=&apos;http://qt-apps.org/content/show.php/QtGain?content=56842&apos;&gt;Projektseite&lt;/a&gt;&lt;br&gt;&lt;br&gt;QtGain ist freie Software. Sie können es unter den Bedingungen der GNU General Public License, wie von der Free Software Foundation herausgegeben, weitergeben und/oder modifizieren, entweder unter Version 2 der Lizenz oder (wenn Sie es wünschen) jeder späteren Version.&lt;h4&gt;Dank an folgende Übersetzer&lt;/h4&gt;%5&lt;h4&gt;Statistik:&lt;/h4&gt;QtGain hat %2 Dateien untersucht (%3 Dateien wurden verarbeitet) seit %4.</translation>
    </message>
    <message>
        <location filename="../src/QtGain.cpp" line="724"/>
        <source>Errorlog</source>
        <translation>Fehlerlog</translation>
    </message>
    <message>
        <location filename="../src/QtGain.cpp" line="726"/>
        <source>Close</source>
        <translation>Schließen</translation>
    </message>
    <message>
        <location filename="../src/QtGain.cpp" line="747"/>
        <source>Operation aborted...</source>
        <translation>Abgebrochen...</translation>
    </message>
    <message>
        <location filename="../src/QtGain.cpp" line="747"/>
        <source>TrackGain finished!</source>
        <translation>TrackGain abgeschlossen!</translation>
    </message>
    <message>
        <location filename="../src/QtGain.cpp" line="747"/>
        <source>AlbumGain finished!</source>
        <translation>AlbumGain abgeschlossen!</translation>
    </message>
    <message>
        <location filename="../src/QtGain.cpp" line="747"/>
        <source>Operation finished!</source>
        <translation>Operation abgeschlossen!</translation>
    </message>
    <message>
        <location filename="../src/QtGain.cpp" line="785"/>
        <source>TrackGain in process...</source>
        <translation>TrackGain-Lautstärke anpassen...</translation>
    </message>
    <message>
        <location filename="../src/QtGain.cpp" line="785"/>
        <source>AlbumGain in process...</source>
        <translation>AlbumGain-Lautstärke anpassen...</translation>
    </message>
    <message>
        <location filename="../src/QtGain.cpp" line="837"/>
        <source>&lt;h2&gt;Donate&lt;/h2&gt;Thank you for your interest in donating money to the QtGain project to support further development.&lt;hr&gt;&lt;center&gt;You can donate via PayPal&lt;h4&gt;%1&lt;/h4&gt;or&lt;h4&gt;%2&lt;/h4&gt;by clicking on the above links.&lt;/center&gt;&lt;hr&gt;Thank you for your support!</source>
        <translation>&lt;h2&gt;Spenden&lt;/h2&gt;Vielen Dank für Ihr Interesse dieses Projekt zu unterstützen, Sie unterstützen damit direkt die weitere Entwicklung.&lt;hr&gt;&lt;center&gt;Sie können über PayPal&lt;h4&gt;%1&lt;/h4&gt;oder&lt;h4&gt;%2&lt;/h4&gt;spenden, indem Sie auf einen der Links klicken.&lt;/center&gt;&lt;hr&gt;Vielen Dank für Ihre Unterstützung!</translation>
    </message>
</context>
<context>
    <name>QtGainClass</name>
    <message>
        <location filename="../ui/QtGain.ui" line="35"/>
        <source>QtGain</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ui/QtGain.ui" line="278"/>
        <source>Gained:</source>
        <translation>Bearbeitet:</translation>
    </message>
    <message>
        <location filename="../ui/QtGain.ui" line="299"/>
        <location filename="../ui/QtGain.ui" line="332"/>
        <location filename="../ui/QtGain.ui" line="369"/>
        <source>0</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ui/QtGain.ui" line="311"/>
        <source>Skipped:</source>
        <translation>Überspr.:</translation>
    </message>
    <message>
        <location filename="../ui/QtGain.ui" line="348"/>
        <source>Error:</source>
        <translation>Fehler:</translation>
    </message>
    <message>
        <location filename="../ui/QtGain.ui" line="381"/>
        <source>Time:</source>
        <translation>Zeit:</translation>
    </message>
    <message>
        <location filename="../ui/QtGain.ui" line="402"/>
        <source>00:00:00</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ui/QtGain.ui" line="463"/>
        <source>Ready...</source>
        <translation>Bereit...</translation>
    </message>
    <message>
        <location filename="../ui/QtGain.ui" line="427"/>
        <source>Status</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ui/QtGain.ui" line="249"/>
        <source>Information</source>
        <translation>Informationen</translation>
    </message>
    <message>
        <location filename="../ui/QtGain.ui" line="69"/>
        <source>ToDo:</source>
        <translation></translation>
    </message>
    <message>
        <source>Files</source>
        <translation type="obsolete">Dateien</translation>
    </message>
</context>
<context>
    <name>renameFiles</name>
    <message>
        <location filename="../src/renamefiles.cpp" line="118"/>
        <source>Processing ID3-Tags...</source>
        <translation>Bearbeite ID3-Tags...</translation>
    </message>
    <message>
        <location filename="../src/renamefiles.cpp" line="148"/>
        <source>&lt;font color=&apos;red&apos;&gt;No ID3-Tag found -&gt; skipped&lt;/font&gt; :: %1&lt;br&gt;</source>
        <translation>&lt;font color=&apos;red&apos;&gt;Keine ID3-Tags gefunden -&gt; übersprungen&lt;/font&gt; :: %1&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../src/renamefiles.cpp" line="155"/>
        <location filename="../src/renamefiles.cpp" line="181"/>
        <source>%Track</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/renamefiles.cpp" line="156"/>
        <location filename="../src/renamefiles.cpp" line="182"/>
        <location filename="../src/renamefiles.cpp" line="198"/>
        <source>%Year</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/renamefiles.cpp" line="157"/>
        <location filename="../src/renamefiles.cpp" line="183"/>
        <source>%Song</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/renamefiles.cpp" line="158"/>
        <location filename="../src/renamefiles.cpp" line="184"/>
        <location filename="../src/renamefiles.cpp" line="199"/>
        <source>%Album</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/renamefiles.cpp" line="159"/>
        <location filename="../src/renamefiles.cpp" line="185"/>
        <location filename="../src/renamefiles.cpp" line="200"/>
        <source>%Artist</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/renamefiles.cpp" line="160"/>
        <location filename="../src/renamefiles.cpp" line="186"/>
        <location filename="../src/renamefiles.cpp" line="201"/>
        <source>%Genre</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../src/renamefiles.cpp" line="162"/>
        <source>&lt;font color=&apos;red&apos;&gt;Not all ID3-Tags found or not all tags are valid -&gt; skipped&lt;/font&gt; :: %1&lt;br&gt;</source>
        <translation>&lt;font color=&apos;red&apos;&gt;Nicht alle ID3-Tags gefunden oder nicht alle gültig -&gt; übersprungen&lt;/font&gt; :: %1&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../src/renamefiles.cpp" line="174"/>
        <source>&lt;font color=&apos;red&apos;&gt;Found &apos;to ignore&apos; pattern in ID3-Tags -&gt; skipped&lt;/font&gt; :: %1&lt;br&gt;</source>
        <translation>&lt;font color=&apos;red&apos;&gt;Ungültigen Pattern in ID3-Tag gefunden, übersprungen&lt;/font&gt; :: %1&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../src/renamefiles.cpp" line="191"/>
        <source>&lt;font color=&apos;red&apos;&gt;Could not rename file %1 to %2&lt;/font&gt;&lt;br&gt;</source>
        <translation>&lt;font color=&apos;red&apos;&gt;Kann Datei %1 nicht zu %2 umbenennen&lt;/font&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../src/renamefiles.cpp" line="230"/>
        <source>&lt;font color=&apos;red&apos;&gt;Skipped renaming of &apos;%1&apos;&lt;/font&gt;&lt;br&gt;</source>
        <translation>&lt;font color=&apos;red&apos;&gt;Umbenennung der Datei &apos;%1&apos; übersprungen&lt;/font&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../src/renamefiles.cpp" line="235"/>
        <source>&lt;font color=&apos;red&apos;&gt;Could not rename folder &apos;%1&apos; to &apos;%2&apos;&lt;/font&gt;&lt;br&gt;</source>
        <translation>&lt;font color=&apos;red&apos;&gt;Kann Verzeichnis &apos;%1&apos; nicht zu &apos;%2&apos; umbenennen&lt;/font&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../src/renamefiles.cpp" line="271"/>
        <source>Downloading Cover Artwork...</source>
        <translation>Suche Album-Cover...</translation>
    </message>
</context>
</TS>
