<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="cs_CZ">
<context>
    <name>CoverDownload</name>
    <message>
        <location filename="../src/coverdownload.cpp" line="186"/>
        <source>&lt;b&gt;Can&apos;t find cover artwork for &apos;%1&apos;&lt;/b&gt;&lt;br&gt;</source>
        <translation>&lt;b&gt;Nelze najít obal pro &apos;%1&apos;&lt;/b&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../src/coverdownload.cpp" line="225"/>
        <source>Can&apos;t save cover: </source>
        <translation>Nelze uložit obal: </translation>
    </message>
    <message>
        <location filename="../src/coverdownload.cpp" line="230"/>
        <source>Download error: </source>
        <translation>Chyba při stahování: </translation>
    </message>
    <message>
        <location filename="../src/coverdownload.cpp" line="335"/>
        <source>Load another Cover</source>
        <translation>Nahrát jiný obal</translation>
    </message>
    <message>
        <location filename="../src/coverdownload.cpp" line="339"/>
        <source>Delete Cover</source>
        <translation>Smazat obal</translation>
    </message>
    <message>
        <location filename="../src/coverdownload.cpp" line="376"/>
        <source>Coverpreview %1/%2</source>
        <translation>Náhled na obal %1/%2</translation>
    </message>
</context>
<context>
    <name>Preferences</name>
    <message>
        <location filename="../src/Preferences.cpp" line="36"/>
        <source>Please select the MP3Gain binary</source>
        <translation>Vyberte, prosím, spustitelný soubor MP3Gain</translation>
    </message>
    <message>
        <location filename="../src/Preferences.cpp" line="38"/>
        <location filename="../src/Preferences.cpp" line="48"/>
        <location filename="../src/Preferences.cpp" line="58"/>
        <location filename="../src/Preferences.cpp" line="68"/>
        <location filename="../src/Preferences.cpp" line="78"/>
        <source>All Files (*)</source>
        <translation>Všechny soubory (*)</translation>
    </message>
    <message>
        <location filename="../src/Preferences.cpp" line="46"/>
        <source>Please select the aacgain binary</source>
        <translation>Vyberte, prosím, spustitelný soubor aacgain</translation>
    </message>
    <message>
        <location filename="../src/Preferences.cpp" line="56"/>
        <source>Please select the VorbisGain binary</source>
        <translation>Vyberte, prosím, spustitelný soubor VorbisGain</translation>
    </message>
    <message>
        <location filename="../src/Preferences.cpp" line="66"/>
        <source>Please select the Metaflac binary</source>
        <translation>Vyberte, prosím, spustitelný soubor Metaflac</translation>
    </message>
    <message>
        <location filename="../src/Preferences.cpp" line="76"/>
        <source>Please select the id3v2 binary</source>
        <translation>Vyberte, prosím, spustitelný soubor id3v2</translation>
    </message>
</context>
<context>
    <name>PreferencesClass</name>
    <message>
        <location filename="../ui/Preferences.ui" line="32"/>
        <source>Settings</source>
        <translation>Nastavení</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="62"/>
        <source>General</source>
        <translation>Obecné</translation>
    </message>
    <message>
        <source>&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;table style=&quot;-qt-table-type: root; margin-top:4px; margin-bottom:4px; margin-left:4px; margin-right:4px;&quot;&gt;
&lt;tr&gt;
&lt;td style=&quot;border: none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;For more information visit &lt;a href=&quot;http://en.wikipedia.org/wiki/Replay_Gain&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Wikipedia&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/td&gt;&lt;/tr&gt;&lt;/table&gt;&lt;/body&gt;&lt;/html&gt;</source>
        <translation type="obsolete">&lt;!DOCTYPE HTML PUBLIC &quot;-//W3C//DTD HTML 4.0//EN&quot; &quot;http://www.w3.org/TR/REC-html40/strict.dtd&quot;&gt;
&lt;html&gt;&lt;head&gt;&lt;meta name=&quot;qrichtext&quot; content=&quot;1&quot; /&gt;&lt;style type=&quot;text/css&quot;&gt;
p, li { white-space: pre-wrap; }
&lt;/style&gt;&lt;/head&gt;&lt;body style=&quot; font-family:&apos;Sans&apos;; font-size:10pt; font-weight:400; font-style:normal;&quot;&gt;
&lt;table style=&quot;-qt-table-type: root; margin-top:4px; margin-bottom:4px; margin-left:4px; margin-right:4px;&quot;&gt;
&lt;tr&gt;
&lt;td style=&quot;border: none;&quot;&gt;
&lt;p style=&quot; margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;&quot;&gt;Pro více informací navštivte &lt;a href=&quot;http://en.wikipedia.org/wiki/Replay_Gain&quot;&gt;&lt;span style=&quot; text-decoration: underline; color:#0000ff;&quot;&gt;Wikipedii&lt;/span&gt;&lt;/a&gt;&lt;/p&gt;&lt;/td&gt;&lt;/tr&gt;&lt;/table&gt;&lt;/body&gt;&lt;/html&gt;</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="135"/>
        <source>Replay Gain Mode</source>
        <translation>Režim vyrovnání hlasitosti</translation>
    </message>
    <message>
        <source>Target volume</source>
        <translation type="obsolete">Cílová hlasitost</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="100"/>
        <source>dB</source>
        <translation>dB</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="113"/>
        <source>Reset target volume to default value</source>
        <translation>Nastavit cílovou hlasitost na výchozí hodnotu</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="143"/>
        <source>AlbumGain</source>
        <translation>Zesílení alba</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="150"/>
        <source>TrackGain</source>
        <translation>Zesílení skladby</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="173"/>
        <source>Quick options</source>
        <translation>Rychlé volby</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="193"/>
        <source>Replay Gain all your media files.</source>
        <translation>Vyrovnat hlasitost všech vašich hudebních souborů.</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="196"/>
        <source>Replay Gain files</source>
        <translation>Vyrovnat hlasitost souborů</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="209"/>
        <source>Autorename all media files with the stored ID3 tags within the files, this works only with MP3 files.</source>
        <translation>Automaticky přejmenovat všechny hudební soubory s v souborech uloženými značkami ID3. Pracuje to jen u souborů MP3.</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="212"/>
        <source>Autorename MP3 files</source>
        <translation>Přejmenovat soubory MP3 automaticky</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="222"/>
        <source>Autorename all folders with the stored ID3 tags, this works only with MP3 files.</source>
        <translation>Automaticky přejmenovat všechny složky s uloženými značkami ID3. Pracuje to jen u souborů MP3.</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="225"/>
        <source>Autorename folders which contains the MP3 files</source>
        <translation>Automaticky přejmenovat složky obsahující soubory MP3</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="235"/>
        <source>Download cover arts from the internet.</source>
        <translation>Stáhnout obrázky obalů z internetu.</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="238"/>
        <source>Download Cover Art</source>
        <translation>Stáhnout obal</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="255"/>
        <source>Opens a file dialog at startup where you can select folders.</source>
        <translation>Otevře při spuštění souborový dialog, kde můžete vybrat složky.</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="258"/>
        <source>Open a file dialog at startup</source>
        <translation>Otevřít při spuštění souborový dialog</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="265"/>
        <source>Turn this on if you want that QtGain shows skipped files and errors in the log window.</source>
        <translation>Toto zapněte, pokud chcete, aby QtGain ukazoval přeskočené soubory a chyby v okně se zápisem.</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="268"/>
        <source>Show skipped files in Errorlog</source>
        <translation>Ukázat přeskočené soubory v zápise chyb</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="275"/>
        <source>Quit QtGain automatically after finished all opening jobs.</source>
        <translation>Ukončit QtGain automaticky po dokončení všech otevřených prací.</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="278"/>
        <source>Quit QtGain after finished gaining</source>
        <translation>Ukončit QtGain po dokončení zesilování</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="292"/>
        <source>MP3 Extras</source>
        <translation>Další pro MP3</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="362"/>
        <source>Download Cover Art from:</source>
        <translation>Stáhnout obrázek obalu z:</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="373"/>
        <source>Amazon.com</source>
        <translation>Amazon.com</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="378"/>
        <source>Google Images Search</source>
        <translation>Hledání obrázků pomocí Google</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="298"/>
        <source>Song renaming scheme</source>
        <translation>Schéma přejmenování písní</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="70"/>
        <source>Target Volume</source>
        <translation>Cílová hlasitost</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="310"/>
        <source>%Artist, %Song, %Album, %Year, %Track, %Genre</source>
        <translation>%Umělec, %Píseň, %Album, %Rok, %Skladba, %Žánr</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="317"/>
        <source>%Artist - %Song</source>
        <translation>%Umělec - %Píseň</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="327"/>
        <source>Folder renaming scheme</source>
        <translation>Schéma přejmenování složek</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="339"/>
        <source>%Artist, %Album, %Year, %Genre</source>
        <translation>%Umělec, %Album, %Rok, %Žánr</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="346"/>
        <source>%Artist - %Album</source>
        <translation>%Umělec - %Album</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="404"/>
        <source>External Tools</source>
        <translation>Vnější nástroje</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="428"/>
        <source>id3v2</source>
        <translation>id3v2</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="451"/>
        <location filename="../ui/Preferences.ui" line="538"/>
        <location filename="../ui/Preferences.ui" line="616"/>
        <location filename="../ui/Preferences.ui" line="678"/>
        <location filename="../ui/Preferences.ui" line="733"/>
        <source>...</source>
        <translation>...</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="487"/>
        <source>Replay Gain Tools</source>
        <translation>Nástroje pro vyrovnání hlasitosti</translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="515"/>
        <source>MP3Gain:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="593"/>
        <source>AACGain:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="655"/>
        <source>VorbisGain:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="717"/>
        <source>Metaflac:</source>
        <translation></translation>
    </message>
    <message>
        <location filename="../ui/Preferences.ui" line="416"/>
        <source>id3v2, needed for Autorenaming/Cover Download</source>
        <translation>id3v2 (pro automatické přejmenovávání/stažení obalu)</translation>
    </message>
</context>
<context>
    <name>QtGain</name>
    <message>
        <location filename="../src/QtGain.cpp" line="67"/>
        <source>About...</source>
        <translation>O programu...</translation>
    </message>
    <message>
        <location filename="../src/QtGain.cpp" line="70"/>
        <source>&amp;Stop...</source>
        <translation>&amp;Zastavit...</translation>
    </message>
    <message>
        <location filename="../src/QtGain.cpp" line="71"/>
        <source>Ctrl+S</source>
        <translation>Ctrl+S</translation>
    </message>
    <message>
        <location filename="../src/QtGain.cpp" line="74"/>
        <source>&amp;Configure</source>
        <translation>&amp;Nastavit</translation>
    </message>
    <message>
        <location filename="../src/QtGain.cpp" line="75"/>
        <source>Ctrl+C</source>
        <translation>Ctrl+C</translation>
    </message>
    <message>
        <location filename="../src/QtGain.cpp" line="81"/>
        <source>Donate</source>
        <translation>Darovat</translation>
    </message>
    <message>
        <location filename="../src/QtGain.cpp" line="84"/>
        <source>E&amp;xit</source>
        <translation>&amp;Ukončit</translation>
    </message>
    <message>
        <location filename="../src/QtGain.cpp" line="85"/>
        <source>Ctrl+X</source>
        <translation>Ctrl+X</translation>
    </message>
    <message>
        <location filename="../src/QtGain.cpp" line="368"/>
        <source>&lt;font color=&apos;red&apos;&gt;Not a valid media file&lt;/font&gt; :: %1&lt;br&gt;</source>
        <translation>&lt;font color=&apos;red&apos;&gt;Není platným multimediálním souborem&lt;/font&gt; :: %1&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../src/QtGain.cpp" line="374"/>
        <source>&lt;font color=&apos;red&apos;&gt;Cannot read file&lt;/font&gt; :: %1&lt;br&gt;</source>
        <translation>&lt;font color=&apos;red&apos;&gt;Nelze přečíst soubor&lt;/font&gt; :: %1&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../src/QtGain.cpp" line="380"/>
        <source>&lt;font color=&apos;red&apos;&gt;Cannot write file&lt;/font&gt; :: %1&lt;br&gt;</source>
        <translation>&lt;font color=&apos;red&apos;&gt;Nelze zapsat soubor&lt;/font&gt; :: %1&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../src/QtGain.cpp" line="390"/>
        <source>&lt;font color=&apos;green&apos;&gt;File already gained -&gt; skipped&lt;/font&gt; :: %1&lt;br&gt;</source>
        <translation>&lt;font color=&apos;green&apos;&gt;Soubor již zesílen -&gt; přeskočeno&lt;/font&gt; :: %1&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../src/QtGain.cpp" line="400"/>
        <source>Scanning directories...</source>
        <translation>Prohledávají se adresáře...</translation>
    </message>
    <message>
        <location filename="../src/QtGain.cpp" line="480"/>
        <source>Please choose a directory</source>
        <translation>Vyberte, prosím, adresář</translation>
    </message>
    <message>
        <location filename="../src/QtGain.cpp" line="503"/>
        <source>No media files found...</source>
        <translation>Nenalezeny žádné multimediální soubory...</translation>
    </message>
    <message>
        <location filename="../src/QtGain.cpp" line="597"/>
        <source>%Artist - %Album</source>
        <translation>%Umělec - %Album</translation>
    </message>
    <message>
        <location filename="../src/QtGain.cpp" line="598"/>
        <source>%Artist - %Song</source>
        <translation>%Umělec - %Píseň</translation>
    </message>
    <message>
        <location filename="../src/QtGain.cpp" line="615"/>
        <source>&lt;font color=red&gt;No replay gain tools found!&lt;/font&gt;</source>
        <translation>&lt;font color=red&gt;Nenalezeny žádné nástroje pro vyrovnání hlasitosti!&lt;/font&gt;</translation>
    </message>
    <message>
        <location filename="../src/QtGain.cpp" line="676"/>
        <source>&lt;h2&gt;%1&lt;/h2&gt;Replay Gain frontend for MP3Gain, VorbisGain, AACGain and Metaflac.&lt;br&gt;Uses id3v2 to rename files/folders of MP3 files.&lt;br&gt;Cover Arts Downloader via Amazon or Google Picture Search.&lt;br&gt;&lt;br&gt;(c) 2007-2014, Vegeta&lt;br&gt;&lt;br&gt;&lt;a href=&apos;http://qt-apps.org/content/show.php/QtGain?content=56842&apos;&gt;Website&lt;/a&gt;&lt;br&gt;&lt;br&gt;This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.&lt;br&gt;&lt;h4&gt;Thanks to the following translator(s):&lt;/h4&gt;%5&lt;h4&gt;Statistic:&lt;/h4&gt;QtGain has %2 files processed (%3 files were replay gained) since %4.</source>
        <translation>&lt;h2&gt;%1&lt;/h2&gt;Rozhraní pro vyrovnání hlasitosti pro MP3Gain, VorbisGain, AACGain a Metaflac.&lt;br&gt;Používá id3v2 pro přejmenování souborů složek souborů MP3&lt;br&gt;Stahování obalů přes Amazon nebo Google Picture Search&lt;br&gt;&lt;br&gt;(c) 2007-2014, Vegeta&lt;br&gt;&lt;a href=&apos;http://qt-apps.org/content/show.php/QtGain?content=56842&apos;&gt;Stránky projektu&lt;/a&gt;&lt;br&gt;&lt;br&gt;QtGain je svobodný software; můžete jej šířit a/nebo upravovat za podmínek povolení GNU General Public License verze 2, jak jsou zveřejněny Free Software Foundation.&lt;br&gt;&lt;h4&gt;Překladatelé:&lt;/h4&gt;%5&lt;h4&gt;Statistika:&lt;/b&gt;&lt;br&gt;QtGain  od %4 zpracoval %2 souborů (u %3 souborů bylo provedeno vyrovnání hlasitosti).</translation>
    </message>
    <message>
        <source>About</source>
        <translation type="obsolete">O programu</translation>
    </message>
    <message>
        <source>&lt;h2&gt;%1&lt;/h2&gt;Replay Gain frontend for MP3Gain, VorbisGain, AACGain and Metaflac.&lt;br&gt;Uses id3v2 to rename files/folders of MP3 files.&lt;br&gt;Cover Arts Downloader via Amazon or Google Picture Search.&lt;br&gt;&lt;br&gt;(c) 2007-2014, Vegeta&lt;br&gt;&lt;a href=&apos;http://qt-apps.org/content/show.php/QtGain?content=56842&apos;&gt;Project page&lt;/a&gt;&lt;br&gt;&lt;br&gt;QtGain This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.&lt;br&gt;&lt;h4&gt;Thanks to the following translator(s):&lt;/h4&gt;%5&lt;h4&gt;Statistic:&lt;/h4&gt;QtGain has %2 files processed (%3 files were replay gained) since %4.</source>
        <translation type="obsolete">&lt;h2&gt;%1&lt;/h2&gt;Rozhraní pro vyrovnání hlasitosti pro MP3Gain, VorbisGain, AACGain a Metaflac.&lt;br&gt;Používá id3v2 pro přejmenování souborů složek souborů MP3&lt;br&gt;Stahování obalů přes Amazon nebo Google Picture Search&lt;br&gt;&lt;br&gt;(c) 2007-2014, Vegeta&lt;br&gt;&lt;a href=&apos;http://qt-apps.org/content/show.php/QtGain?content=56842&apos;&gt;Stránky projektu&lt;/a&gt;&lt;br&gt;&lt;br&gt;QtGain je svobodný software; můžete jej šířit a/nebo upravovat za podmínek povolení GNU General Public License verze 2, jak jsou zveřejněny Free Software Foundation.&lt;br&gt;&lt;h4&gt;Překladatelé:&lt;/h4&gt;%5&lt;h4&gt;Statistika:&lt;/b&gt;&lt;br&gt;QtGain  od %4 zpracoval %2 souborů (u %3 souborů bylo provedeno vyrovnání hlasitosti).</translation>
    </message>
    <message>
        <source>QtGain</source>
        <translation type="obsolete">QtGain</translation>
    </message>
    <message>
        <location filename="../src/QtGain.cpp" line="837"/>
        <source>&lt;h2&gt;Donate&lt;/h2&gt;Thank you for your interest in donating money to the QtGain project to support further development.&lt;hr&gt;&lt;center&gt;You can donate via PayPal&lt;h4&gt;%1&lt;/h4&gt;or&lt;h4&gt;%2&lt;/h4&gt;by clicking on the above links.&lt;/center&gt;&lt;hr&gt;Thank you for your support!</source>
        <translation>&lt;h2&gt;Dar&lt;/h2&gt;Děkuji vám za váš zájem a darované peníze pro projekt QtGain na podporu dalšího vývoje.&lt;hr&gt;&lt;center&gt;Darovat můžete pomocí služby PayPal&lt;h4&gt;%1&lt;/h4&gt;nebo&lt;h4&gt;%2&lt;/h4&gt;klepnutím na odkazy výše.&lt;/center&gt;&lt;hr&gt;Děkuji vám za vaši podporu!</translation>
    </message>
    <message>
        <source>&lt;h2&gt;%1&lt;/h2&gt;Replay Gain frontend for MP3Gain, VorbisGain, AACGain and Metaflac&lt;br&gt;Uses id3v2 to rename files/folders of MP3 files&lt;br&gt;Cover Arts Downloader via Amazon or Google Picture Search&lt;br&gt;&lt;br&gt;(c) 2007-2014, Vegeta&lt;br&gt;&lt;a href=&apos;http://qt-apps.org/content/show.php/QtGain?content=56842&apos;&gt;Project page&lt;/a&gt;&lt;br&gt;&lt;br&gt;QtGain is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License version 2 as published by the Free Software Foundation.&lt;br&gt;&lt;br&gt;&lt;b&gt;Statistic:&lt;/b&gt;&lt;br&gt;QtGain has %2 files processed (%3 files were replay gained) since %4.</source>
        <translation type="obsolete">&lt;h2&gt;%1&lt;/h2&gt;Rozhraní pro vyrovnání hlasitosti pro MP3Gain, VorbisGain, AACGain a Metaflac&lt;br&gt;Používá id3v2 pro přejmenování souborů složek souborů MP3&lt;br&gt;Stahování obalů přes Amazon nebo Google Picture Search&lt;br&gt;&lt;br&gt;(c) 2007-2014, Vegeta&lt;br&gt;&lt;a href=&apos;http://qt-apps.org/content/show.php/QtGain?content=56842&apos;&gt;Stránky projektu&lt;/a&gt;&lt;br&gt;&lt;br&gt;QtGain je svobodný software; můžete jej šířit a/nebo upravovat za podmínek povolení GNU General Public License verze 2, jak jsou zveřejněny Free Software Foundation.&lt;br&gt;&lt;br&gt;&lt;b&gt;Statistika:&lt;/b&gt;&lt;br&gt;QtGain má %2 souborů zpracováno (u %3 souborů bylo provedeno vyrovnání hlasitosti) od %4.</translation>
    </message>
    <message>
        <location filename="../src/QtGain.cpp" line="724"/>
        <source>Errorlog</source>
        <translation>Chyby</translation>
    </message>
    <message>
        <location filename="../src/QtGain.cpp" line="726"/>
        <source>Close</source>
        <translation>Zavřít</translation>
    </message>
    <message>
        <location filename="../src/QtGain.cpp" line="747"/>
        <source>Operation aborted...</source>
        <translation>Operace zrušena...</translation>
    </message>
    <message>
        <location filename="../src/QtGain.cpp" line="747"/>
        <source>TrackGain finished!</source>
        <translation>Zesilování skladeb skončilo!</translation>
    </message>
    <message>
        <location filename="../src/QtGain.cpp" line="747"/>
        <source>AlbumGain finished!</source>
        <translation>Zesilování alb skončilo!</translation>
    </message>
    <message>
        <location filename="../src/QtGain.cpp" line="747"/>
        <source>Operation finished!</source>
        <translation>Operace dokončena!</translation>
    </message>
    <message>
        <location filename="../src/QtGain.cpp" line="785"/>
        <source>TrackGain in process...</source>
        <translation>Zesílení skladby probíhá...</translation>
    </message>
    <message>
        <location filename="../src/QtGain.cpp" line="785"/>
        <source>AlbumGain in process...</source>
        <translation>Zesílení alba probíhá...</translation>
    </message>
</context>
<context>
    <name>QtGainClass</name>
    <message>
        <location filename="../ui/QtGain.ui" line="35"/>
        <source>QtGain</source>
        <translation>QtGain</translation>
    </message>
    <message>
        <location filename="../ui/QtGain.ui" line="278"/>
        <source>Gained:</source>
        <translation>Zesíleno:</translation>
    </message>
    <message>
        <location filename="../ui/QtGain.ui" line="299"/>
        <location filename="../ui/QtGain.ui" line="332"/>
        <location filename="../ui/QtGain.ui" line="369"/>
        <source>0</source>
        <translation>0</translation>
    </message>
    <message>
        <location filename="../ui/QtGain.ui" line="311"/>
        <source>Skipped:</source>
        <translation>Přeskočeno:</translation>
    </message>
    <message>
        <location filename="../ui/QtGain.ui" line="348"/>
        <source>Error:</source>
        <translation>Chyba:</translation>
    </message>
    <message>
        <location filename="../ui/QtGain.ui" line="381"/>
        <source>Time:</source>
        <translation>Čas:</translation>
    </message>
    <message>
        <location filename="../ui/QtGain.ui" line="402"/>
        <source>00:00:00</source>
        <translation>00:00:00</translation>
    </message>
    <message>
        <location filename="../ui/QtGain.ui" line="463"/>
        <source>Ready...</source>
        <translation>Připraven...</translation>
    </message>
    <message>
        <location filename="../ui/QtGain.ui" line="427"/>
        <source>Status</source>
        <translation>Stav</translation>
    </message>
    <message>
        <location filename="../ui/QtGain.ui" line="249"/>
        <source>Information</source>
        <translation>Informace</translation>
    </message>
    <message>
        <location filename="../ui/QtGain.ui" line="69"/>
        <source>ToDo:</source>
        <translation>Udělat:</translation>
    </message>
    <message>
        <source>Files</source>
        <translation type="obsolete">Soubory</translation>
    </message>
</context>
<context>
    <name>renameFiles</name>
    <message>
        <location filename="../src/renamefiles.cpp" line="118"/>
        <source>Processing ID3-Tags...</source>
        <translation>Zpracovávají se značky ID3...</translation>
    </message>
    <message>
        <location filename="../src/renamefiles.cpp" line="148"/>
        <source>&lt;font color=&apos;red&apos;&gt;No ID3-Tag found -&gt; skipped&lt;/font&gt; :: %1&lt;br&gt;</source>
        <translation>&lt;font color=&apos;red&apos;&gt;Nenalezena žádná značka ID3 -&gt; přeskočeno&lt;/font&gt; :: %1&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../src/renamefiles.cpp" line="155"/>
        <location filename="../src/renamefiles.cpp" line="181"/>
        <source>%Track</source>
        <translation>%Skladba</translation>
    </message>
    <message>
        <location filename="../src/renamefiles.cpp" line="156"/>
        <location filename="../src/renamefiles.cpp" line="182"/>
        <location filename="../src/renamefiles.cpp" line="198"/>
        <source>%Year</source>
        <translation>%Rok</translation>
    </message>
    <message>
        <location filename="../src/renamefiles.cpp" line="157"/>
        <location filename="../src/renamefiles.cpp" line="183"/>
        <source>%Song</source>
        <translation>%Píseň</translation>
    </message>
    <message>
        <location filename="../src/renamefiles.cpp" line="158"/>
        <location filename="../src/renamefiles.cpp" line="184"/>
        <location filename="../src/renamefiles.cpp" line="199"/>
        <source>%Album</source>
        <translation>%Album</translation>
    </message>
    <message>
        <location filename="../src/renamefiles.cpp" line="159"/>
        <location filename="../src/renamefiles.cpp" line="185"/>
        <location filename="../src/renamefiles.cpp" line="200"/>
        <source>%Artist</source>
        <translation>%Umělec</translation>
    </message>
    <message>
        <location filename="../src/renamefiles.cpp" line="160"/>
        <location filename="../src/renamefiles.cpp" line="186"/>
        <location filename="../src/renamefiles.cpp" line="201"/>
        <source>%Genre</source>
        <translation>%Žánr</translation>
    </message>
    <message>
        <location filename="../src/renamefiles.cpp" line="162"/>
        <source>&lt;font color=&apos;red&apos;&gt;Not all ID3-Tags found or not all tags are valid -&gt; skipped&lt;/font&gt; :: %1&lt;br&gt;</source>
        <translation>&lt;font color=&apos;red&apos;&gt;Nenalezeny všechny značky ID3 nebo nejsou všechny značky platné -&gt; přeskočeno&lt;/font&gt; :: %1&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../src/renamefiles.cpp" line="174"/>
        <source>&lt;font color=&apos;red&apos;&gt;Found &apos;to ignore&apos; pattern in ID3-Tags -&gt; skipped&lt;/font&gt; :: %1&lt;br&gt;</source>
        <translation>&lt;font color=&apos;red&apos;&gt;Ve značkách ID3 nalezen vzor &quot;nevšímat si&quot; -&gt; přeskočeno&lt;/font&gt; :: %1&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../src/renamefiles.cpp" line="191"/>
        <source>&lt;font color=&apos;red&apos;&gt;Could not rename file %1 to %2&lt;/font&gt;&lt;br&gt;</source>
        <translation>&lt;font color=&apos;red&apos;&gt;Nepodařilo se přejmenovat soubor %1 na %2&lt;/font&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../src/renamefiles.cpp" line="230"/>
        <source>&lt;font color=&apos;red&apos;&gt;Skipped renaming of &apos;%1&apos;&lt;/font&gt;&lt;br&gt;</source>
        <translation>&lt;font color=&apos;red&apos;&gt;Přeskočeno přejmenování %1&lt;/font&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../src/renamefiles.cpp" line="235"/>
        <source>&lt;font color=&apos;red&apos;&gt;Could not rename folder &apos;%1&apos; to &apos;%2&apos;&lt;/font&gt;&lt;br&gt;</source>
        <translation>&lt;font color=&apos;red&apos;&gt;Nepodařilo se přejmenovat složku %1 na %2&lt;/font&gt;&lt;br&gt;</translation>
    </message>
    <message>
        <location filename="../src/renamefiles.cpp" line="271"/>
        <source>Downloading Cover Artwork...</source>
        <translation>Stahuje se obal...</translation>
    </message>
</context>
</TS>
