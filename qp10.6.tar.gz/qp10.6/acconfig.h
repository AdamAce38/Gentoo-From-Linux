#undef LINUX
#undef SOLARIS

#undef MULTIPLE_THREADS

#define BITS_PER_WORD 32
#define BYTES_PER_WORD 4
#define HAVE_GCC_LABELS 1
#define INT_TYPE long
#define SHORT_TYPE short
