open OUnit

let () = ignore (run_test_tt_main Test.all)
