from . import hiprand_test
