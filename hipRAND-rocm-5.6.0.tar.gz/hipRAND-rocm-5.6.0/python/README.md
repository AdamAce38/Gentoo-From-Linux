# Python Wrappers

* [rocRAND Wrapper](./rocrand/)
* [hipRAND Wrapper](./hiprand/)
