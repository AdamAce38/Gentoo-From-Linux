==================
hipRAND User Guide
==================

.. toctree::
   :maxdepth: 3
   :caption: Contents:
   :numbered:

   introduction
   installing
   cpp_api
   python_api
