===================
C/C++ API Reference
===================

This chapter describes the hipRAND C and C++ API.

Device Functions
================
.. doxygengroup:: hipranddevice

C Host API
==========
.. doxygengroup:: hiprandhost

C++ Host API Wrapper
====================
.. doxygengroup:: hiprandhostcpp
