#include <QCoreApplication>
#include "usbexample.h"

int main(int argc, char *argv[])
{
    QCoreApplication a(argc, argv);

    UsbExample example;

    return a.exec();
}
