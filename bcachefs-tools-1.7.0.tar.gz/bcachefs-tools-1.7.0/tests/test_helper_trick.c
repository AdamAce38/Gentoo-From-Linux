/*
 * Prevent compiler from optimizing away a variable by referencing it from
 * another compilation unit.
 */
void
trick_compiler(int *x)
{
}
