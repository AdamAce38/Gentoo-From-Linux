#ifndef _LINUX_CONSOLE_H_
#define _LINUX_CONSOLE_H_

#define console_lock()
#define console_unlock()

#endif /* _LINUX_CONSOLE_H */
