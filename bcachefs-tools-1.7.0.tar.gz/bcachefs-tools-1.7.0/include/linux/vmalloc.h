#ifndef __TOOLS_LINUX_VMALLOC_H
#define __TOOLS_LINUX_VMALLOC_H

#include "linux/slab.h"

#endif /* __TOOLS_LINUX_VMALLOC_H */
