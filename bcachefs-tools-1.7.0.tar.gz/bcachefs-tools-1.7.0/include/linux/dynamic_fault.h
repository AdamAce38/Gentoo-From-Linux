#ifndef __TOOLS_LINUX_DYNAMIC_FAULT_H
#define __TOOLS_LINUX_DYNAMIC_FAULT_H

#define dynamic_fault(_class)			0
#define race_fault()				0

#endif /* __TOOLS_LINUX_DYNAMIC_FAULT_H */
