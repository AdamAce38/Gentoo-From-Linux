#ifndef _SCHED_RT_H
#define _SCHED_RT_H

static inline int rt_task(struct task_struct *p)
{
	return 0;
}

#endif /* _SCHED_RT_H */
