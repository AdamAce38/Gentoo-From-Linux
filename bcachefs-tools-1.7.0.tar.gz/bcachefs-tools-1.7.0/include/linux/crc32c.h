#ifndef _LINUX_CRC32C_H
#define _LINUX_CRC32C_H

#include "tools-util.h"

#endif	/* _LINUX_CRC32C_H */
