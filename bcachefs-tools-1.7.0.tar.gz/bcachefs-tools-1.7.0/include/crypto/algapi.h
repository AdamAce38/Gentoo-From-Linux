#ifndef _CRYPTO_ALGAPI_H
#define _CRYPTO_ALGAPI_H

#include <linux/crypto.h>
#include <crypto/skcipher.h>

#endif	/* _CRYPTO_ALGAPI_H */
