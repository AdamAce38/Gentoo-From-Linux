#ifndef _KEYS_USER_TYPE_H
#define _KEYS_USER_TYPE_H

#include <linux/key.h>

#endif /* _KEYS_USER_TYPE_H */
