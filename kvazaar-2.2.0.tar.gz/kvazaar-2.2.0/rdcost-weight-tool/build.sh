#!/bin/sh

gcc -O2 filter_rdcosts.c -o frcosts_matrix
gcc -O2 ols_2ndpart.c -o ols_2ndpart
