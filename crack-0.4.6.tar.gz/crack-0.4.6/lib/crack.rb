module Crack
  class ParseError < StandardError; end
end

require 'crack/version'
require 'crack/util'
require 'crack/json'
require 'crack/xml'
