#ifndef RATE_LIMIT_H
#define RATE_LIMIT_H

extern struct rateGovernor_t maxBitrate;
#define MAX_BITRATE "maxBitrate"

#endif
