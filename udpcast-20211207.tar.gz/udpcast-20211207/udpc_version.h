#ifndef UDPC_VERSION_H
#define UDPC_VERSION_H

#include "libbb_udpcast.h"
extern const char *version;

#endif
