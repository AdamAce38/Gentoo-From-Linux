from flask.json.provider import (  # noqa: F401
    DefaultJSONProvider as DefaultJSONProvider,
    JSONProvider as JSONProvider,
)
