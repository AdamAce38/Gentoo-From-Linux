.. _python_versions:

Python version support
======================

The main branch and releases >= 0.19.0 onwards only support Python
3.8.0 or greater.

The 0.6-maintenance branch supported Python3.6. The final 0.6.X
release, 0.6.15, was released in October 2019 after the release of
Python3.8.
