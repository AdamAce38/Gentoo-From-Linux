Logo
====

The Quart logo has been kindly provided by Vic Shóstak, @koddr,
`Quart-Logo <https://github.com/koddr/quart-logo>`_.

The logo itself has a lot of meaning, as expressed by @koddr,

    This is looks like Flask fonts and give us to understand what's
    the quart means?, because 1 quart equal 0.9 litre (and we're
    assuming: full bottle on logo hold one litre, but it's not full —
    because hold a quart now).

    The bung on top of bottle makes it clear — this is production
    ready Python framework with speed more than Flask, but Flask-like
    — all in one pack!. Get, open (equal install) and use it!

    Unstable liquid's state in bottle give us to understand — this
    liquid is reactivity, like new async features on Python and
    HTTP/2. And some aggressive gradient's color of liquid say to us
    hey, I'm alive and can help you to improve yourself... just use
    me!.


.. image:: ../_static/logo.png
   :alt: Quart logo
