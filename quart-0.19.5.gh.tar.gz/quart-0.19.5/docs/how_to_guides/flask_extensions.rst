.. _flask_extensions:

Using Flask Extensions
======================

Some Flask extensions can be used with Quart by patching Quart to act
as Flask, to patch Quart see the `Quart-Flask-Patch
<https://github.com/pgjones/quart-flask-patch>`_ extension. This was
part of Quart until release 0.19.0.

Reference
---------

More information about Flask extensions can be found
`here <https://flask.palletsprojects.com/extensions>`_.
