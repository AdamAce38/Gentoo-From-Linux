
/* Memory types (MT) to scan in /proc/meminfo */
MT_ADD(MemTotal)
MT_ADD(MemFree)
MT_ADD(MemShared)
MT_ADD(Slab)
MT_ADD(Buffers)
MT_ADD(Cached)

MT_ADD(SwapTotal)
MT_ADD(SwapFree)
