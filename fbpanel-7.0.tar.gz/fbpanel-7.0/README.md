# fbpanel
A lightweight gtk2 panel for Linux desktop.

Please visit [project web site](http://aanatoly.github.io/fbpanel/)
for more information.

![shot](/data/shot.png)
