package Net::SSH::Any::DPipe;

use strict;
use warnings;

use Carp;
our @CARP_NOT = qw(Net::SSH::Any);

# This module is just a marker inheretid by the other classes really implementing dpipes

1;

__END__

=head1 NAME

Net::SSH::Any::DPipe - bidirectional communication with remote process


