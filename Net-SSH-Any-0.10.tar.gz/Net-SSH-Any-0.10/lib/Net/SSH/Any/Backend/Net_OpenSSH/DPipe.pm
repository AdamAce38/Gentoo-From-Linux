package Net::SSH::Any::Backend::Net_OpenSSH::DPipe;

use strict;
use warnings;

use Net::SSH::Any::OS::POSIX::DPipe;
our @ISA = qw(Net::SSH::Any::OS::POSIX::DPipe);
