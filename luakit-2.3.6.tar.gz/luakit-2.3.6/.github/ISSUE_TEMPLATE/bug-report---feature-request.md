---
name: Report luakit issue
about: Use this template to create issues.

---

**Current Behavior:**


**Desired Behavior:**


**How can we reproduce it (step by step):**


**Environment:**

Linux Distribution & Version:
Output of `luakit --version`:


**Note about webkit issues:**

If you're reporting a rendering issue, please test it with the gnome
browser ephiphany as well. If the issue occurs there too, we're very
likely not able to help. These issues should be reported to webkit:
https://bugs.webkit.org
