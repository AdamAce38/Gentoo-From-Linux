#Luakit Authors

**Authors of luakit**

*  Aidan Holm        (aidanholm) <aidanholm@gmail.com>       2016-2017
*  Mason Larobina    (mason-l)   <mason.larobina@gmail.com>  2010-2012

**Contributors to luakit (A to Z)**

*  Alexis Daboville              <alexis.daboville@gmail.com> 2011
*  André Aparício                <aparicio99@gmail.com>      2011
*  Ben Armston                   <ben.armston@googlemail.com> 2012
*  Chris van Dijk    (quigybo)   <quigybo@hotmail.com>       2010
*  Clint Adams       (Clint)     <schizo@debian.org>         2010
*  Constantin Schomburg (xconstruct) <me@xconstruct.net>     2011
*  Fabian Streitel               <karottenreibe@gmail.com>   2010-2011
*  Gregor Uhlenheuer (kongo)     <kongo2002@googlemail.com>  2010
*  HarryD                        <harry@anapnea.net>         2010
*  Henning Hasemann              <hhasemann@web.de>          2010
*  Henrik Hallberg   (halhen)    <halhen@k2h.se>             2010
*  Javier Rojas      (jerojasro) <jerojasro@devnull.li>      2011
*  Jonas Höglund     (FireFly)   <firefly@firefly.nu>        2012
*  Kumar Appaiah     (kmap)      <a.kumar@alumni.iitm.ac.in> 2010
*  LokiChaos                     <loki.chaos@gmail.com>      2012
*  Matthew Wild      (MattJ)     <mwild1@gmail.com>          2010
*  Michael Dietrich  (emdete)    <mdt@emdete.de>             2010
*  Michishige Kaito  (mkaito)    <me@mkaito.com>             2012
*  Pawel Tomak       (grodzik)   <pawel.tomak@gmail.com>     2010
*  Pawel Zuzelski    (pawelz)    <pawelz@pld-linux.org>      2010
*  Pete Elmore                   <pete@debu.gs>              2010
*  Piotr Husiatyński (husio)     <phusiatynski@gmail.com>    2010
*  Richard Gay                   <richard.gay@t-online.de>   2010
*  Roman Leonov      (liaonau)   <rliaonau@gmail.com>        2011
*  Stefan Bolte      (portix)    <portix@gmx.net>            2011
*  Stjujsckij Nickolaj           <sterkrig@home.no>          2011
*  Vasuvi                        <vasuvi@inbox.com>          2010-2011

**Author of `lib/markdown.lua`**

* Niklas Frykholm               <niklas@frykholm.se>        2008

**Author of the JavaScript greasemonkey methods in `lib/userscripts.lua`**

* Jim Tuttle                                                2009

**Author of the `lib/go_input.lua` JavaScript**

* Aldrik Dunbar     (n30n)                                  2009

**Author of the `lib/follow_selected.lua` javascript**

* israellevin                                               2009

**Inherited authors from the awesomewm project**

* Julien Danjou                 <julien@danjou.info>        2007-2009
* Pierre Habouzit               <madcoder@debian.org>       2008
* Michael Gehring               <mg@ebfe.org>               2008
* Aldo Cortesi                  <aldo@nullcube.com>         2007-2008

**Special thanks to authors from the uzbl & surf projects for inspiration and support**

* Dieter Plaetinck  (Dieter@be) <dieter@plaetinck.be>       2009-2010
* Enno Boland       (tox)       <tox@s01.de>                2009-2010
* Dequis                        <dx@dxzone.com.ar>          2009
* Robert Manea      (robm)      <rob.manea@gmail.com>       2009-2010
* Simon Lipp        (sloonz)    <sloonz@gmail.com>          2010

**License**

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.
