﻿namespace NuGetUtility.Test.Extensions
{
    internal record struct HashSetExtensionTestObject(string A, int B);
}
