﻿namespace NuGetUtility.LicenseValidator
{
    public record ValidationError(string Error, string Context);
}
