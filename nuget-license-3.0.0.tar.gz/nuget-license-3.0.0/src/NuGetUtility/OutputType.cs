﻿namespace NuGetUtility
{
    public enum OutputType
    {
        Table,
        Json,
        JsonPretty
    }
}
