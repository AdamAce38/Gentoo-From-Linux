﻿namespace NuGetUtility.Wrapper.NuGetWrapper
{
    internal class NugetWrapperException : Exception
    {
        public NugetWrapperException(string message)
            : base(message) { }
    }
}
