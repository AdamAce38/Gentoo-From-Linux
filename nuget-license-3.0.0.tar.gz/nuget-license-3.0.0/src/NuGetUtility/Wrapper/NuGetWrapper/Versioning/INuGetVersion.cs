﻿namespace NuGetUtility.Wrapper.NuGetWrapper.Versioning
{
    public interface INuGetVersion { }
}
