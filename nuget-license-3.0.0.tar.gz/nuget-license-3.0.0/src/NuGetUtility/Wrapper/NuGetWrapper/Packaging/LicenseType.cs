namespace NuGetUtility.Wrapper.NuGetWrapper.Packaging
{
    public enum LicenseType
    {
        File,
        Expression,
        Overwrite
    }
}
