﻿namespace NuGetUtility.Wrapper.NuGetWrapper.Frameworks
{
    public interface INuGetFramework
    {
        string? ToString();
    }
}
