### Fixes

* frpc has a certain chance to panic when login: close of closed channel.
