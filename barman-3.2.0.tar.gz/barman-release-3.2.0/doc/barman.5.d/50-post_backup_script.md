post_backup_script
:   Hook script launched after a base backup, after 'post_backup_retry_script'.
    Global/Server.
