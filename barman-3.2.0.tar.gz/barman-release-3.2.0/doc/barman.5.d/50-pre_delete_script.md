pre_delete_script
:   Hook script launched before the deletion of a backup. Global/Server.
