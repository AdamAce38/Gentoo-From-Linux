streaming_backup_name
:   Identifier to be used as `application_name` by the `pg_basebackup` command.
    Only available with `pg_basebackup` >= 9.3. By default it is set to
    `barman_streaming_backup`. Global/Server.
