pre_wal_delete_script
:   Hook script launched before the deletion of a WAL file. Global/Server.
