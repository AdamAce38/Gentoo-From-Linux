post_archive_script
:   Hook script launched after a WAL file is archived by maintenance,
    after 'post_archive_retry_script'. Global/Server.
