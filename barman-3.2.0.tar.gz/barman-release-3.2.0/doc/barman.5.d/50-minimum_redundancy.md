minimum_redundancy
:   Minimum number of backups to be retained. Default 0. Global/Server.
