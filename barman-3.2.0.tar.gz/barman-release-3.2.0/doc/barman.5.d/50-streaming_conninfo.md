streaming_conninfo
:   Connection string used by Barman to connect to the Postgres server via
    streaming replication protocol. By default it is set to `conninfo`. Server.
