backup_compression_level
:   An integer value representing the compression level to use when compressing
    backups. Allowed values depend on the compression algorithm specified by
    `backup_compression`. Only supported when `backup_method = postgres`.
    Global/Server.
