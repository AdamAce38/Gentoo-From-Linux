post_wal_delete_script
:   Hook script launched after the deletion of a WAL file, after 'post_wal_delete_retry_script'.
    Global/Server.
