custom_decompression_filter
:   Customised decompression algorithm applied to compressed WAL files;
    this must match the compression algorithm. Global/Server.
