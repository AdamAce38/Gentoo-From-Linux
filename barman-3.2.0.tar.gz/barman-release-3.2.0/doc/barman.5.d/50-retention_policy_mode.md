retention_policy_mode
:   Currently only "auto" is implemented. Global/Server.
