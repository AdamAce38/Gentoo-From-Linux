network_compression
:   This option allows you to enable data compression for network
    transfers.
    If set to `false` (default), no compression is used.
    If set to `true`, compression is enabled, reducing network usage.
    Global/Server.
