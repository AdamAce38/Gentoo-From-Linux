backup_compression_workers
:   The number of compression threads to be used during the backup process. Only supported when
    `backup_compression = zstd` is set. Default value is 0. In this case default compression 
    behavior will be used.
