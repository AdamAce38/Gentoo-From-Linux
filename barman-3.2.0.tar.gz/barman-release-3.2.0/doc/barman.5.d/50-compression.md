compression
:   Standard compression algorithm applied to WAL files. Possible values
    are: `gzip` (requires `gzip` to be installed on the system),
    `bzip2` (requires `bzip2`), `pigz` (requires `pigz`), `pygzip`
    (Python's internal gzip compressor) and `pybzip2` (Python's internal
    bzip2 compressor). Global/Server.
