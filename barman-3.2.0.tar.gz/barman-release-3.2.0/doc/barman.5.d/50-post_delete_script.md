post_delete_script
:   Hook script launched after the deletion of a backup, after 'post_delete_retry_script'.
    Global/Server.
