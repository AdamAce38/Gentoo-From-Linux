custom_compression_filter
:   Customised compression algorithm applied to WAL files. Global/Server.
