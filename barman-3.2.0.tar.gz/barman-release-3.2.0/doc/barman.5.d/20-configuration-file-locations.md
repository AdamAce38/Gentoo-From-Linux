# CONFIGURATION FILE LOCATIONS

The system-level Barman configuration file is located at

    /etc/barman.conf

or

    /etc/barman/barman.conf

and is overridden on a per-user level by

    $HOME/.barman.conf
