pre_backup_script
:   Hook script launched before a base backup. Global/Server.
