create_slot
:   When set to `auto` and `slot_name` is defined, Barman automatically
    attempts to create the replication slot if not present.
    When set to `manual` (default), the replication slot needs to be
    manually created. Global/Server.
