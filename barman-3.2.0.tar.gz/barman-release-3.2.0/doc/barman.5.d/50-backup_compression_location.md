backup_compression_location
:   The location (either `client` or `server`) where compression should be
    performed during the backup. The value `server` is only allowed if the
    server is running PostgreSQL 15 or later. Global/Server.
