% BARMAN(1) Barman User manuals | Version 3.2.0
% EnterpriseDB <https://www.enterprisedb.com>
% October 20, 2022
