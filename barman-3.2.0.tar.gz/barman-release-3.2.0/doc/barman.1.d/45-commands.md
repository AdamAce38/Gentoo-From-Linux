# COMMANDS

Important: every command has a help option
