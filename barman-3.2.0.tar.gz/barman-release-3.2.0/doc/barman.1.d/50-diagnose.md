diagnose
:   Collect diagnostic information about the server where barman is installed
    and all the configured servers, including: global configuration, SSH version,
    Python version, `rsync` version, as well as current configuration and status
    of all servers.
