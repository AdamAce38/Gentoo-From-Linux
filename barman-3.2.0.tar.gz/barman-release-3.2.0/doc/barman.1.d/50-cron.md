cron
:   Perform maintenance tasks, such as enforcing retention policies or
    WAL files management.

    --keep-descriptors
    :    Keep the stdout and the stderr streams of the Barman subprocesses
         attached to this one. This is useful for Docker based installations.
