list-servers
:   Show all the configured servers, and their descriptions.
