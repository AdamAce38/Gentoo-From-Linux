# EXIT STATUS

0
:   Success

Not zero
:   Failure
