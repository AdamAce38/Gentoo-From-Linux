# AUTHORS

Barman maintainers (in alphabetical order):

* Abhijit Menon-Sen
* Jane Threefoot
* Michael Wallace

Past contributors (in alphabetical order):

* Anna Bellandi (QA/testing)
* Britt Cole (documentation reviewer)
* Carlo Ascani (developer)
* Francesco Canovai (QA/testing)
* Gabriele Bartolini (architect)
* Gianni Ciolli (QA/testing)
* Giulio Calacoci (developer)
* Giuseppe Broccolo (developer)
* Jonathan Battiato (QA/testing)
* Leonardo Cecchi (developer)
* Marco Nenciarini (project leader)
* Niccolò Fei (QA/testing)
* Rubens Souza (QA/testing)
* Stefano Bianucci (developer)
