show-servers *SERVER_NAME*
:   Show information about `SERVER_NAME`, including: `conninfo`,
    `backup_directory`, `wals_directory` and many more.
    Specify `all` as `SERVER_NAME` to show information about all
    the configured servers.
