************
Introduction
************

.. include:: ../README.rst
    :start-after: elementpath-introduction
