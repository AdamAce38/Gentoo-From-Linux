#!/bin/sh

#PBS -N pbsjob.sh
#PBS -d .
#PBS -l nodes=1
#PBS -l host=node01.abc.com

pwd
