#!/bin/sh

#PBS -N pbsjob.sh
#PBS -d .
#PBS -l nodes=node01.abc.com:ppn=2

date
