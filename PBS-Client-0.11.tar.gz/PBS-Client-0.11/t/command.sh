#!/bin/sh

#PBS -N pbsjob.sh
#PBS -d .
#PBS -v A,B=b,C,D=d
#PBS -l nodes=1

pwd
