#!/usr/bin/sh

#PBS -N test1
#PBS -d .
#PBS -q @server01
#PBS -A guest
#PBS -l nodes=1

pwd
