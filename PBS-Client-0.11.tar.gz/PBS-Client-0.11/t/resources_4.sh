#!/bin/sh

#PBS -N pbsjob.sh
#PBS -d .
#PBS -l nodes=1
#PBS -a 1448.33

pwd
