# asahi-nvram
Nvram reader/writer for arm macs. May or may not result in you having to perform a dfu restore.