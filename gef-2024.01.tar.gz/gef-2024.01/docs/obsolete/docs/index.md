
---

## The latest version of the documentation is hosted on [hugsy.github.io/gef](https://hugsy.github.io/gef)

---

![redirect](https://i.imgflip.com/1f0lcn.jpg)
