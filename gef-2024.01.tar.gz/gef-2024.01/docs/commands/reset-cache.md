## Command `reset-cache`

This command is only useful for debugging `GEF` itself.
