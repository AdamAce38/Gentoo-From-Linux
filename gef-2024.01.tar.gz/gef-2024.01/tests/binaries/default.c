/**
 * default.c
 * -*- mode: c -*-
 * -*- coding: utf-8 -*-
 */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>


int main(int argc, char** argv, char** envp)
{
        printf("Hello World!\n");
        return EXIT_SUCCESS;
}
