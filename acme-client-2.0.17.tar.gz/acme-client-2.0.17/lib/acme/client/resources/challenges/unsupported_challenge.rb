class Acme::Client::Resources::Challenges::Unsupported < Acme::Client::Resources::Challenges::Base
end
