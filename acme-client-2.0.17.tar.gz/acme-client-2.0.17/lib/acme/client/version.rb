# frozen_string_literal: true

module Acme
  class Client
    VERSION = '2.0.17'.freeze
  end
end
