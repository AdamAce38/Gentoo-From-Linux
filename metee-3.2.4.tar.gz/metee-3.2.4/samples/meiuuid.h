/* SPDX-License-Identifier: Apache-2.0 */
/*
 * Copyright (C) 2014-2019 Intel Corporation
 */
#include <linux/uuid.h>
int mei_uuid_parse(const char *str, uuid_le *uuid);
