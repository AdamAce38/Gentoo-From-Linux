Changes
=======

Version 0.5.0 (released 2018-01-05)

- Try to read configuration values from application config if a context
  is available otherwise return an instance config or extension default.
  (pull #23)
- Package refresh - testing Python 3.6, fixed links, and much more.
  (pull #22)

Version 0.4.2 (released 2015-03-23)

- Set use_ssl default value according to request protocol. (pull #14)
- Improved documentation typo fixes. (pull #13 #18)
- Migration from flaskext.gravatar to flask_gravatar. (pull #11 #12)

Version 0.4.1 (released 2013-11-07)

- Added Python 3 support. (pull #9)

Version 0.4.0 (released 2013-08-09)

- Added custom url support. (pull #7)
- Use setuptools. (pull #6)

Version 0.3.0 (released 2013-03-23)

- Enabled registering multiple times in one process.

Version 0.2.4 (released 2012-11-28)

- Added init_app method.
- Fixed various bugs.

Version 0.2.3 (released 2011-11-29)

- Added HTTPS suppport.

Version 0.2.2 (released 2011-01-10)

- First public release.
- It works.
