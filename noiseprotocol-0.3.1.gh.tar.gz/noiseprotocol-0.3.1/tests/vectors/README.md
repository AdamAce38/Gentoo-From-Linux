Test vectors:
- cacophony.txt from https://github.com/centromere/cacophony/blob/master/vectors/cacophony.txt, stripped from outer dict (so that it is just a list of json objects)
- snow-multipsk.txt from https://github.com/mcginty/snow/blob/master/tests/vectors/snow-multipsk.txt, stripped from outer dict (so that it is just a list of json objects)  