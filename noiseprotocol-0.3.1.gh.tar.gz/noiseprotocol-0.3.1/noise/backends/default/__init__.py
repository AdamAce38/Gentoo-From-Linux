from .backend import DefaultNoiseBackend

noise_backend = DefaultNoiseBackend()
