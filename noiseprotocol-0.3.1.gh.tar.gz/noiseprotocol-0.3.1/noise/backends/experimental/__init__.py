from noise.backends.experimental.backend import ExperimentalNoiseBackend

noise_backend = ExperimentalNoiseBackend()
