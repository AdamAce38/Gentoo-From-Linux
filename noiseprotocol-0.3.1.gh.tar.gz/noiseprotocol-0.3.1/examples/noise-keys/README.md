Keypairs in this directory were generated solely for usage in examples. Private keys are not protected with a passphrase. 

**DO NOT** use them for any other purpose than testing, as they are publicly available and it will pose a security threat to you. 