This example shows interoperability with Wireguard. 
It connects to Wireguard service, does a handshake, sends and receives a ping.

Run with noiseprotocol and scapy installed in your environment (python main.py) 
or directly from here (PYTHONPATH=../../ python main.py) (you still need scapy)
