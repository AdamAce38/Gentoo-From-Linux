module Foo
  def self.foo?
    !!@foo
  end
end
__END__
# Classes
module Foo
  self.@foo: bot

# def self.foo?: -> bool
end
