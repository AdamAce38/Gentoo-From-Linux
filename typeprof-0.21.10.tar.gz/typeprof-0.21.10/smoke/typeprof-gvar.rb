x = 42
x = "foo" if $typeprof
p(x)

__END__
# Revealed types
#  smoke/typeprof-gvar.rb:3 #=> String

# Classes
