s = "foo"
p s[0..1]

__END__
# Revealed types
#  smoke/range2.rb:2 #=> String?

# Classes
