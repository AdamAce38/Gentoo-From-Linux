while begin l = r = true; l or r end
end

__END__
# Classes
