def foo
  1i
end

__END__
# Classes
class Object
  private
  def foo: -> Complex
end
