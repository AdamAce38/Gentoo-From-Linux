UndefinedConstant::Foo = Struct.new(:foo)

__END__
# Classes
class AnonymousStruct_generated_1 < Struct[untyped]
  attr_accessor foo(): untyped
end
