class Foo
  x = 1
end
__END__
# Classes
class Foo
end
