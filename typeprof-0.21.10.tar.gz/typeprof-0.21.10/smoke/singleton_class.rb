class << Object.new
end

__END__
# Errors
smoke/singleton_class.rb:1: [warning] A singleton class is open for Object; handled as any

# Classes
