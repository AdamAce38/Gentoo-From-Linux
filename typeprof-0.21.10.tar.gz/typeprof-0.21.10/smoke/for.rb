for x in [[1, 2]]
  p x
end

__END__
# Revealed types
#  smoke/for.rb:2 #=> [Integer, Integer]?

# Classes
