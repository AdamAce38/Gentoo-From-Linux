class Foo
  def foo
    @foo = 1
  end
end

__END__
# Classes
class Foo
  @foo: Integer

# def foo: -> Integer
end
