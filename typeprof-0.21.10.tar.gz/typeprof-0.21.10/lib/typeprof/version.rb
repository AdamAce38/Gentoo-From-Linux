module TypeProf
  VERSION = "0.21.10"
end
