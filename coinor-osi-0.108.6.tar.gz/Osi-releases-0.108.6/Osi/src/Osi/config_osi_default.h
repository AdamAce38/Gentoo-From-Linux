
/***************************************************************************/
/*           HERE DEFINE THE PROJECT SPECIFIC PUBLIC MACROS                */
/*    These are only in effect in a setting that doesn't use configure     */
/***************************************************************************/

/* Version number of project */
#define OSI_VERSION "0.108.6"

/* Major Version number of project */
#define OSI_VERSION_MAJOR 0

/* Minor Version number of project */
#define OSI_VERSION_MINOR 108

/* Release Version number of project */
#define OSI_VERSION_RELEASE 6
