"""Certbot compatibility test Apache configurators"""
