Errors
------

.. automodule:: acme.errors
   :members:
