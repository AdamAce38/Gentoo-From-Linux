# Empty Cli App

This is a simple test cli app

## Installation

Add this line to your application's Gemfile:

```ruby
gem 'cli-app'
```

And then execute:

    $ bundle

Or install it yourself as:

    $ gem install cli-app

## Usage

Place files in `lib/cli/app/`. They are loaded automatically. If you need a
specific load order, use `require` in your files.
