require "cli/app/version"

module Cli
  module App
    # Your code goes here...
  end
end
