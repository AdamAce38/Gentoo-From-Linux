module Cli
  module App
    VERSION = "0.1.0".freeze
  end
end
