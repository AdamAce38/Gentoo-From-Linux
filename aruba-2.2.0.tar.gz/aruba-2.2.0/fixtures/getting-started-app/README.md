# Simple Cli App

This is a simple app to get started with `aruba`.
