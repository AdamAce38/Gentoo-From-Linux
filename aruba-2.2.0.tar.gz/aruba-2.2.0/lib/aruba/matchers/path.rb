Aruba.platform.require_matching_files("../path/**/*.rb", __FILE__)
