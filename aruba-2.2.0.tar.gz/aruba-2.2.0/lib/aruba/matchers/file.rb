Aruba.platform.require_matching_files("../file/**/*.rb", __FILE__)
