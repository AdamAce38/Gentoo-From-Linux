Aruba.platform.require_matching_files("../command/**/*.rb", __FILE__)
