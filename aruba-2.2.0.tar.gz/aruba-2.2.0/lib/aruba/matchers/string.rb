Aruba.platform.require_matching_files("../string/**/*.rb", __FILE__)
