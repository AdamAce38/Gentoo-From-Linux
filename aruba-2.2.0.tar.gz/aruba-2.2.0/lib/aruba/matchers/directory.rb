Aruba.platform.require_matching_files("../directory/**/*.rb", __FILE__)
