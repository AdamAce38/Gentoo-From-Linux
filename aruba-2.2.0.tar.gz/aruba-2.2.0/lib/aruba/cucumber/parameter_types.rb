ParameterType(name: "channel", regexp: "output|stderr|stdout", transformer: ->(name) { name })
