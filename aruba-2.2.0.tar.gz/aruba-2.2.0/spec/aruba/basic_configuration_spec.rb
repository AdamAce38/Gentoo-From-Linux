require "spec_helper"

RSpec.describe Aruba::BasicConfiguration do
  it_behaves_like "a basic configuration"
end
