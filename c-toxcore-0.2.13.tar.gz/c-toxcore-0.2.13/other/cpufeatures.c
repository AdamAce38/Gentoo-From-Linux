#ifdef ANDROID_CPU_FEATURES
#define typeof __typeof__
#include ANDROID_CPU_FEATURES
#endif

typedef int unused_declaration;
