GPRCONFIG KB
============

GPRCONFIG KB is a knowledge base for configuring GPR toolchains, used by
[GPRbuild](https://github.com/AdaCore/gprbuild) and
[GPR2](https://github.com/AdaCore/gpr) projects.

Installation and use
--------------------

Please refer to corresponding project documentation for instructions on how
gprconfig_kb is used by that project.

Doc & Examples
--------------

The documentation for this knowledge base is available
[online](http://docs.adacore.com/gprbuild-docs/html/gprbuild_ug/companion_tools.html#the-gprconfig-knowledge-base).
