## mime-types

Basic mime-type handling types and functions
