"""
Integration tests for stem.socket.
"""

__all__ = ['control_message', 'control_socket']
