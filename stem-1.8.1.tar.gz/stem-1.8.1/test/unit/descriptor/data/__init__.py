"""
Test data for test.unit.descriptor tests.
"""

__all__ = [
  'collector',
]
