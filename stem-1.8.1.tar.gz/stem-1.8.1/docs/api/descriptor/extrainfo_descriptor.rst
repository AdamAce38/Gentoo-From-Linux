Extrainfo Descriptor
====================

.. automodule:: stem.descriptor.extrainfo_descriptor

