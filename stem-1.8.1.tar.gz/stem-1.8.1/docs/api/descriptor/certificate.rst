Certificate
===========

.. automodule:: stem.descriptor.certificate

