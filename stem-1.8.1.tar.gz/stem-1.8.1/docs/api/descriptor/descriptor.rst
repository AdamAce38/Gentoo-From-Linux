Descriptor
==========

.. automodule:: stem.descriptor.__init__

