Descriptor Reader
=================

.. automodule:: stem.descriptor.reader

