MicroDescriptor
===============

.. automodule:: stem.descriptor.microdescriptor

