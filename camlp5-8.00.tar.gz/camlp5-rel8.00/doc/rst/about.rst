About
=====

.. container::
   :name: menu

.. container::
   :name: content

   .. rubric:: About Camlp5
      :name: about-camlp5
      :class: top

   Version
   Home page
      http://pauillac.inria.fr/~ddr/camlp5/
   Author
      Daniel de Rauglaudre, INRIA
   History
      The ideas behind Camlp5 were expressed in the 1990s by Michel
      Mauny. In 1996, Daniel de Rauglaudre implemented the first version
      named Camlp4 (the four "p" standing for
      "Pre-Processor-Pretty-Printer"). In 2002, Camlp4 was maintained by
      Michel Mauny, and later extended by Nicolas Pouillard, with
      different basic ideas, introducing some incompatibilities. In
      2006, Daniel de Rauglaudre restarted this work, renaming it
      Camlp5.

   ::

   .. container:: trailer
