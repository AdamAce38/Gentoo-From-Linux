
value diff = (x /. ax) ** 2.0
;
