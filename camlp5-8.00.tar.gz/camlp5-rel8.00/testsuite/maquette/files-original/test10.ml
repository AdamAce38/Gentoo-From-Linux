
let x = a >:: b &&= c ||= d
;
