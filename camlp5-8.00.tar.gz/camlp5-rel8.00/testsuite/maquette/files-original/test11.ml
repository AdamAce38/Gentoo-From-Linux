
type t1 =
   A of { f1 : int; f2 : string option; }
and
 t2 =
   B of { f3 : int; f4 : string option; }
;;
