
let x = a & b ;;
let y = c or d ;;
