# Protocol Buffer Version 2 IDL parser

This directory contains a sample Protocol Buffers IDL version 2 parser
and pretty-printer.  It's a significant grammar, and that's really why
it's here.  The tests in `tests/testdata` were copied from the
testsuite of [ocaml-protoc](https://github.com/mransan/ocaml-protoc).
