"""Provide an imported version-comparison class"""

from mcomix._vendor.packaging.version import LegacyVersion

__all__ = ["LegacyVersion"]

