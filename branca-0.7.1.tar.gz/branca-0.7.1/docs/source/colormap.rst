:mod:`branca.colormap`
----------------------

.. automodule:: branca.colormap
   :members:
   :undoc-members:
   :show-inheritance:
