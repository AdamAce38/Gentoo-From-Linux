"""Unittests for emoji."""


from . import *
