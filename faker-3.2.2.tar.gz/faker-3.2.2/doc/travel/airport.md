# Faker::Travel::Airport

```ruby
Faker::Travel::Airport.name(size: 'large', region: 'united_states') #=> "Los Angeles International Airport"
Faker::Travel::Airport.iata(size: 'large', region: 'united_states') #=> "LAX"
```
