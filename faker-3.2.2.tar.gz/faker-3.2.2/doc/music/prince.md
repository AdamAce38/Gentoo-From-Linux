# Faker::Music::Prince

```ruby
Faker::Music::Prince.lyric #=> "It's been 7 hours and 16 days since you took your love away."

Faker::Music::Prince.song #=> "The Beautiful Ones"

Faker::Music::Prince.album #=> "Purple Rain"

Faker::Music::Prince.band #=> "The New Power Generation"

```
