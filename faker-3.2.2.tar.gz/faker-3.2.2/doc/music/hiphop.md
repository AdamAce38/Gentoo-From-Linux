# Faker::Music::Hiphop

```ruby
Faker::Music::Hiphop.artist #=> "Lil Wayne"

Faker::Music::Hiphop.groups #=> "G-Unit"

Faker::Music::Hiphop.subgenres #=> "Alternative"

```
