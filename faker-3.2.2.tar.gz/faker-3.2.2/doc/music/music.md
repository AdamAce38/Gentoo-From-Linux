# Faker::Music

Available since version 1.6.4.

```ruby
Faker::Music.key #=> "C"

Faker::Music.chord #=> "Amaj7"

Faker::Music.instrument #=> "Ukelele"

Faker::Music.band #=> "The Beatles"

Faker::Music.album #=> "Sgt. Pepper's Lonely Hearts Club"

Faker::Music.genre #=> "Rock"

Faker::Music.mambo_no_5 #=> "Monica"
```
