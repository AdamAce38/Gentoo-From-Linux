# Faker::Music::UmphreysMcgee

```ruby
Faker::Music::UmphreysMcgee.song #=> "Dump City"
```
