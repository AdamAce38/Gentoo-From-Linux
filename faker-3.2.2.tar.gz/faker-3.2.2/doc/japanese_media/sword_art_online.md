# Faker::JapaneseMedia::SwordArtOnline

Available since version 1.9.0.

```ruby
# Random Sword Art Online real name
Faker::JapaneseMedia::SwordArtOnline.real_name #=> "Kirigaya Kazuto"

# Random Sword Art Online game name
Faker::JapaneseMedia::SwordArtOnline.game_name #=> "Silica"

# Random Sword Art Online location
Faker::JapaneseMedia::SwordArtOnline.location #=> "Ruby Palace"

# Random Sword Art Online item
Faker::JapaneseMedia::SwordArtOnline.item #=> "Blackwyrm Coat"
```
