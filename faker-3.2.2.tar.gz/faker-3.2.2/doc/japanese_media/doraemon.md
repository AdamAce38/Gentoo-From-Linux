# Faker::JapaneseMedia::Doraemon

```ruby
Faker::JapaneseMedia::Doraemon.character #=> "Nobita"

Faker::JapaneseMedia::Doraemon.gadget #=> "Anywhere Door"

Faker::JapaneseMedia::Doraemon.location #=> "Tokyo"
```
