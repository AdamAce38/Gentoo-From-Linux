# Faker::TvShows::FamilyGuy

```ruby
Faker::TvShows::FamilyGuy.character #=> "Peter Griffin"

Faker::TvShows::FamilyGuy.location #=> "James Woods High"

Faker::TvShows::FamilyGuy.quote #=> "It’s Peanut Butter Jelly Time."
```
