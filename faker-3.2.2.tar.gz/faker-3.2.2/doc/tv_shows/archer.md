# Faker::TvShows::Archer

```ruby
Faker::TvShows::Archer.character #=> "Sterling Archer"

Faker::TvShows::Archer.location #=> "Area 51"

Faker::TvShows::Archer.quote #=> "Danger Zone!"
```
