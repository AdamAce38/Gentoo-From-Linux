# Faker::TvShows::Community

Available since version 1.9.0.

```ruby
Faker::TvShows::Community.characters #=> "Jeff Winger"

Faker::TvShows::Community.quotes #=> I fear a political career could shine a negative light on my drug dealing."
```
