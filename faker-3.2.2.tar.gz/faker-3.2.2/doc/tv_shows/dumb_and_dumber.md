# Faker::TvShows::DumbAndDumber

```ruby
Faker::TvShows::DumbAndDumber.actor #=> "Jim Carrey"

Faker::TvShows::DumbAndDumber.character #=> "Harry Dunne"

Faker::TvShows::DumbAndDumber.quote #=> "Why you going to the airport? Flying somewhere?"
```
