# Faker::TvShows::StrangerThings

Available since version 1.9.0.

```ruby
Faker::TvShows::StrangerThings.character #=> "six"

Faker::TvShows::StrangerThings.quote #=> "Friends don't lie"
```
