# Faker::TvShows::ParksAndRec

```ruby
Faker::TvShows::ParksAndRec.character #=> "Leslie Knope"

Faker::TvShows::ParksAndRec.city #=> "Pawnee"
```
