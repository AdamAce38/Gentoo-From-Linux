# Faker::TvShows::FinalSpace

```ruby
Faker::TvShows::FinalSpace.character #=> "Gary Goodspeed"

Faker::TvShows::FinalSpace.vehicle #=> "Imperium Cruiser"

Faker::TvShows::FinalSpace.quote #=> "It's an alien on my face! It's an alien on my...It's a space alien!"
```
