# Faker::TvShows::AquaTeenHungerForce

```ruby
Faker::TvShows::AquaTeenHungerForce.character #=> "Master Shake"

Faker::TvShows::AquaTeenHungerForce.quote #=> "Listen to me, Randy. It doesn't matter what you look like on the outside-- whether you're white or black or a sasquatch even-- as long as you follow your dream, no matter how crazy or against the law it is, except for a sasquatch. If you're a sasquatch, the rules are different."
```
