# Faker::TvShows::Seinfeld

Available since version 1.8.3.

```ruby
Faker::TvShows::Seinfeld.character  #=> George Costanza

Faker::TvShows::Seinfeld.quote      #=> I'm not a lesbian. I hate men, but I'm not a lesbian

Faker::TvShows::Seinfeld.business   #=> Kruger Industrial Smoothing
```
