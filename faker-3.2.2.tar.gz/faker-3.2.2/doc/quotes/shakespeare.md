# Faker::Quotes::Shakespeare

```ruby
Faker::Quotes::Shakespeare.hamlet_quote # => "To be, or not to be: that is the question."

Faker::Quotes::Shakespeare.as_you_like_it_quote # => "Can one desire too much of a good thing?."

Faker::Quotes::Shakespeare.king_richard_iii_quote # => "Now is the winter of our discontent."

Faker::Quotes::Shakespeare.romeo_and_juliet_quote # => "O Romeo, Romeo! wherefore art thou Romeo?."
```
