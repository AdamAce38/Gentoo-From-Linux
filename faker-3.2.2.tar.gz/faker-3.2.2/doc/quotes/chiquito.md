# Faker::Quotes::Chiquito

```ruby
Faker::Quotes::Chiquito.expression # => "¡Ereh un torpedo!"

Faker::Quotes::Chiquito.term # => "Fistro"

Faker::Quotes::Chiquito.sentence # => "Te llamo trigo por no llamarte Rodrigo"

Faker::Quotes::Chiquito.joke # => "- Papár papár llévame al circo!
                             #     - Noorl! El que quiera verte que venga a la casa"
```
