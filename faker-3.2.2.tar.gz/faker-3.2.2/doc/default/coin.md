# Faker::Coin

```ruby
# Flip a coin
Faker::Coin.flip #=> "Heads"

# The currency of the coin
Faker::Coin.name #=> "Philippine Peso"
```
