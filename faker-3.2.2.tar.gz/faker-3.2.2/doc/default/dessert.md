# Faker::Dessert

Available since version 1.8.0.

```ruby
# Random dessert variety
Faker::Dessert.variety #=> "Cake"

# Random dessert topping
Faker::Dessert.topping #=> "Gummy Bears"

# Random dessert flavor
Faker::Dessert.flavor #=> "Salted Caramel"
```