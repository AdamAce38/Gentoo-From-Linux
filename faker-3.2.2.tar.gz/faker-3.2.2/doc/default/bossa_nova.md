# Faker::BossaNova

```ruby
Faker::BossaNova.artist #=> "Tom Jobim"

Faker::BossaNova.song #=> "Chega de Saudade"
```
