# Faker::Artist

Available since version 1.8.8.

```ruby
Faker::Artist.name #=> "Michelangelo"
```
