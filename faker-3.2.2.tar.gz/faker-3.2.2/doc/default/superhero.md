# Faker::Superhero

Available since version 1.6.2.

```ruby
# Random Superhero name
Faker::Superhero.name #=> "Magnificent Shatterstar"

# Random Superhero power
Faker::Superhero.power #=> "Photokinesis"

# Random Superhero prefix
Faker::Superhero.prefix #=> "Captain"

# Random Superhero suffix
Faker::Superhero.suffix #=> "the Fated"

# Random Superhero descriptor
Faker::Superhero.descriptor #=> "Bizarro"
```
