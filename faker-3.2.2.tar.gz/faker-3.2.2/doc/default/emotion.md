# Faker::Emotion

```ruby
Faker::Emotion.noun #=> "euphoria"
Faker::Emotion.adjective #=> "chagrined"
```
