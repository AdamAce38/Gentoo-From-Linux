# Faker::Crypto

Available since version 1.6.4.

```ruby
Faker::Crypto.md5 #=> "6b5ed240042e8a65c55ddb826c3408e6"

Faker::Crypto.sha1 #=> "4e99e31c51eef8b2d290e709f757f92e558a503f"

Faker::Crypto.sha256 #=> "51e4dbb424cd9db1ec5fb989514f2a35652ececef33f21c8dd1fd61bb8e3929d"

Faker::Crypto.sha512 #=> "7b9fc82a6642874833d01b74a7b4fae3d15373193b55cfba47327f8f0afdc8d0ea155b58639a03a887009ef997dab8dd8d36767620d430f6e787e5996e26da80"
```
