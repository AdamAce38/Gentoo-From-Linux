# Faker::Cosmere

```ruby
Faker::Cosmere.aon                    #=> "Rao"

Faker::Cosmere.shard_world            #=> "Yolen"

Faker::Cosmere.shard                  #=> "Ambition"

Faker::Cosmere.surge                  #=> "Progression"

Faker::Cosmere.knight_radiant          #=> "Truthwatcher"

Faker::Cosmere.metal                  #=> "Brass"

Faker::Cosmere.allomancer             #=> "Coinshot"

Faker::Cosmere.feruchemist            #=> "Archivist"

Faker::Cosmere.herald                 #=> "Ishar"

Faker::Cosmere.spren                  #=> "Flamespren"
```
