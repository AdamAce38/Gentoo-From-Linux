# Faker::Color

```ruby
Faker::Color.hex_color #=> "#31a785"

Faker::Color.color_name #=> "yellow"

Faker::Color.rgb_color #=> [54, 233, 67]

Faker::Color.hsl_color #=> [69.87, 0.66, 0.3]

Faker::Color.hsla_color #=> [154.77, 0.36, 0.9, 0.26170574657729073]
```
