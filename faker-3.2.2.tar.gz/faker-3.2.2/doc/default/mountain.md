# Faker::Mountain

```ruby
Faker::Mountain.name #=> "Mount Everest"
Faker::Mountain.range #=> "Dhaulagiri Himalaya"
```
