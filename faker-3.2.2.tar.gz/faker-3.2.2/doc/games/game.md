# Faker::Game

```ruby
# Random Game Title
Faker::Game.title #=> "Half-Life"

# Random Game Genre
Faker::Game.genre #=> "First-person shooter"

# Random Game Platform
Faker::Game.platform #=> "Nintendo DS"
```
