# Faker::Games::Touhou

```ruby
# Random Touhou game
Faker::Games::Touhou.game #=> "Mountain of Faith"

# Random Touhou character
Faker::Games::Touhou.character #=> "Sanae Kochiya"

# Random Touhou location
Faker::Games::Touhou.location #=> "Moriya Shrine"

# Random Touhou item
Faker::Games::Touhou.spell_card #=> 'Esoterica "Gray Thaumaturgy"'

# Random Touhou song
Faker::Games::Touhou.song #=> "Faith Is for the Transient People"
```
