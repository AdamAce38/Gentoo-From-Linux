# Faker::Games::Myst

Available since version 1.9.0.

```ruby
Faker::Games::Myst.game #=> "Myst III: Exile"

Faker::Games::Myst.creature #=> "squee"

Faker::Games::Myst.age #=> "Relto"

Faker::Games::Myst.character #=> "Gehn"

Faker::Games::Myst.quote #=> "I realized, the moment I fell into the fissure, that the Book would not be destroyed as I had planned."
```
