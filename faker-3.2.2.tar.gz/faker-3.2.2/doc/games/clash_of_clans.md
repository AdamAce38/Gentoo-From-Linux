# Faker::Games::ClashOfClans

```ruby
Faker::Games::ClashOfClans.troop #=> "Barbarian"

Faker::Games::ClashOfClans.rank #=> "Legend"

Faker::Games::ClashOfClans.defensive_building #=> "Cannon"
```
