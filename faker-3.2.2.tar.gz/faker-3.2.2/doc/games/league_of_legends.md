# Faker::Games::LeagueOfLegends

Available since version 1.8.0.

```ruby
Faker::Games::LeagueOfLegends.champion #=> "Jarvan IV"

Faker::Games::LeagueOfLegends.location #=> "Demacia"

Faker::Games::LeagueOfLegends.quote #=> "Purge the unjust."

Faker::Games::LeagueOfLegends.summoner_spell #=> "Flash"

Faker::Games::LeagueOfLegends.masteries #=> "Double Edged Sword"

Faker::Games::LeagueOfLegends.rank #=> "Bronze V"
```
