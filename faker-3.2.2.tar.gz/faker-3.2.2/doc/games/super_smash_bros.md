# Faker::Games::SuperSmashBros

Data up to date as of October 2018, preceding any final announcements on *Super Smash Bros. Ultimate*.

```ruby
# Any playable fighter from the series
Faker::Games::SuperSmashBros.fighter #=> "Simon Belmont"

# Any stage from the series
Faker::Games::SuperSmashBros.stage #=> "Temple"
```
