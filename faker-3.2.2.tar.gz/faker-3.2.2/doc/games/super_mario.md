# Faker::Games::Super Mario

```ruby
# Random Super Mario character
Faker::Games::SuperMario.character #=> "Luigi"

# Random Super Mario game
Faker::Games::SuperMario.game #=> "Super Mario Odyssey"

# Random Super Mario location
Faker::Games::SuperMario.location #=> "Kong City"
```
