# Faker::Music::Show

```ruby
Faker::Music::Show.adult_musical  # => "West Side Story"
Faker::Music::Show.kids_musical   # => "Into the Woods JR."
Faker::Music::Show.play           # => "Death of a Salesman"
```
