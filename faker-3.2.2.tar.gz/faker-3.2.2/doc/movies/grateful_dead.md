# Faker::Movies::GratefulDead

```ruby
Faker::Movies::GratefulDead.player #=> "Jerry Garcia"

Faker::Movies::GratefulDead.song #=> "China Cat Sunflower"
```
