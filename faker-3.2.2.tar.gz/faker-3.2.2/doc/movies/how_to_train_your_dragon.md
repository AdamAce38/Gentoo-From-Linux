# Faker::Movies::HowToTrainYourDragon

```ruby
Faker::Movies::HowToTrainYourDragon.character #=> "Hiccup"
Faker::Movies::HowToTrainYourDragon.location #=> "Berk"
Faker::Movies::HowToTrainYourDragon.dragon #=> "Toothless"
```