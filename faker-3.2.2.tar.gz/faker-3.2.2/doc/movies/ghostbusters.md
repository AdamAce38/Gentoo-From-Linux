# Faker::Ghostbusters

```ruby
Faker::Movies::Ghostbusters.actor #=> "Bill Murray"

Faker::Movies::Ghostbusters.character #=> "Dr. Egon Spengler"

Faker::Movies::Ghostbusters.quote #=> "I tried to think of the most harmless thing. Something I loved from my childhood. Something that could never ever possibly destroy us. Mr. Stay Puft!","
```
