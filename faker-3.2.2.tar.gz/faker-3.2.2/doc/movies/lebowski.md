# Faker::Movies::Lebowski

Available since version 1.8.8.

```ruby
Faker::Movies::Lebowski.actor #=> "John Goodman"

Faker::Movies::Lebowski.character #=> "Jackie Treehorn"

Faker::Movies::Lebowski.quote #=> "Forget it, Donny, you're out of your element!"
```
