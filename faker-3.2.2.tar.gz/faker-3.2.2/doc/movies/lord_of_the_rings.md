# Faker::Movies::LordOfTheRings

```ruby
Faker::Movies::LordOfTheRings.character #=> "Legolas"

Faker::Movies::LordOfTheRings.location #=> "Helm's Deep"
```
