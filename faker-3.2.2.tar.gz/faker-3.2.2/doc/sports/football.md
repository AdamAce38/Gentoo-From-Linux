# Faker::Sports::Football

Available since version 1.9.0.

```ruby
Faker::Sports::Football.team #=> "Manchester United"

Faker::Sports::Football.player #=> "Lionel Messi"

Faker::Sports::Football.coach #=> "Jose Mourinho"

Faker::Sports::Football.competition #=> "FIFA World Cup"

Faker::Sports::Football.position #=> "Defensive Midfielder"
```
