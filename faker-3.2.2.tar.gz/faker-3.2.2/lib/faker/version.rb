# frozen_string_literal: true

module Faker # :nodoc:
  VERSION = '3.2.1'
end
