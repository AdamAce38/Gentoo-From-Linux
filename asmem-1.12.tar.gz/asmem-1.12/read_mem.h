/*
 * Copyright (c) 1999  Albert Dorofeev <Albert@mail.dma.be>
 * For the updates see http://bewoner.dma.be/Albert/
 *
 * This software is distributed under GPL. For details see LICENSE file.
 */

#ifndef _read_mem_h_
#define _read_mem_h_

int open_meminfo();
int read_meminfo();
int close_meminfo();

#endif

