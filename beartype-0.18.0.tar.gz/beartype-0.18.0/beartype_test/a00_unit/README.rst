.. # ------------------( SYNOPSIS                           )------------------

==================
Project Unit Tests
==================

This subpackage provides *all* pytest_-based **unit tests** (i.e., callables
collectively exercising this project's public API but individually exercising
only a small subset of that API referred to as a "unit") for this project.

.. # ------------------( LINKS                              )------------------
.. _pytest:
   https://docs.pytest.org
