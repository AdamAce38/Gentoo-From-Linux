Contact and Support channels
------------------------------

If you have interest, questions, issues or suggestions you
are welcome to:

* join `execnet-dev`_ for general discussions
* join `execnet-commit`_ to be notified of changes
* clone the `github repository`_ and submit patches
* hang out on the #pytest channel on `irc.libera.chat <ircs://irc.libera.chat/#pytest>`_
  (using an IRC client, via `webchat <https://web.libera.chat/#pytest>`_,
  or `via Matrix <https://matrix.to/#/%23pytest:libera.chat>`_).

.. _`execnet-dev`: http://mail.python.org/mailman/listinfo/execnet-dev
.. _`execnet-commit`: http://mail.python.org/mailman/listinfo/execnet-commit
.. _`github repository`: https://github.com/pytest-dev/execnet
