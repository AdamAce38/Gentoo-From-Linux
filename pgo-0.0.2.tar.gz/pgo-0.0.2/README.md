# soko-cli

A CLI for packages.g.o - still are WIP currently
