package main

import "github.com/arzano/pgo/cmd"

func main() {
	cmd.Execute()
}
