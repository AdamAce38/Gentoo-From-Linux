# Loader - `tmuxp.workspace.loader`

```{eval-rst}
.. automodule:: tmuxp.workspace.loader
   :members:
   :show-inheritance:
   :undoc-members:
```
