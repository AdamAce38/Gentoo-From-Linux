# Constants - `tmuxp.workspace.constants`

```{eval-rst}
.. automodule:: tmuxp.workspace.constants
   :members:
   :show-inheritance:
   :undoc-members:
```
