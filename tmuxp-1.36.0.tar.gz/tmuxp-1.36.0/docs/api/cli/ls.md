# tmuxp ls - `tmuxp.cli.ls`

```{eval-rst}
.. automodule:: tmuxp.cli.ls
   :members:
   :show-inheritance:
   :undoc-members:
```
