"""Example tmuxp plugin module for reattaching sessions."""
