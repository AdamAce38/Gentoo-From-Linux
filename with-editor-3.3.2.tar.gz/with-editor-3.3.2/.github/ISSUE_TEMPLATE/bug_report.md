---
title: 
name: 🪳 Bug report
about: Report a defect. Do not use this for support requests and feature suggestions.
---

Please explain
    (1) what behavior you expected
    (2) what behavior you observed
    (3) and how we can reproduce the issue.

You don't have to quote the above lines to do that.

Please include a backtrace in your report.  In most cases doing:

    M-x toggle-debug-on-error RET

and then going through the steps again should result in a backtrace.

---- now delete this line and everything above ----
