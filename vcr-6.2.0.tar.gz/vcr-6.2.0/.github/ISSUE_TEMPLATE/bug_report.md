---
name: Bug report
about: Create a report to help us improve
title: ''
labels: ''
assignees: ''

---

{{Replace with description of the problem and code or logs to help explain your problem}}

{{Include VCR configuration and appropriate vcr cassettes}}

Ruby {{Replace with version}}
Gem {{Replace with version}}
HTTP {{Replace with name and version}}
Mock {{Replace with name and version}}
Rails {{Replace with version if applicable}}
Rspec {{Replace with version if applicable}}
