from setuptools import setup

setup(cmake_args=["-DEXAMPLE_DEFINE5=5"])
