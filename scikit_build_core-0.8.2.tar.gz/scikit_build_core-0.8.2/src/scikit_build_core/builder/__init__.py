"""
The items in this module are general tools for building wheels, useful by both the build backend and plugins.
"""

from __future__ import annotations

__all__: list[str] = []
