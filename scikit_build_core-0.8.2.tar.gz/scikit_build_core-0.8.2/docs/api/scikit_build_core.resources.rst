scikit\_build\_core.resources package
=====================================

.. automodule:: scikit_build_core.resources
   :members:
   :undoc-members:
   :show-inheritance:

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   scikit_build_core.resources.find_python
