scikit\_build\_core.setuptools package
======================================

.. automodule:: scikit_build_core.setuptools
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

scikit\_build\_core.setuptools.build\_cmake module
--------------------------------------------------

.. automodule:: scikit_build_core.setuptools.build_cmake
   :members:
   :undoc-members:
   :show-inheritance:

scikit\_build\_core.setuptools.build\_meta module
-------------------------------------------------

.. automodule:: scikit_build_core.setuptools.build_meta
   :members:
   :undoc-members:
   :show-inheritance:

scikit\_build\_core.setuptools.wrapper module
---------------------------------------------

.. automodule:: scikit_build_core.setuptools.wrapper
   :members:
   :undoc-members:
   :show-inheritance:
