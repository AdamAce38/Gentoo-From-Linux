scikit\_build\_core.metadata package
====================================

.. automodule:: scikit_build_core.metadata
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

scikit\_build\_core.metadata.fancy\_pypi\_readme module
-------------------------------------------------------

.. automodule:: scikit_build_core.metadata.fancy_pypi_readme
   :members:
   :undoc-members:
   :show-inheritance:

scikit\_build\_core.metadata.regex module
-----------------------------------------

.. automodule:: scikit_build_core.metadata.regex
   :members:
   :undoc-members:
   :show-inheritance:

scikit\_build\_core.metadata.setuptools\_scm module
---------------------------------------------------

.. automodule:: scikit_build_core.metadata.setuptools_scm
   :members:
   :undoc-members:
   :show-inheritance:
