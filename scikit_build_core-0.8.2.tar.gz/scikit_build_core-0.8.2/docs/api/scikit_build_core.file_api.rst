scikit\_build\_core.file\_api package
=====================================

.. automodule:: scikit_build_core.file_api
   :members:
   :undoc-members:
   :show-inheritance:

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   scikit_build_core.file_api.model

Submodules
----------

scikit\_build\_core.file\_api.query module
------------------------------------------

.. automodule:: scikit_build_core.file_api.query
   :members:
   :undoc-members:
   :show-inheritance:

scikit\_build\_core.file\_api.reply module
------------------------------------------

.. automodule:: scikit_build_core.file_api.reply
   :members:
   :undoc-members:
   :show-inheritance:
