scikit\_build\_core.settings package
====================================

.. automodule:: scikit_build_core.settings
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

scikit\_build\_core.settings.documentation module
-------------------------------------------------

.. automodule:: scikit_build_core.settings.documentation
   :members:
   :undoc-members:
   :show-inheritance:

scikit\_build\_core.settings.json\_schema module
------------------------------------------------

.. automodule:: scikit_build_core.settings.json_schema
   :members:
   :undoc-members:
   :show-inheritance:

scikit\_build\_core.settings.metadata module
--------------------------------------------

.. automodule:: scikit_build_core.settings.metadata
   :members:
   :undoc-members:
   :show-inheritance:

scikit\_build\_core.settings.skbuild\_docs module
-------------------------------------------------

.. automodule:: scikit_build_core.settings.skbuild_docs
   :members:
   :undoc-members:
   :show-inheritance:

scikit\_build\_core.settings.skbuild\_model module
--------------------------------------------------

.. automodule:: scikit_build_core.settings.skbuild_model
   :members:
   :undoc-members:
   :show-inheritance:

scikit\_build\_core.settings.skbuild\_read\_settings module
-----------------------------------------------------------

.. automodule:: scikit_build_core.settings.skbuild_read_settings
   :members:
   :undoc-members:
   :show-inheritance:

scikit\_build\_core.settings.skbuild\_schema module
---------------------------------------------------

.. automodule:: scikit_build_core.settings.skbuild_schema
   :members:
   :undoc-members:
   :show-inheritance:

scikit\_build\_core.settings.sources module
-------------------------------------------

.. automodule:: scikit_build_core.settings.sources
   :members:
   :undoc-members:
   :show-inheritance:
