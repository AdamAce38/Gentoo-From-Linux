scikit\_build\_core.builder package
===================================

.. automodule:: scikit_build_core.builder
   :members:
   :undoc-members:
   :show-inheritance:

Submodules
----------

scikit\_build\_core.builder.builder module
------------------------------------------

.. automodule:: scikit_build_core.builder.builder
   :members:
   :undoc-members:
   :show-inheritance:

scikit\_build\_core.builder.generator module
--------------------------------------------

.. automodule:: scikit_build_core.builder.generator
   :members:
   :undoc-members:
   :show-inheritance:

scikit\_build\_core.builder.get\_requires module
------------------------------------------------

.. automodule:: scikit_build_core.builder.get_requires
   :members:
   :undoc-members:
   :show-inheritance:

scikit\_build\_core.builder.macos module
----------------------------------------

.. automodule:: scikit_build_core.builder.macos
   :members:
   :undoc-members:
   :show-inheritance:

scikit\_build\_core.builder.sysconfig module
--------------------------------------------

.. automodule:: scikit_build_core.builder.sysconfig
   :members:
   :undoc-members:
   :show-inheritance:

scikit\_build\_core.builder.wheel\_tag module
---------------------------------------------

.. automodule:: scikit_build_core.builder.wheel_tag
   :members:
   :undoc-members:
   :show-inheritance:
