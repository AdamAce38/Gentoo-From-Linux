float square(float x) { return x * x; }
