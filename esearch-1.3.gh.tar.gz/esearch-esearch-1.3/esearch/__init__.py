#!/usr/bin/python
# Distributed under the terms of the GNU General Public License v2

__version__ = "vcs"
