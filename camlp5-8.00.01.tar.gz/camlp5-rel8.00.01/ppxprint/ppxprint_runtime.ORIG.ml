(* camlp5r *)
(* ppxprint_runtime.ml,v *)
(* Copyright (c) INRIA 2007-2017 *)

IFDEF BOOTSTRAP THEN

module Runtime = struct
module Stdlib = Stdlib
module Fmt = Fmt
end

ELSE
END
