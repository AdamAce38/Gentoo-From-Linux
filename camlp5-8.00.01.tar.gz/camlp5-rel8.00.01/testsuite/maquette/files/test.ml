value x = ((1)) ;

type t = {
  a : int ;
  b : string ;
} ;
  
