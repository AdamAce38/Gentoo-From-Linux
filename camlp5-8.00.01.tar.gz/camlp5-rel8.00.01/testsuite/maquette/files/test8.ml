type t 'a 'b = 'c  constraint 'a = 'b
 and u 'a 'b = t 'a 'b ;
