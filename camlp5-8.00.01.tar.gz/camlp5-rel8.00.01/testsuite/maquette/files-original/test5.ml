let diff = sqrt ((float xdiff /. (float wx *. bnd)) ** 2.0 +.
                (float ydiff /. (float wy *. bnd)) ** 2.0)
;;

let diff = sqrt ((float xdiff /. ax) ** 2.0 +.
                (float ydiff /. ay) ** 2.0)
;;

let diff = ((f xdiff /. ax) ** 2.0)
;;

let diff = ((x /. ax) ** 2.0)
;;
