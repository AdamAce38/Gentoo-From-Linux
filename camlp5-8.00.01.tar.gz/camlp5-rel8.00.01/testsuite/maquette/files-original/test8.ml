type ('a,'b) t constraint 'a = 'b and ('a,'b) u = ('a,'b) t;;
