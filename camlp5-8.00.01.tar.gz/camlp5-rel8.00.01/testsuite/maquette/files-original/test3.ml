let f x =
  g (fun repr -> 1)
;;
