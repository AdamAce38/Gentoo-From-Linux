class virtual f (a, b) =
object(self)
end
;;
