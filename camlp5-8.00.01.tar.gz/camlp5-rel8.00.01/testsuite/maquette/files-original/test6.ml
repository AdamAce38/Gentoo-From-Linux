class foobar = object (self : 'self)
  inherit foo as super
  inherit! bar
end
;;
