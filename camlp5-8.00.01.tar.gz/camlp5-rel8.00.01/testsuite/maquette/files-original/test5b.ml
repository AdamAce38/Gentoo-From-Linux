
let diff = ((x /. ax) ** 2.0)
;;
