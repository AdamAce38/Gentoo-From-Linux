let ast_impl_magic_number = "Caml1999M027"
let ast_intf_magic_number = "Caml1999N027"
