#define RARVER_MAJOR     7
#define RARVER_MINOR     0
#define RARVER_BETA      0
#define RARVER_DAY      26
#define RARVER_MONTH     2
#define RARVER_YEAR   2024
